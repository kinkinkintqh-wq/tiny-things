import {describe,it,expect} from 'vitest';
import {runLetterSteps} from '../../../../../packages/tapeout-adapter/src/letter-step';
const step={rule:'sum' as const,target:12,face:6,state:0,input:13,expected:6};
describe('runtime binding boundaries (no real RPC)',()=>{
 it('explicitly reports local mode for a rule without a deployed binding',async()=>{
  const saved=process.env.TINY_LETTER_SUM_ID;delete process.env.TINY_LETTER_SUM_ID;
  try{expect(await runLetterSteps([{...step,target:13}])).toEqual({mode:'local'});}
  finally{if(saved!==undefined)process.env.TINY_LETTER_SUM_ID=saved;}
 });
 it('rejects malformed inputs and configured invalid IDs instead of silently using local mode',async()=>{
  for(const input of [[],[{...step,input:32}],[{...step,state:-1}],[{...step,target:0}]])await expect(runLetterSteps(input)).rejects.toThrow();
  const saved=process.env.TINY_LETTER_SUM_ID;process.env.TINY_LETTER_SUM_ID='not-a-real-id';
  try{await expect(runLetterSteps([step])).rejects.toThrow('正式流片');}
  finally{if(saved===undefined)delete process.env.TINY_LETTER_SUM_ID;else process.env.TINY_LETTER_SUM_ID=saved;}
 });
});
