# -*- coding: utf-8 -*-
"""Use existing local system speech and actual product screenshots, no new dependencies."""
from pathlib import Path
import json,subprocess
root=Path(__file__).resolve().parents[1]
out=root/'outputs/demo-video'
scenes=[
 ('把心意，拼成小礼物','为伴侣、朋友和普通创作者\n不用写代码，从模板开始','home.png','这是一封需要亲手掷骰，才能打开的小情书。小东西制造所，让普通人也能像拼积木一样，做一个可以送给朋友的小惊喜。'),
 ('写下想说的话','编辑称呼、信纸和正文\n挑一个小约定，选一首音乐','composer.png','选一张模板，写下称呼和想说的话，再选择一首轻轻的背景音乐。累计十二点，或者收集三个六，都能成为属于你们的小约定。'),
 ('零件真的连在一起','按钮 → 骰子 → 信封\n拖拽连线，预览和保存','workbench.png','它并不只是一张漂亮的卡片。按钮发出事件，骰子产生点数，连线把结果送进信封的规则。你还可以在工作台继续添加和改造零件。'),
 ('打开链接，就能玩','无需登录、安装或钱包\n网页负责随机数和本机进度','play.png','收件人打开分享链接就能玩，不需要登录、安装应用，或者连接钱包。这里是实际运行后的画面，进度核对成功才会继续。'),
 ('亲手拆开这封信','小游戏制造惊喜\n快照包含明文，不是加密私信','letter.png','条件满足之后，还要由对方亲手拆开信封。普通文字，就变成了一个可以参与的小小期待。需要说明，作品快照包含明文，这并不是加密私信。'),
 ('两枚规则，已正式流片','TapeOut × X Layer\n累计 12 点 #6\n收集三个 6 #7','proof.png','我们已经在主网的共享处理器上，完成两枚正式电路流片。累计十二点是六号电路，收集三个六是七号电路。每枚电路都核对了网表和四十四个状态步骤。'),
 ('每一步，核对正式规则','NAND + LATCH 状态逻辑\n结果不一致就保留上一状态\n不同文案可以复用同一规则','proof.png','标准情书玩法会读取正式电路的运行结果，确认与本地计算一致以后，才提交下一状态。规则由我们提前准备，不同文案可以复用，普通玩家不用自己流片。'),
 ('不止一封情书','爱心打卡机、小习惯工具\n通过作品分享和复制改造触达创作者','checkin.png','同样的积木，还能做一台可以直接按下爱心的打卡机，或者一个小习惯工具。我们从互动礼物开始，通过分享和复制改造，让更多人参与创作。'),
 ('让小心意，继续生长','基础试玩免费\n计划探索主题皮肤、节日模板和创作者模板包\n商业计划，尚未实现收费','home.png','基础试玩目前免费。未来计划探索主题皮肤、节日模板和创作者模板包，这些是计划，还没有实现收费。让可以检查的电路规则，变成每个人都能送出去的小心意。'),
]
result=[]
for i,(title,detail,image,narration) in enumerate(scenes):
 audio=out/('%02d.aiff'%i)
 subprocess.run(['/usr/bin/say','-v','Tingting','-r','230','-o',str(audio),narration],check=True)
 result.append(dict(title=title,detail=detail,image=str(out/image),audio=str(audio),narration=narration))
(out/'scenes.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
(out/'narration.txt').write_text('\n\n'.join(s['narration'] for s in result)+'\n')
print('Prepared %d narration clips; screenshots still require verification before rendering.'%len(result))
