import Foundation
import AppKit
import AVFoundation
import CoreVideo

struct Scene: Decodable {let title:String;let detail:String;let image:String;let audio:String}
@main struct DemoRenderer {
 static let width=1920, height=1080, fps:Int32=15
 static func text(_ text:String,_ rect:CGRect,_ size:CGFloat,_ color:NSColor,_ bold:Bool=false){
  let para=NSMutableParagraphStyle();para.lineSpacing=10
  (text as NSString).draw(in:rect,withAttributes:[.font:NSFont.systemFont(ofSize:size,weight:bold ? .semibold:.regular),.foregroundColor:color,.paragraphStyle:para])
 }
 static func frame(_ scene:Scene,_ number:Int) throws -> CVPixelBuffer {
  var raw:CVPixelBuffer?
  let status=CVPixelBufferCreate(kCFAllocatorDefault,width,height,kCVPixelFormatType_32ARGB,[kCVPixelBufferCGImageCompatibilityKey:true,kCVPixelBufferCGBitmapContextCompatibilityKey:true] as CFDictionary,&raw)
  guard status==kCVReturnSuccess,let buffer=raw else{throw NSError(domain:"video",code:1)}
  CVPixelBufferLockBaseAddress(buffer,[]);defer{CVPixelBufferUnlockBaseAddress(buffer,[])}
  let ctx=CGContext(data:CVPixelBufferGetBaseAddress(buffer),width:width,height:height,bitsPerComponent:8,bytesPerRow:CVPixelBufferGetBytesPerRow(buffer),space:CGColorSpaceCreateDeviceRGB(),bitmapInfo:CGImageAlphaInfo.noneSkipFirst.rawValue)!
  NSGraphicsContext.saveGraphicsState();NSGraphicsContext.current=NSGraphicsContext(cgContext:ctx,flipped:false)
  defer{NSGraphicsContext.restoreGraphicsState()}
  NSColor(red:0.96,green:0.94,blue:1,alpha:1).setFill();ctx.fill(CGRect(x:0,y:0,width:width,height:height))
  let ink=NSColor(red:0.37,green:0.27,blue:0.48,alpha:1)
  text("TINY THINGS  /  小东西制造所",CGRect(x:64,y:980,width:1700,height:56),34,ink,true)
  text("真实产品画面 · X Layer 主网电路 #6 / #7",CGRect(x:64,y:924,width:1600,height:42),25,.secondaryLabelColor)
  let box=CGRect(x:64,y:116,width:1280,height:770)
  NSColor.white.setFill();NSBezierPath(roundedRect:box,xRadius:24,yRadius:24).fill()
  if let image=NSImage(contentsOfFile:scene.image){
   let scale=min((box.width-24)/image.size.width,(box.height-24)/image.size.height)
   let size=CGSize(width:image.size.width*scale,height:image.size.height*scale)
   image.draw(in:CGRect(x:box.midX-size.width/2,y:box.midY-size.height/2,width:size.width,height:size.height))
  }
  text(String(format:"%02d",number+1),CGRect(x:1400,y:810,width:400,height:72),56,NSColor(red:0.62,green:0.48,blue:0.84,alpha:1),true)
  text(scene.title,CGRect(x:1400,y:540,width:440,height:246),54,ink,true)
  text(scene.detail,CGRect(x:1400,y:190,width:440,height:320),31,ink)
  text("TapeOut × X Layer  ·  Product walkthrough  ·  2026-11-12",CGRect(x:64,y:43,width:1800,height:36),24,ink)
  return buffer
 }
 static func main() async throws {
  let args=CommandLine.arguments
  guard args.count==3 else{fatalError("Usage: renderer scenes.json output.mp4")}
  let scenes=try JSONDecoder().decode([Scene].self,from:Data(contentsOf:URL(fileURLWithPath:args[1])))
  let output=URL(fileURLWithPath:args[2]);let silent=output.deletingPathExtension().appendingPathExtension("silent.mp4")
  guard !FileManager.default.fileExists(atPath:output.path),!FileManager.default.fileExists(atPath:silent.path) else{fatalError("Choose a new output version")}
  var durations:[Double]=[]
  for scene in scenes{
   let duration=try await AVURLAsset(url:URL(fileURLWithPath:scene.audio)).load(.duration).seconds
   durations.append(max(9,duration+1.2))
  }
  let total=durations.reduce(0,+)
  guard total<175 else{fatalError("Narration too long: \(total)")}
  let writer=try AVAssetWriter(outputURL:silent,fileType:.mp4)
  let input=AVAssetWriterInput(mediaType:.video,outputSettings:[AVVideoCodecKey:AVVideoCodecType.h264,AVVideoWidthKey:width,AVVideoHeightKey:height,AVVideoCompressionPropertiesKey:[AVVideoAverageBitRateKey:2000000,AVVideoMaxKeyFrameIntervalKey:90]])
  let adaptor=AVAssetWriterInputPixelBufferAdaptor(assetWriterInput:input,sourcePixelBufferAttributes:[kCVPixelBufferPixelFormatTypeKey as String:kCVPixelFormatType_32ARGB,kCVPixelBufferWidthKey as String:width,kCVPixelBufferHeightKey as String:height])
  writer.add(input);guard writer.startWriting() else{throw writer.error!};writer.startSession(atSourceTime:.zero)
  var cursor:Int64=0
  for (i,scene) in scenes.enumerated(){
   let buffer=try frame(scene,i);let count=Int64(ceil(durations[i]*Double(fps)))
   for _ in 0..<count{
    while !input.isReadyForMoreMediaData {try await Task.sleep(nanoseconds:5_000_000)}
    if !adaptor.append(buffer,withPresentationTime:CMTime(value:cursor,timescale:fps)){throw writer.error!};cursor+=1
   }
   durations[i]=Double(count)/Double(fps)
  }
  input.markAsFinished();await writer.finishWriting();guard writer.status == .completed else{throw writer.error!}
  let composition=AVMutableComposition()
  let silentAsset=AVURLAsset(url:silent)
  let video=try await silentAsset.loadTracks(withMediaType:.video).first!
  let duration=CMTime(value:cursor,timescale:fps)
  try composition.addMutableTrack(withMediaType:.video,preferredTrackID:kCMPersistentTrackID_Invalid)!.insertTimeRange(CMTimeRange(start:.zero,duration:duration),of:video,at:.zero)
  let voice=composition.addMutableTrack(withMediaType:.audio,preferredTrackID:kCMPersistentTrackID_Invalid)!
  var time=CMTime.zero
  for (i,scene) in scenes.enumerated(){
   let audio=AVURLAsset(url:URL(fileURLWithPath:scene.audio));let track=try await audio.loadTracks(withMediaType:.audio).first!
   let length=try await audio.load(.duration)
   try voice.insertTimeRange(CMTimeRange(start:.zero,duration:length),of:track,at:time)
   time=CMTimeAdd(time,CMTime(seconds:durations[i],preferredTimescale:600))
  }
  let export=AVAssetExportSession(asset:composition,presetName:AVAssetExportPreset1920x1080)!
  try await export.export(to:output,as:.mp4)
  print("DEMO_RENDERED seconds=\(duration.seconds) bytes=\((try FileManager.default.attributesOfItem(atPath:output.path)[.size])!)")
 }
}
