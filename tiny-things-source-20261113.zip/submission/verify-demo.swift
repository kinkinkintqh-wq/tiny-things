import Foundation
import AVFoundation
import ImageIO
import UniformTypeIdentifiers
@main struct VerifyDemo {
 static func main() async throws {
  let path=CommandLine.arguments[1],dir=CommandLine.arguments[2]
  let asset=AVURLAsset(url:URL(fileURLWithPath:path));let duration=try await asset.load(.duration).seconds
  let video=try await asset.loadTracks(withMediaType:.video).first!
  let size=try await video.load(.naturalSize)
  let audio=try await asset.loadTracks(withMediaType:.audio)
  guard duration>10 && duration<180 && size.width==1920 && size.height==1080 && audio.count==1 else{fatalError("Video acceptance failed")}
  let generator=AVAssetImageGenerator(asset:asset);generator.appliesPreferredTrackTransform=true
  for (i,second) in [2.0,duration*0.3,duration*0.6,duration-3].enumerated(){
   let cg=try generator.copyCGImage(at:CMTime(seconds:second,preferredTimescale:600),actualTime:nil)
   let url=URL(fileURLWithPath:dir).appendingPathComponent("qa-\(i).png")
   let dest=CGImageDestinationCreateWithURL(url as CFURL,UTType.png.identifier as CFString,1,nil)!
   CGImageDestinationAddImage(dest,cg,nil);guard CGImageDestinationFinalize(dest) else{fatalError("Frame export failed")}
  }
  let reader=try AVAssetReader(asset:asset)
  let output=AVAssetReaderTrackOutput(track:audio[0],outputSettings:[AVFormatIDKey:kAudioFormatLinearPCM,AVLinearPCMIsFloatKey:true,AVLinearPCMBitDepthKey:32,AVLinearPCMIsNonInterleaved:false])
  reader.add(output);reader.startReading();var peak:Float=0;var samples=0
  while let sample=output.copyNextSampleBuffer(){
   guard let block=CMSampleBufferGetDataBuffer(sample) else{continue}
   var length=0,total=0;var pointer:UnsafeMutablePointer<Int8>?
   if CMBlockBufferGetDataPointer(block,atOffset:0,lengthAtOffsetOut:&length,totalLengthOut:&total,dataPointerOut:&pointer)==noErr,let pointer=pointer{
    pointer.withMemoryRebound(to:Float.self,capacity:total/4){p in for i in 0..<(total/4){peak=max(peak,abs(p[i]));samples+=1}}
   }
  }
  guard peak>0.001 && samples>100000 else{fatalError("Audio is empty or silent")}
  let result:[String:Any]=["durationSeconds":duration,"width":Int(size.width),"height":Int(size.height),"audioTracks":audio.count,"decodedAudioPeak":peak,"decodedAudioSamples":samples,"framesExported":4,"note":"Visual frames still need human/model inspection; not user acceptance."]
  let data=try JSONSerialization.data(withJSONObject:result,options:[.prettyPrinted,.sortedKeys]);try data.write(to:URL(fileURLWithPath:dir).appendingPathComponent("QA.json"));print(String(data:data,encoding:.utf8)!)
 }
}
