"""Package a relocatable Next standalone runtime. No keys, env files, or Mac binaries."""
from pathlib import Path
import hashlib,json,shutil,tarfile,os,re
ROOT=Path(__file__).resolve().parents[1]
build_name=os.environ.get('TINYTHINGS_BUILD_DIR','.next-mainnet')
version=os.environ.get('TINY_RELEASE_VERSION','20261112-mainnet')
if not re.fullmatch(r'\.next-[a-z0-9-]+',build_name) or not re.fullmatch(r'[a-z0-9-]+',version):raise SystemExit('Invalid release path')
BUILD=ROOT/'apps/web'/build_name
DEST=ROOT/'outputs'/('tiny-things-runtime-'+version)
if DEST.exists():
    raise SystemExit('Release folder already exists; choose a new version instead of overwriting it')
shutil.copytree(BUILD/'standalone',DEST,symlinks=True,ignore=shutil.ignore_patterns('.env*','*.pem','*.key','.DS_Store'))
APP=DEST/'apps/web'
shutil.copytree(ROOT/'apps/web/public',APP/'public')
shutil.copytree(BUILD/'static',APP/build_name/'static')
# images.unoptimized is true. Next returns 404 before calling Sharp on /_next/image.
# Drop optional Mac-only Sharp artifacts; production uses the original static images.
for d in (APP/'node_modules/@img').glob('*darwin*'):
    if d.is_dir():shutil.rmtree(d)
for p in DEST.rglob('*'):
    if p.is_symlink() and not p.resolve().is_relative_to(DEST.resolve()):
        raise SystemExit('Release has an external symlink: '+str(p.relative_to(DEST)))
    if p.is_file() and p.suffix in {'.node','.dylib','.pem','.key'}:
        raise SystemExit('Release has an unexpected native or private file: '+str(p.relative_to(DEST)))
manifest={str(p.relative_to(DEST)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(DEST.rglob('*')) if p.is_file()}
(DEST/'RUNTIME-SHA256.json').write_text(json.dumps(manifest,indent=2)+'\n')
(DEST/'RELEASE.json').write_text(json.dumps({'version':version,'buildId':(BUILD/'BUILD_ID').read_text().strip(),'entry':'apps/web/server.js','requires':'Compatible Linux Node.js 22+; server runtime verification pending','images':'Original static assets; runtime optimization disabled','chainBindings':json.loads((ROOT/'verification/letter-bindings.json').read_text())},indent=2)+'\n')
archive=DEST.with_suffix('.tar.gz')
with tarfile.open(archive,'w:gz') as t:t.add(DEST,arcname=DEST.name)
print(json.dumps({'files':len(manifest),'archive':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}))
