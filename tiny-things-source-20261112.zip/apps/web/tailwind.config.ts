import type { Config } from "tailwindcss";

export default {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        tt: {
          bg: "#F3EEFB",
          panel: "#FFFCFF",
          primary: "#9274DD",
          deep: "#6F52C4",
          ink: "#302740",
          muted: "#71677F",
          border: "#E1D8EE",
          pink: "#F1B0C9",
          blue: "#B8D4F4",
          mint: "#CBE6CF",
          cream: "#F5E6B8",
        },
      },
      fontFamily: {
        sans: [
          "PingFang SC",
          "Hiragino Sans GB",
          "Microsoft YaHei",
          "sans-serif",
        ],
        pixel: ["var(--font-pixel)", "monospace"],
      },
      boxShadow: {
        soft: "0 4px 16px rgba(80, 56, 130, 0.08)",
        panel: "0 10px 30px rgba(80, 56, 130, 0.12)",
      },
      borderRadius: {
        panel: "20px",
        card: "16px",
        btn: "12px",
      },
      keyframes: {
        floaty: {
          "0%, 100%": { transform: "translateY(0px)" },
          "50%": { transform: "translateY(-10px)" },
        },
        softPulse: {
          "0%, 100%": { opacity: "0.55" },
          "50%": { opacity: "1" },
        },
        spark: {
          "0%": { transform: "scale(0.6)", opacity: "0" },
          "40%": { transform: "scale(1.05)", opacity: "1" },
          "100%": { transform: "scale(1)", opacity: "0" },
        },
      },
      animation: {
        floaty: "floaty 5s ease-in-out infinite",
        softPulse: "softPulse 2.4s ease-in-out infinite",
        spark: "spark 0.45s ease-out",
      },
    },
  },
  plugins: [],
} satisfies Config;
