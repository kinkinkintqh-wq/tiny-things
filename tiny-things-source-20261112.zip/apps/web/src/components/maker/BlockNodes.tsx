"use client";

import { Handle, Position, type NodeProps } from "@xyflow/react";
import { getBlock } from "@tinythings/block-registry";
import { PartIcon } from "@/components/VoxelIcons";

export type BlockNodeData = {
  blockType: string;
  label?: string;
  config: Record<string, unknown>;
  runtimeValue?: unknown;
  selectedGlow?: boolean;
};

function hintFor(blockType: string, config: Record<string, unknown>, runtime: unknown) {
  if (blockType === "button") {
    const action = String(config.action ?? "increment");
    const map: Record<string, string> = {
      increment: "点击后 +1",
      toggle: "点击切换开关",
      checkIn: "点击打卡",
      draw: "点击掷骰 / 抽取",
      open: "点击打开信封",
      start: "点击开始计时",
    };
    return map[action] ?? "发出点击";
  }
  if (blockType === "counter") return `当前 ${runtime ?? config.initial ?? 0}`;
  if (blockType === "streakCounter") return `连续 ${runtime ?? 0} 天`;
  if (blockType === "switch") return runtime ? "现在是开" : "现在是关";
  if (blockType === "randomBox") {
    return String(config.mode ?? "list") === "dice" ? "骰子 1–6" : "随机抽取";
  }
  if (blockType === "envelope") {
    const mode = String(config.unlockMode ?? "event");
    if (mode === "signals") return config.signalRule === "sum" ? `累计 ${config.needSignals ?? 12} 点拆信` : `收集 ${config.needSignals ?? 3} 次指定点数`;
    if (mode === "time") return "到日子才开";
    return "收到解锁才开";
  }
  if (blockType === "progress") return `目标 ${config.target ?? 30}`;
  if (blockType === "timer") return `${config.durationSec ?? 60} 秒`;
  if (blockType === "text") return "显示文案";
  if (blockType === "dateGate") return "一天一次";
  if (blockType === "condition") return "条件判断";
  return "";
}

function shortPortLabel(label: string) {
  return label.length > 3 ? label.slice(0, 3) : label;
}

function NodeShell({
  color,
  title,
  subtitle,
  blockType,
  children,
  selected,
  display,
  portRows = 1,
}: {
  color: string;
  title: string;
  subtitle?: string;
  blockType?: string;
  children?: React.ReactNode;
  selected?: boolean;
  display?: string;
  portRows?: number;
}) {
  return (
    <div
      className={`maker-node relative min-h-[108px] w-[220px] rounded-[18px] border-[2.5px] bg-white/95 p-3.5 transition ${
        selected ? "border-tt-primary ring-4 ring-tt-primary/15" : "border-white/90"
      }`}
      style={{
        minHeight: 132 + portRows * 26,
        borderColor: selected ? "#9274DD" : `${color}`,
        boxShadow: `0 6px 0 ${color}cc, 0 12px 22px ${color}33, 0 2px 0 #ffffff inset`,
        background: `linear-gradient(180deg, #ffffff 0%, ${color}22 100%)`,
      }}
    >
      <div className="flex items-center gap-2.5">
        {blockType ? (
          <PartIcon type={blockType} size={40} />
        ) : (
          <span className="inline-block h-10 w-10 rounded-xl" style={{ background: color }} />
        )}
        <div className="min-w-0">
          <div className="truncate text-[15px] font-medium text-tt-ink">{title}</div>
          {subtitle ? (
            <div className="truncate text-[11px] text-tt-muted">{subtitle}</div>
          ) : null}
        </div>
      </div>
      {display != null ? (
        <div className="mt-3 text-[30px] font-semibold leading-none tracking-tight text-tt-ink">
          {display}
        </div>
      ) : null}
      {children}
    </div>
  );
}

export function BlockFlowNode({ data, selected }: NodeProps) {
  const d = data as BlockNodeData;
  const def = getBlock(d.blockType);
  if (!def) {
    return (
      <NodeShell color="#ccc" title={d.blockType} selected={selected}>
        <p className="mt-2 text-xs text-tt-muted">未知零件</p>
      </NodeShell>
    );
  }

  const display =
    d.blockType === "counter"
      ? String(d.runtimeValue ?? d.config.initial ?? 0)
      : d.blockType === "button"
        ? String(d.config.label ?? def.label)
        : d.blockType === "streakCounter"
          ? `${d.runtimeValue ?? 0} 天`
          : d.blockType === "switch"
            ? d.runtimeValue
              ? "开"
              : "关"
            : d.blockType === "randomBox" && d.runtimeValue != null
              ? String(d.runtimeValue)
              : undefined;

  const inCount = Math.max(def.inputPorts.length, 1);
  const outCount = Math.max(def.outputPorts.length, 1);
  const portTop = (i: number) =>
    140 + i * 26;

  return (
    <NodeShell
      color={def.color}
      title={d.label ?? def.label}
      subtitle={hintFor(d.blockType, d.config ?? {}, d.runtimeValue)}
      blockType={d.blockType}
      selected={selected}
      display={display}
      portRows={Math.max(inCount, outCount)}
    >
      {def.inputPorts.map((p, i) => {
        const top = portTop(i);
        return (
          <span key={`in-${p.id}`}>
            <Handle
              id={p.id}
              type="target"
              position={Position.Left}
              style={{ top }}
              className="!h-3.5 !w-3.5 !border-2 !border-tt-primary !bg-white"
              title={`${p.label} · ${p.valueType}`}
            />
            <span
              className="pointer-events-none absolute left-3 -translate-y-1/2 rounded bg-white/95 px-1 py-0.5 text-[10px] font-medium leading-none text-tt-muted shadow-soft"
              style={{ top }}
            >
              {shortPortLabel(p.label)}
            </span>
          </span>
        );
      })}
      {def.outputPorts.map((p, i) => {
        const top = portTop(i);
        return (
          <span key={`out-${p.id}`}>
            <Handle
              id={p.id}
              type="source"
              position={Position.Right}
              style={{ top }}
              className="!h-3.5 !w-3.5 !border-2 !border-tt-primary !bg-tt-primary"
              title={`${p.label} · ${p.valueType}`}
            />
            <span
              className="pointer-events-none absolute right-3 -translate-y-1/2 rounded bg-white/95 px-1 py-0.5 text-[10px] font-medium leading-none text-tt-muted shadow-soft"
              style={{ top }}
            >
              {shortPortLabel(p.label)}
            </span>
          </span>
        );
      })}
    </NodeShell>
  );
}

export const nodeTypes = { block: BlockFlowNode };
