"use client";

import {
  Background,
  Controls,
  ReactFlow,
  ReactFlowProvider,
  addEdge,
  useEdgesState,
  useNodesState,
  useReactFlow,
  type Connection,
  type Edge,
  type Node,
  type OnSelectionChangeParams,
} from "@xyflow/react";
import "@xyflow/react/dist/style.css";
import {
  getBlock,
  listBlocks,
  validateConnection,
  wouldCreateCycle,
  TEMPLATES,
  draftFromTemplate,
} from "@tinythings/block-registry";
import type { DesignGraph, DraftPayload } from "@tinythings/schema";
import { compileGraph, supportedLetterRule } from "@tinythings/compiler";
import { RuntimeSession } from "@tinythings/runtime";
import { nanoid } from "nanoid";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { TapeoutCostPanel } from "@/components/TapeoutCostPanel";
import { PartIcon } from "@/components/VoxelIcons";
import { nodeTypes, type BlockNodeData } from "./BlockNodes";
import { LoveLetterComposer } from "./LoveLetterComposer";
import { PreviewPlayer } from "./PreviewPlayer";
import { toast } from "@/lib/toast";
import { downloadDesign, parseDesign } from "@/lib/portable";

const EVENT_EDGE = { stroke: "#9274DD", strokeWidth: 2.5 };
const DATA_EDGE = { stroke: "#7BA6D6", strokeWidth: 2, strokeDasharray: "6 4" };

function edgeStyleFor(kind: string, highlight = false) {
  const base = kind === "data" || kind === "state" ? DATA_EDGE : EVENT_EDGE;
  if (!highlight) return base;
  return { ...base, strokeWidth: (base.strokeWidth ?? 2) + 1.5, stroke: "#6F52C4" };
}

/** Spread template nodes so wires are less tangled. */
function spreadPositions(graph: DesignGraph): DesignGraph {
  const depth = new Map(graph.nodes.map((n) => [n.id, 0]));
  const degree = new Map(graph.nodes.map((n) => [n.id, graph.edges.filter((e) => e.target === n.id).length]));
  const queue = graph.nodes.filter((n) => degree.get(n.id) === 0).map((n) => n.id);
  while (queue.length) {
    const id = queue.shift()!;
    for (const edge of graph.edges.filter((e) => e.source === id)) {
      depth.set(edge.target, Math.max(depth.get(edge.target) ?? 0, (depth.get(id) ?? 0) + 1));
      degree.set(edge.target, (degree.get(edge.target) ?? 1) - 1);
      if (degree.get(edge.target) === 0) queue.push(edge.target);
    }
  }
  const rows = new Map<number, number>();
  return { ...graph, nodes: graph.nodes.map((n) => {
    const col = depth.get(n.id) ?? 0;
    const row = rows.get(col) ?? 0;
    rows.set(col, row + 1);
    return { ...n, position: { x: 50 + col * 300, y: 80 + row * 280 } };
  }) };

}

function toFlow(graph: DesignGraph): { nodes: Node[]; edges: Edge[] } {
  return {
    nodes: graph.nodes.map((n) => ({
      id: n.id,
      type: "block",
      position: n.position,
      data: {
        blockType: n.type,
        config: n.config,
        label: getBlock(n.type)?.label,
      } satisfies BlockNodeData,
    })),
    edges: graph.edges.map((e) => ({
      id: e.id,
      source: e.source,
      target: e.target,
      sourceHandle: e.sourcePort,
      targetHandle: e.targetPort,
      animated: e.kind === "event",
      style: edgeStyleFor(e.kind),
      data: { kind: e.kind },
    })),
  };
}

function fromFlow(
  nodes: Node[],
  edges: Edge[],
  prev: DesignGraph
): DesignGraph {
  return {
    ...prev,
    nodes: nodes.map((n) => {
      const data = n.data as BlockNodeData;
      const existing = prev.nodes.find((x) => x.id === n.id);
      return {
        id: n.id,
        type: data.blockType,
        version: existing?.version ?? "1.0.0",
        config: data.config ?? {},
        position: n.position,
      };
    }),
    edges: edges.map((e) => {
      const existing = prev.edges.find((x) => x.id === e.id);
      const sourcePort = String(e.sourceHandle ?? "out");
      const targetPort = String(e.targetHandle ?? "in");
      const sDef = getBlock(
        (nodes.find((n) => n.id === e.source)?.data as BlockNodeData)?.blockType ?? ""
      );
      const kind =
        existing?.kind ??
        sDef?.outputPorts.find((p) => p.id === sourcePort)?.kind ??
        "event";
      return {
        id: e.id,
        source: e.source,
        target: e.target,
        sourcePort,
        targetPort,
        kind,
      };
    }),
  };
}

const STARTERS = [
  {
    id: "daily-checkin",
    name: "每日打卡器",
    blurb: "粉色小设备 · 一天一次",
    accent: "#F1B0C9",
  },
  {
    id: "love-letter",
    name: "给 TA 一封小情书",
    blurb: "掷骰解锁 · 藏一句喜欢你",
    accent: "#F5E6B8",
  },
  {
    id: "habit-builder",
    name: "习惯养成",
    blurb: "按钮 + 计数 + 进度条",
    accent: "#B8D4F4",
  },
] as const;

function ActionChip({
  active,
  label,
  onClick,
}: {
  active: boolean;
  label: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`w-full rounded-[14px] border px-3 py-2.5 text-left text-sm transition ${
        active
          ? "border-tt-primary bg-tt-primary/12 text-tt-deep shadow-soft"
          : "border-tt-border/70 bg-white/80 text-tt-ink hover:border-tt-primary/40"
      }`}
    >
      {label}
    </button>
  );
}

function MakerInner({
  draft,
  onChange,
  onPublish,
  saving,
  saveStatus,
}: {
  draft: DraftPayload & { id: string };
  onChange: (next: DraftPayload) => void;
  onSave: () => void;
  onPublish: () => void;
  saving?: boolean;
  saveStatus?: string;
}) {
  const initial = useRef(toFlow(draft.graph)).current;
  const [nodes, setNodes, onNodesChange] = useNodesState(initial.nodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(initial.edges);
  const [tab, setTab] = useState<"parts" | "templates">("parts");
  const [selected, setSelected] = useState<Node | null>(null);
  const [name, setName] = useState(draft.name);
  const [previewOpen, setPreviewOpen] = useState(false);
  const [loveOpen, setLoveOpen] = useState(false);
  useEffect(() => {
    const url = new URL(window.location.href);
    if (url.searchParams.get("write") === "1") {
      setLoveOpen(true);
      url.searchParams.delete("write");
      window.history.replaceState(window.history.state, "", url);
    }
  }, []);
  const [runtimeView, setRuntimeView] = useState<Record<string, Record<string, unknown>>>({});
  const [previewFlash, setPreviewFlash] = useState<string | null>(null);
  const [compileReport, setCompileReport] = useState<string>("本地可运行 · 拖拽与预览可用");
  const [canCompile, setCanCompile] = useState(false);
  const [circuitOpen, setCircuitOpen] = useState(false);
  const [mobilePartsOpen, setMobilePartsOpen] = useState(false);
  const [mobileSettingsOpen, setMobileSettingsOpen] = useState(false);
  const [previewOpening, setPreviewOpening] = useState(false);
  const [hintDismissed, setHintDismissed] = useState(draft.graph.nodes.length > 0);
  const history = useRef<DesignGraph[]>([]);
  const future = useRef<DesignGraph[]>([]);
  const { screenToFlowPosition, fitView } = useReactFlow();
  const sessionRef = useRef<RuntimeSession | null>(null);
  const dragSyncTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const pushHistory = useCallback((g: DesignGraph) => {
    history.current = [...history.current.slice(-99), structuredClone(g)];
    future.current = [];
  }, []);

  const emitGraph = useCallback(
    (n: Node[], e: Edge[], opts?: { record?: boolean }) => {
      const graph = fromFlow(n, e, draft.graph);
      if (opts?.record !== false) pushHistory(draft.graph);
      onChange({ ...draft, name, graph });
      try {
        const compiled = compileGraph(graph);
        if (compiled.netlist) {
          setCanCompile(true);
          setCompileReport(
            `本地 NAND · ${compiled.report.gateCount} NAND / 深度 ${compiled.report.depth}`
          );
        } else {
          setCanCompile(graph.nodes.some(n => n.type === "envelope" && supportedLetterRule(n.config)));
          setCompileReport(graph.nodes.some(n => n.type === "envelope" && supportedLetterRule(n.config)) ? "情书规则已编译 · NAND ＋ LATCH · 本地运行" : "网页可运行 · 此组合暂不支持 NAND");
        }
      } catch {
        setCanCompile(false);
        setCompileReport("本地可运行 · 拖拽与预览可用");
      }
    },
    [draft, name, onChange, pushHistory]
  );

  useEffect(() => {
    const result = compileGraph(draft.graph);
    const hasLetter = draft.graph.nodes.some(n => n.type === "envelope" && supportedLetterRule(n.config));
    setCanCompile(Boolean(result.netlist) || hasLetter);
    setCompileReport(result.netlist ? `本地 NAND · ${result.report.gateCount} 门 / 深度 ${result.report.depth}` : hasLetter ? "情书规则已编译 · NAND ＋ LATCH · 本地运行" : "网页可运行 · 此组合暂不支持 NAND");
  }, [draft.graph]);

  const isValidConnection = useCallback(
    (connection: Connection | Edge) => {
      const graph = fromFlow(nodes, edges, draft.graph);
      const sourcePort = String(connection.sourceHandle ?? "");
      const sDef = getBlock(
        (nodes.find((n) => n.id === connection.source)?.data as BlockNodeData)
          ?.blockType ?? ""
      );
      const kind =
        (sDef?.outputPorts.find((p) => p.id === sourcePort)?.kind as
          | "event"
          | "data"
          | "state"
          | undefined) ?? "event";
      const edge = {
        id: "tmp",
        source: connection.source!,
        target: connection.target!,
        sourcePort,
        targetPort: String(connection.targetHandle ?? ""),
        kind,
      };
      const issue = validateConnection(graph, edge);
      if (issue) return false;
      if (wouldCreateCycle(graph, edge)) return false;
      return true;
    },
    [nodes, edges, draft.graph]
  );

  const onConnect = useCallback(
    (connection: Connection) => {
      if (!isValidConnection(connection)) {
        toast("这两端接不上，换个圆点试试", "error");
        return;
      }
      const next = addEdge(
        {
          ...connection,
          id: `e_${nanoid(6)}`,
          animated: getBlock((nodes.find((n) => n.id === connection.source)?.data as BlockNodeData)?.blockType)?.outputPorts.find((p) => p.id === connection.sourceHandle)?.kind === "event",
          data: { kind: getBlock((nodes.find((n) => n.id === connection.source)?.data as BlockNodeData)?.blockType)?.outputPorts.find((p) => p.id === connection.sourceHandle)?.kind ?? "event" },
        },
        edges
      );
      setEdges(next);
      emitGraph(nodes, next);
      toast("连上了，点预览就能玩", "ok");
    },
    [edges, nodes, setEdges, emitGraph, isValidConnection]
  );

  const addBlock = useCallback(
    (type: string, position?: { x: number; y: number }) => {
      const def = getBlock(type);
      if (!def) return;
      const id = `${type}_${nanoid(5)}`;
      const node: Node = {
        id,
        type: "block",
        position: position ?? {
          x: 180 + Math.random() * 120,
          y: 120 + Math.random() * 100,
        },
        data: {
          blockType: type,
          config: structuredClone(def.defaultConfig),
          label: def.label,
        } satisfies BlockNodeData,
      };
      const next = [...nodes, node];
      setNodes(next);
      emitGraph(next, edges);
      setSelected(node);
      setHintDismissed(true);
      setMobilePartsOpen(false);
      toast(`已放入「${def.label}」`, "ok");
    },
    [nodes, edges, setNodes, emitGraph]
  );

  const onDrop = useCallback(
    (event: React.DragEvent) => {
      event.preventDefault();
      const type = event.dataTransfer.getData("application/tinythings-block");
      if (!type) return;
      const position = screenToFlowPosition({
        x: event.clientX,
        y: event.clientY,
      });
      addBlock(type, position);
    },
    [screenToFlowPosition, addBlock]
  );

  const onSelectionChange = useCallback((p: OnSelectionChangeParams) => {
    const node = p.nodes[0] ?? null;
    setSelected(node);
    if (node && typeof window !== "undefined" && window.innerWidth < 768) {
      setMobileSettingsOpen(true);
    }
  }, []);

  const updateSelectedConfig = (key: string, value: unknown) => {
    if (!selected) return;
    const next = nodes.map((n) =>
      n.id === selected.id
        ? {
            ...n,
            data: {
              ...(n.data as BlockNodeData),
              config: { ...(n.data as BlockNodeData).config, [key]: value },
            },
          }
        : n
    );
    setNodes(next);
    setSelected(next.find((n) => n.id === selected.id) ?? null);
    emitGraph(next, edges);
  };

  const applyActionEdge = (action: string, targetNodeId: string) => {
    if (!selected) return;
    const targetPort =
      action === "increment"
        ? "increment"
        : action === "toggle"
          ? "toggle"
          : action === "checkIn"
            ? "attempt"
            : action === "draw"
              ? "draw"
              : action === "start"
                ? "start"
                : action === "open"
                  ? "open"
                  : "increment";
    const cleaned = edges.filter((e) => e.source !== selected.id);
    const edge: Edge = {
      id: `e_${nanoid(6)}`,
      source: selected.id,
      target: targetNodeId,
      sourceHandle: "click",
      targetHandle: targetPort,
      animated: true,
      style: edgeStyleFor("event"),
      data: { kind: "event" },
    };
    const nextEdges = [...cleaned, edge];
    const nextNodes = nodes.map((n) =>
      n.id === selected.id
        ? {
            ...n,
            data: {
              ...(n.data as BlockNodeData),
              config: {
                ...(n.data as BlockNodeData).config,
                action,
                targetNodeId,
              },
            },
          }
        : n
    );
    setNodes(nextNodes);
    setEdges(nextEdges);
    emitGraph(nextNodes, nextEdges);
  };

  const undo = () => {
    const prev = history.current.pop();
    if (!prev) return;
    future.current.push(structuredClone(draft.graph));
    const flow = toFlow(prev);
    setNodes(flow.nodes);
    setEdges(flow.edges);
    onChange({ ...draft, name, graph: prev });
  };

  const redo = () => {
    const next = future.current.pop();
    if (!next) return;
    history.current.push(structuredClone(draft.graph));
    const flow = toFlow(next);
    setNodes(flow.nodes);
    setEdges(flow.edges);
    onChange({ ...draft, name, graph: next });
  };

  const loadTemplate = useCallback(
    (templateId: string, displayName: string, toastMsg: string, openPreview = false) => {
      pushHistory(fromFlow(nodes, edges, draft.graph));
      const template = draftFromTemplate(templateId);
      const g = spreadPositions(template.graph);
      const flow = toFlow(g);
      setNodes(flow.nodes);
      setEdges(flow.edges);
      setName(displayName);
      onChange({ ...draft, name: displayName, graph: g, theme: { ...draft.theme, ...template.theme } });
      setHintDismissed(true);
      setSelected(null);
      setMobilePartsOpen(false);
      setMobileSettingsOpen(false);
      toast(toastMsg, "ok");
      window.setTimeout(() => { void fitView({ padding: 0.18, duration: 300 }); }, 150);
      if (openPreview) {
        setPreviewOpening(true);
        window.setTimeout(() => {
          try {
            sessionRef.current = new RuntimeSession(g, {
              timezone: "Asia/Shanghai",
              seed: crypto.getRandomValues(new Uint32Array(1))[0],
            });
            const states = sessionRef.current.getSnapshot().states as Record<
              string,
              Record<string, unknown>
            >;
            setRuntimeView(states);
            setPreviewFlash("模板已就绪，先玩玩看");
            setPreviewOpen(true);
          } catch {
            /* ignore */
          } finally {
            setPreviewOpening(false);
          }
        }, 360);
      }
    },
    [draft, nodes, edges, onChange, setNodes, setEdges, fitView, pushHistory]
  );

  const applyRuntimeToNodes = (states: Record<string, Record<string, unknown>>) => {
    setNodes((curr) =>
      curr.map((n) => {
        const st = states[n.id];
        let runtimeValue: unknown = undefined;
        if (st) {
          if ("value" in st) runtimeValue = st.value;
          else if ("streak" in st) runtimeValue = st.streak;
          else if ("on" in st) runtimeValue = st.on;
          else if ("last" in st) runtimeValue = st.last;
        }
        return {
          ...n,
          data: { ...(n.data as BlockNodeData), runtimeValue },
        };
      })
    );
  };

  const runPreview = () => {
    if (previewOpening || previewOpen) return;
    try {
      const graph = fromFlow(nodes, edges, draft.graph);
      if (graph.nodes.length === 0) {
        toast("画布还是空的，先选一个模板吧", "info");
        setHintDismissed(false);
        return;
      }
      setPreviewOpening(true);
      sessionRef.current = new RuntimeSession(graph, {
        timezone: "Asia/Shanghai",
        seed: crypto.getRandomValues(new Uint32Array(1))[0],
      });
      const states = sessionRef.current.getSnapshot().states as Record<
        string,
        Record<string, unknown>
      >;
      setRuntimeView(states);
      setPreviewFlash(null);
      applyRuntimeToNodes(states);
      window.setTimeout(() => {
        setPreviewOpen(true);
        setPreviewOpening(false);
      }, 120);
    } catch (err) {
      console.error("[preview]", err);
      setPreviewOpening(false);
      toast(err instanceof Error ? err.message : "预览失败", "error");
    }
  };

  const tickPreview = (nodeId: string, port: string) => {
    if (!sessionRef.current) return;
    sessionRef.current.updateTime(Date.now());
    const before = sessionRef.current.getSnapshot().states as Record<
      string,
      Record<string, unknown>
    >;
    const snap = sessionRef.current.tick({
      eventId: `pv_${nanoid(8)}`,
      nodeId,
      port,
    });
    if (snap.errors.length) toast(snap.errors.join("；"), "error");
    const states = snap.states as Record<string, Record<string, unknown>>;
    setRuntimeView(states);
    applyRuntimeToNodes(states);

    let message: string | null = null;
    for (const [id, st] of Object.entries(states)) {
      const prev = before[id] ?? {};
      if ("streak" in st && Number(st.streak) > Number(prev.streak ?? 0)) {
        message = `打卡成功 · 连续 ${st.streak} 天，真棒`;
        break;
      }
      if (
        "value" in st &&
        Number(st.value) !== Number(prev.value ?? Number.NaN) &&
        !("ratio" in st)
      ) {
        message = `计数变成 ${st.value} 啦`;
      }
      if ("ratio" in st && Number(st.ratio) !== Number(prev.ratio ?? Number.NaN)) {
        message = st.done ? "目标达成，轻轻庆祝一下" : `进度 ${st.ratio}%`;
      }
      if ("last" in st && st.last && st.last !== prev.last) {
        message = `掷出「${String(st.last)}」`;
      }
      if (
        "signalCount" in st &&
        Number(st.signalCount) > Number(prev.signalCount ?? 0)
      ) {
        const need = Number(st.need ?? 3);
        message = st.unlocked
          ? "条件达成，可以读信了"
          : `凑齐中 ${st.signalCount}/${need}`;
      }
      if ("on" in st && st.on !== prev.on) {
        message = st.on ? "开关亮起来了" : "开关安静下来了";
      }
      if ("remaining" in st && st.deadline != null && prev.deadline == null) {
        message = "计时开始，慢慢来";
      }
      if ("opened" in st && st.opened && !prev.opened) {
        message = "信封打开了";
      } else if ("unlocked" in st && !st.unlocked && port === "open") {
        message = "还没解锁，先完成条件";
      }
    }
    if (!message) {
      const hasGate = nodes.some(
        (n) => (n.data as BlockNodeData).blockType === "dateGate"
      );
      message =
        hasGate && port === "press"
          ? "今天已经温柔地打过卡啦"
          : "收到啦";
    }
    setPreviewFlash(message);
  };

  const resetPreview = () => {
    sessionRef.current = new RuntimeSession(fromFlow(nodes, edges, draft.graph), {
      timezone: "Asia/Shanghai",
      seed: crypto.getRandomValues(new Uint32Array(1))[0],
    });
    const states = sessionRef.current.getSnapshot().states as Record<
      string,
      Record<string, unknown>
    >;
    setRuntimeView(states);
    setPreviewFlash(null);
    applyRuntimeToNodes(states);
  };

  useEffect(() => {
    if (!previewOpen) return;
    const id = window.setInterval(() => {
      const rt = sessionRef.current;
      if (!rt) return;
      const before = rt.getSnapshot().revision;
      const snap = rt.updateTime(Date.now());
      if (snap.errors.length) { setPreviewFlash(snap.errors.join("；")); return; }
      if (snap.revision !== before) { setRuntimeView(snap.states); applyRuntimeToNodes(snap.states); }
    }, 250);
    return () => clearInterval(id);
  // The preview locks the graph until closed.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [previewOpen]);

  async function importDesign(file: File) {
    try {
      if (file.size > 500_000) throw new Error("作品文件超过 500 KB");
      const value = parseDesign(JSON.parse(await file.text()));
      pushHistory(fromFlow(nodes, edges, draft.graph));
      const flow = toFlow(value.graph);
      setNodes(flow.nodes); setEdges(flow.edges); setName(value.name); setSelected(null);
      onChange({ ...value, revision: draft.revision });
      requestAnimationFrame(() => fitView({ padding: 0.25 }));
      toast("作品已导入并保存到本机", "ok");
    } catch (err) { toast(err instanceof Error ? err.message : "作品格式无效", "error"); }
  }

  const parts = listBlocks().filter(
    (b) => b.group === "core" || b.group === "extended" || b.group === "rule"
  );
  const selectedData = selected ? (selected.data as BlockNodeData) : null;
  const selectedDef = selectedData ? getBlock(selectedData.blockType) : null;
  const empty = nodes.length === 0;
  const canWriteLetter = empty || (nodes.some((n) => (n.data as BlockNodeData).blockType === "envelope") && nodes.some((n) => (n.data as BlockNodeData).blockType === "randomBox"));
  const showEmptyHero = empty && !hintDismissed;

  const styledEdges = useMemo(() => {
    const selId = selected?.id;
    return edges.map((e) => {
      const kind = String((e.data as { kind?: string } | undefined)?.kind ?? "event");
      const highlight = Boolean(selId && (e.source === selId || e.target === selId));
      return {
        ...e,
        animated: kind === "event",
        style: edgeStyleFor(kind, highlight),
        zIndex: highlight ? 3 : 1,
      };
    });
  }, [edges, selected?.id]);

  const statusHint = useMemo(() => {
    if (empty) return "从左侧拖零件，或点一个模板开始";
    if (edges.length === 0) return "把右侧圆点拖到下一个零件的端口，连上才有玩法";
    if (!selected) return "点选零件可在右侧改文字与行为 · 顶栏预览可试玩";
    return `正在编辑「${selectedDef?.label ?? "零件"}」`;
  }, [empty, edges.length, selected, selectedDef?.label]);

  const PartsGrid = (
    <div className="grid grid-cols-2 gap-2.5">
      {parts.map((p) => (
        <button
          key={p.type}
          draggable
          onDragStart={(e) =>
            e.dataTransfer.setData("application/tinythings-block", p.type)
          }
          onClick={() => addBlock(p.type)}
          className="group flex h-[92px] flex-col items-center justify-center rounded-[16px] border border-tt-border/60 bg-white/85 p-2 text-center transition hover:-translate-y-0.5 hover:border-tt-primary/35 hover:shadow-soft active:translate-y-0"
        >
          <PartIcon type={p.type} size={44} />
          <span className="mt-1 text-xs font-medium text-tt-ink">{p.label}</span>
        </button>
      ))}
    </div>
  );

  const TemplatesList = (
    <div className="space-y-2">
      {TEMPLATES.map((t) => (
        <button
          key={t.id}
          className="w-full rounded-[16px] border border-tt-border/70 bg-white/85 p-3 text-left transition hover:-translate-y-0.5 hover:border-tt-primary/40 hover:shadow-soft"
          onClick={() => loadTemplate(t.id, t.name, `已套用「${t.name}」`, true)}
        >
          <div className="text-sm font-medium text-tt-ink">{t.name}</div>
          <div className="mt-0.5 text-xs leading-5 text-tt-muted">{t.description}</div>
        </button>
      ))}
    </div>
  );

  return (
    <div className="flex h-[calc(100vh-56px)] flex-col">
      <div className="relative z-30 flex h-16 shrink-0 items-center gap-2 border-b border-tt-border/70 bg-tt-panel/95 px-3 backdrop-blur-md md:gap-3 md:px-4">
        <div className="hidden rounded-[12px] bg-tt-bg/90 p-1 text-sm md:flex">
          <button
            type="button"
            className={`rounded-[10px] px-3 py-1.5 transition ${
              tab === "parts" ? "bg-white text-tt-ink shadow-soft" : "text-tt-muted"
            }`}
            onClick={() => setTab("parts")}
          >
            基础零件
          </button>
          <button
            type="button"
            className={`rounded-[10px] px-3 py-1.5 transition ${
              tab === "templates" ? "bg-white text-tt-ink shadow-soft" : "text-tt-muted"
            }`}
            onClick={() => setTab("templates")}
          >
            组合模板
          </button>
        </div>

        <input
          className="tt-input min-w-0 flex-1 max-w-[160px] border-transparent bg-transparent px-2 font-medium shadow-none focus:border-tt-border focus:bg-white/80 md:max-w-[240px]"
          value={name}
          maxLength={40}
          aria-label="作品名称"
          onChange={(e) => {
            setName(e.target.value);
            onChange({ ...draft, name: e.target.value });
          }}
        />
        <span className="hidden text-xs text-tt-muted sm:inline">
          {saveStatus ?? (saving ? "保存中…" : "已保存到本机")}
        </span>

        <div className="ml-auto flex items-center gap-1.5 md:gap-2">
          {canWriteLetter && <button type="button" className="hidden h-10 rounded-[12px] bg-[#f6d7e3] px-3 text-sm text-[#9c637f] lg:inline-flex items-center whitespace-nowrap" onClick={() => setLoveOpen(true)}>♡ 写封情书</button>}
          <label className="tt-btn-secondary hidden h-10 cursor-pointer px-3 lg:inline-flex">
            导入<input aria-label="导入作品" type="file" accept=".json" className="hidden" onChange={(e) => { const file = e.target.files?.[0]; if (file) void importDesign(file); e.target.value = ""; }} />
          </label>
          <button className="tt-btn-secondary hidden h-10 px-3 lg:inline-flex" onClick={() => { try { downloadDesign({ ...draft, name, graph: fromFlow(nodes, edges, draft.graph) }); } catch (err) { toast(err instanceof Error ? err.message : "导出失败", "error"); } }}>导出</button>

          <button
            type="button"
            className="tt-btn-secondary h-10 px-3"
            onClick={undo}
            title="撤销"
          >
            撤销
          </button>
          <button
            type="button"
            className="tt-btn-secondary hidden h-10 px-3 md:inline-flex"
            onClick={redo}
            title="重做"
          >
            重做
          </button>
          <button
            type="button"
            data-testid="maker-preview"
            aria-label="预览"
            disabled={previewOpening}
            className="h-10 rounded-[12px] bg-[#F1B0C9] px-4 text-sm font-medium text-tt-ink shadow-soft transition hover:-translate-y-0.5 disabled:opacity-60"
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              runPreview();
            }}
          >
            {previewOpening ? "打开中…" : "预览"}
          </button>
          <button type="button" className="tt-btn h-10 px-4" onClick={onPublish}>
            保存 / 分享
          </button>
        </div>
      </div>

      <div className="grid min-h-0 flex-1 grid-cols-1 gap-3 p-3 md:grid-cols-[180px_minmax(0,1fr)_240px] xl:grid-cols-[208px_minmax(0,1fr)_280px] md:gap-4 md:p-4">
        <aside className="tt-panel hidden overflow-auto p-3 md:block">
          <div className="mb-3 text-[11px] font-medium tracking-wide text-tt-muted">
            {tab === "parts" ? "拖到画布，或点一下放入" : "一键套用，马上能预览"}
          </div>
          {tab === "parts" ? PartsGrid : TemplatesList}
        </aside>

        <section className="relative min-h-[420px] overflow-hidden rounded-[20px] border border-tt-border/80 bg-[#fbf8ff] shadow-[inset_0_1px_0_#ffffffaa]">
          {!showEmptyHero && (
            <div className="pointer-events-none absolute left-3 right-3 top-3 z-10 hidden justify-center md:flex">
              <div className="pointer-events-auto inline-flex max-w-full items-center gap-2 rounded-full border border-white/80 bg-white/90 px-3.5 py-1.5 text-xs text-tt-muted shadow-soft backdrop-blur">
                <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-tt-primary animate-softPulse" />
                <span className="truncate">{statusHint}</span>
              </div>
            </div>
          )}

          {showEmptyHero && (
            <div className="absolute inset-0 z-20 flex items-center justify-center bg-[radial-gradient(circle_at_50%_30%,#ffffffcc,transparent_60%)] p-4">
              <div className="maker-empty w-full max-w-xl rounded-[24px] border border-white/90 bg-tt-panel/95 p-5 shadow-panel backdrop-blur-md md:p-6">
                <div className="text-center">
                  <div className="text-[11px] tracking-[0.18em] text-tt-muted">
                    60 秒上手
                  </div>
                  <h2 className="mt-1 text-xl font-semibold text-tt-ink md:text-2xl">
                    先做一个会动的小东西
                  </h2>
                  <p className="mt-2 text-sm leading-6 text-tt-muted">
                    选模板立刻能玩；也可以自己拖零件、接线、改文字。
                  </p>
                </div>
                <div className="mt-5 grid gap-3 sm:grid-cols-3">
                  {STARTERS.map((s) => (
                    <button
                      key={s.id}
                      type="button"
                      onClick={() =>
                        loadTemplate(s.id, s.name, `已放入「${s.name}」`, true)
                      }
                      className="rounded-[18px] border border-tt-border/70 bg-white/90 p-4 text-left transition hover:-translate-y-1 hover:shadow-panel"
                      style={{
                        boxShadow: `0 10px 24px ${s.accent}55`,
                      }}
                    >
                      <div
                        className="mb-3 h-10 w-10 rounded-2xl"
                        style={{ background: s.accent }}
                      />
                      <div className="text-sm font-medium text-tt-ink">{s.name}</div>
                      <div className="mt-1 text-[11px] leading-4 text-tt-muted">
                        {s.blurb}
                      </div>
                    </button>
                  ))}
                </div>
                <div className="mt-4 flex flex-wrap items-center justify-between gap-2">
                  <button
                    type="button"
                    className="text-xs text-tt-muted underline-offset-2 hover:underline"
                    onClick={() => setHintDismissed(true)}
                  >
                    我自己从空白开始
                  </button>
                  <button
                    type="button"
                    className="tt-btn-secondary h-9 text-sm md:hidden"
                    onClick={() => setMobilePartsOpen(true)}
                  >
                    打开零件库
                  </button>
                </div>
              </div>
            </div>
          )}

          {canWriteLetter && <button type="button" className="absolute right-3 top-3 z-20 rounded-full bg-[#e8bbcf] px-3.5 py-2 text-xs text-[#84506c] shadow-soft lg:hidden" onClick={() => setLoveOpen(true)}>♡ 写封情书</button>}
          <ReactFlow
            nodes={nodes}
            edges={styledEdges}
            onNodesChange={onNodesChange}
            onEdgesChange={(c) => {
              onEdgesChange(c);
              if (dragSyncTimer.current) clearTimeout(dragSyncTimer.current);
              dragSyncTimer.current = setTimeout(() => {
                setEdges((cedges) => {
                  setNodes((cnodes) => {
                    emitGraph(cnodes, cedges, { record: false });
                    return cnodes;
                  });
                  return cedges;
                });
              }, 50);
            }}
            onNodeDragStop={(_e, node) => {
              setNodes((curr) => {
                const next = curr.map((n) =>
                  n.id === node.id ? { ...n, position: node.position } : n
                );
                emitGraph(next, edges, { record: false });
                return next;
              });
            }}
            onConnect={onConnect}
            isValidConnection={isValidConnection}
            onSelectionChange={onSelectionChange}
            nodeTypes={nodeTypes}
            fitView
            fitViewOptions={{ padding: 0.18, minZoom: 0.55, maxZoom: 1 }}
            minZoom={0.25}
            maxZoom={2}
            snapToGrid
            snapGrid={[20, 20]}
            defaultEdgeOptions={{
              animated: true,
              style: EVENT_EDGE,
            }}
            onDragOver={(e) => {
              e.preventDefault();
              e.dataTransfer.dropEffect = "move";
            }}
            onDrop={onDrop}
            deleteKeyCode={["Backspace", "Delete"]}
            onNodesDelete={(deleted) => {
              const ids = new Set(deleted.map((n) => n.id));
              const nextNodes = nodes.filter((n) => !ids.has(n.id));
              const nextEdges = edges.filter(
                (e) => !ids.has(e.source) && !ids.has(e.target)
              );
              setNodes(nextNodes);
              setEdges(nextEdges);
              emitGraph(nextNodes, nextEdges);
              setSelected(null);
            }}
            className="bg-[linear-gradient(#ebe3f5_1px,transparent_1px),linear-gradient(90deg,#ebe3f5_1px,transparent_1px)] bg-[size:20px_20px]"
          >
            <Background gap={20} color="transparent" />
            <Controls showInteractive={false} position="bottom-left" />
          </ReactFlow>

          <div className="absolute bottom-4 left-4 z-10 max-w-[min(420px,calc(100%-32px))]">
            {!circuitOpen ? (
              <button
                type="button"
                onClick={() => setCircuitOpen(true)}
                className="inline-flex items-center gap-2 rounded-full border border-white/80 bg-white/90 px-3 py-1.5 text-[11px] text-tt-muted shadow-soft backdrop-blur"
              >
                <span
                  className={`h-1.5 w-1.5 rounded-full ${
                    canCompile ? "bg-emerald-500" : "bg-tt-primary/70"
                  }`}
                />
                {canCompile ? "本地可运行 · 也可编译" : "本地可运行"}
              </button>
            ) : (
              <div className="overflow-hidden rounded-[16px] border border-tt-border bg-tt-panel/95 p-3 shadow-panel">
                <div className="flex items-center justify-between gap-3">
                  <div className="min-w-0">
                    <div className="text-sm font-medium text-tt-ink">进阶 · 编译与成本</div>
                    <div className="truncate text-xs text-tt-muted">{compileReport}</div>
                  </div>
                  <button
                    className="shrink-0 text-sm text-tt-primary"
                    onClick={() => setCircuitOpen(false)}
                  >
                    收起
                  </button>
                </div>
                <div className="mt-3 max-h-[280px] space-y-3 overflow-auto pr-1">
                  <TapeoutCostPanel
                    graph={fromFlow(nodes, edges, draft.graph)}
                    compact
                  />
                  {!draft.graph.nodes.some(n => n.type === "envelope" && supportedLetterRule(n.config)) && <pre className="overflow-auto rounded-lg bg-tt-bg p-3 text-[11px] text-tt-muted">
                    {JSON.stringify(
                      compileGraph(fromFlow(nodes, edges, draft.graph)).report,
                      null,
                      2
                    )}
                  </pre>}
                </div>
              </div>
            )}
          </div>

          <button
            type="button"
            className="absolute left-3 top-3 z-20 rounded-full bg-tt-primary px-3.5 py-2 text-xs font-medium text-white shadow-soft md:hidden"
            onClick={() => setMobilePartsOpen(true)}
          >
            零件 / 模板
          </button>
        </section>

        <aside className="tt-panel hidden overflow-auto p-4 md:block">
          {!selectedDef ? (
            <div className="space-y-4">
              <div>
                <h3 className="text-base font-medium">下一步</h3>
                <ol className="mt-3 list-decimal space-y-2 pl-4 text-sm leading-6 text-tt-muted">
                  {empty ? (
                    <>
                      <li>在中间选一个模板，或从左侧拖零件</li>
                      <li>把右侧圆点连到下一个零件</li>
                      <li>点顶栏「预览」立刻试玩</li>
                    </>
                  ) : (
                    <>
                      <li>点选零件，在这里改文字与行为</li>
                      <li>连线不同，玩法就会不同</li>
                      <li>改完点顶栏粉色「预览」</li>
                    </>
                  )}
                </ol>
              </div>
              <div className="rounded-[14px] bg-tt-bg/90 p-3 text-xs leading-5 text-tt-muted">
                <div className="font-medium text-tt-ink">小提示</div>
                <p className="mt-1">作品会自动保存。部署后可分享给别人打开。</p>
                <p className="mt-1">左下角「本地可运行」点开才是进阶编译信息。</p>
              </div>
            </div>
          ) : selected ? (
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <PartIcon type={selectedDef.type} size={44} />
                <div>
                  <h3 className="text-base font-medium">{selectedDef.label}设置</h3>
                  <p className="text-xs text-tt-muted">
                    {selectedDef.compileSupport === "hostOnly"
                      ? "本地运行零件"
                      : selectedDef.compileSupport === "transition"
                        ? "可参与流片编译"
                        : "可组合逻辑"}
                  </p>
                </div>
              </div>

              {selectedDef.type === "button" && (
                <>
                  <label className="block text-sm">
                    显示文字
                    <input
                      className="tt-input mt-1.5"
                      value={String(selectedData?.config.label ?? "")}
                      maxLength={24}
                      onChange={(e) => updateSelectedConfig("label", e.target.value)}
                    />
                  </label>
                  <div className="space-y-2">
                    <div className="text-sm font-medium">点击后执行</div>
                    {(
                      [
                        ["increment", "计数器 +1", "counter"],
                        ["toggle", "切换开关状态", "switch"],
                        ["checkIn", "打卡（日期门）", "dateGate"],
                        ["draw", "掷骰子 / 抽取", "randomBox"],
                        ["open", "打开信封", "envelope"],
                        ["start", "开始计时", "timer"],
                      ] as const
                    ).map(([value, label, type]) => (
                      <ActionChip
                        key={value}
                        active={selectedData?.config.action === value}
                        label={label}
                        onClick={() => {
                          const target = nodes.find(
                            (n) => (n.data as BlockNodeData).blockType === type
                          );
                          updateSelectedConfig("action", value);
                          if (target) {
                            applyActionEdge(value, target.id);
                            toast(`已接到「${getBlock(type)?.label}」`, "ok");
                          } else {
                            toast(
                              `画布上还没有「${getBlock(type)?.label ?? type}」，先拖一个过来`,
                              "info"
                            );
                          }
                        }}
                      />
                    ))}
                  </div>
                </>
              )}

              {selectedDef.type === "switch" && (
                <label className="flex items-center gap-2 text-sm">
                  <input
                    type="checkbox"
                    checked={Boolean(selectedData?.config.initial)}
                    onChange={(e) => updateSelectedConfig("initial", e.target.checked)}
                  />
                  初始为开
                </label>
              )}

              {selectedDef.type === "counter" && (
                <>
                  <label className="block text-sm">
                    初始值
                    <input
                      type="number"
                      className="tt-input mt-1.5"
                      value={Number(selectedData?.config.initial ?? 0)}
                      min={0}
                      max={65535}
                      onChange={(e) =>
                        updateSelectedConfig("initial", Number(e.target.value))
                      }
                    />
                  </label>
                  <label className="block text-sm">
                    步进
                    <input
                      type="number"
                      className="tt-input mt-1.5"
                      value={Number(selectedData?.config.step ?? 1)}
                      min={1}
                      max={1000}
                      onChange={(e) =>
                        updateSelectedConfig("step", Number(e.target.value))
                      }
                    />
                  </label>
                </>
              )}

              {selectedDef.type === "progress" && (
                <label className="block text-sm">
                  目标
                  <input
                    type="number"
                    className="tt-input mt-1.5"
                    value={Number(selectedData?.config.target ?? 30)}
                    min={1}
                    max={65535}
                    onChange={(e) =>
                      updateSelectedConfig("target", Number(e.target.value))
                    }
                  />
                </label>
              )}

              {selectedDef.type === "text" && (
                <label className="block text-sm">
                  内容
                  <textarea
                    className="tt-input mt-1.5 h-28 py-2"
                    value={String(selectedData?.config.content ?? "")}
                    maxLength={2000}
                    onChange={(e) => updateSelectedConfig("content", e.target.value)}
                  />
                </label>
              )}

              {selectedDef.type === "timer" && (
                <label className="block text-sm">
                  时长（秒）
                  <input
                    type="number"
                    className="tt-input mt-1.5"
                    value={Number(selectedData?.config.durationSec ?? 60)}
                    min={1}
                    max={86400}
                    onChange={(e) =>
                      updateSelectedConfig("durationSec", Number(e.target.value))
                    }
                  />
                </label>
              )}

              {selectedDef.type === "randomBox" && (
                <>
                  <div className="space-y-2">
                    <div className="text-sm font-medium">盒子模式</div>
                    <ActionChip
                      active={String(selectedData?.config.mode ?? "list") === "dice"}
                      label="骰子 1–6"
                      onClick={() => {
                        updateSelectedConfig("mode", "dice");
                        updateSelectedConfig("items", ["1", "2", "3", "4", "5", "6"]);
                        updateSelectedConfig("noRepeat", false);
                      }}
                    />
                    <ActionChip
                      active={String(selectedData?.config.mode ?? "list") === "list"}
                      label="自定义清单"
                      onClick={() => updateSelectedConfig("mode", "list")}
                    />
                  </div>
                  {String(selectedData?.config.mode ?? "list") !== "dice" && (
                    <label className="block text-sm">
                      选项（每行一个）
                      <textarea
                        className="tt-input mt-1.5 h-28 py-2"
                        value={((selectedData?.config.items as string[]) ?? []).join(
                          "\n"
                        )}
                        onChange={(e) =>
                          updateSelectedConfig(
                            "items",
                            e.target.value
                              .split("\n")
                              .map((s) => s.trim())
                              .filter(Boolean)
                              .slice(0, 100)
                          )
                        }
                      />
                    </label>
                  )}
                  <p className="rounded-[12px] bg-tt-bg/90 p-2.5 text-[11px] leading-5 text-tt-muted">
                    把「抽中」连到信封的「信号」，就能按点数解锁信件。
                  </p>
                </>
              )}

              {selectedDef.type === "condition" && (
                <>
                  <p className="rounded-[12px] bg-tt-bg/90 p-2.5 text-[11px] leading-5 text-tt-muted">
                    左值来自接到「左」端口的零件（如计数器数值）；没接线时只比右值常数。
                  </p>
                  <label className="block text-sm">
                    比较方式
                    <select
                      className="tt-input mt-1.5"
                      value={String(selectedData?.config.op ?? "eq")}
                      onChange={(e) => updateSelectedConfig("op", e.target.value)}
                    >
                      <option value="eq">等于</option>
                      <option value="neq">不等于</option>
                      <option value="gt">大于</option>
                      <option value="gte">大于等于</option>
                      <option value="lt">小于</option>
                      <option value="lte">小于等于</option>
                    </select>
                  </label>
                  <label className="block text-sm">
                    右值常数（没接线时用）
                    <input
                      type="number"
                      className="tt-input mt-1.5"
                      value={Number(selectedData?.config.rightConst ?? 0)}
                      onChange={(e) =>
                        updateSelectedConfig("rightConst", Number(e.target.value))
                      }
                    />
                  </label>
                </>
              )}

              {selectedDef.type === "dateGate" && (
                <div className="space-y-3">
                  <p className="rounded-[12px] bg-tt-bg/90 p-2.5 text-[11px] leading-5 text-tt-muted">
                    同一天只放行一次。把按钮「点击」接到这里的「尝试」，通过后再连到连续天数。
                  </p>
                  <label className="block text-sm">
                    时区
                    <input
                      className="tt-input mt-1.5"
                      value={String(
                        selectedData?.config.timezone ?? "Asia/Shanghai"
                      )}
                      onChange={(e) =>
                        updateSelectedConfig("timezone", e.target.value)
                      }
                    />
                  </label>
                </div>
              )}

              {selectedDef.type === "streakCounter" && (
                <div className="rounded-[12px] bg-tt-bg/90 p-2.5 text-[11px] leading-5 text-tt-muted">
                  记录连续打卡天数。请接到日期门的「通过」口，而不是直接接按钮，否则无法防同日重复。
                </div>
              )}

              {selectedDef.type === "envelope" && (
                <>
                  <div className="space-y-2">
                    <div className="text-sm font-medium">如何解锁</div>
                    {(
                      [
                        ["signals", "凑齐信号（如三个 6）"],
                        ["event", "收到「解锁」事件"],
                        ["time", "到了设定时间"],
                      ] as const
                    ).map(([value, label]) => (
                      <ActionChip
                        key={value}
                        active={
                          String(selectedData?.config.unlockMode ?? "event") === value
                        }
                        label={label}
                        onClick={() => updateSelectedConfig("unlockMode", value)}
                      />
                    ))}
                  </div>
                  {String(selectedData?.config.unlockMode ?? "event") === "signals" && (
                    <>
                      <label className="block text-sm">计分方式<select className="tt-input mt-1.5" value={String(selectedData?.config.signalRule ?? "matches")} onChange={(e) => updateSelectedConfig("signalRule", e.target.value)}><option value="matches">收集指定点数</option><option value="sum">累计骰子点数</option></select></label>
                      <label className="block text-sm">
                        需要几个信号
                        <input
                          type="number"
                          className="tt-input mt-1.5"
                          min={1}
                          max={99}
                          value={Number(selectedData?.config.needSignals ?? 3)}
                          onChange={(e) =>
                            updateSelectedConfig(
                              "needSignals",
                              Number(e.target.value)
                            )
                          }
                        />
                      </label>
                      <label className="block text-sm">
                        只认这个内容（如 6）
                        <input
                          className="tt-input mt-1.5"
                          value={String(selectedData?.config.matchPayload ?? "6")}
                          onChange={(e) =>
                            updateSelectedConfig("matchPayload", e.target.value)
                          }
                        />
                      </label>
                    </>
                  )}
                  <label className="block text-sm">
                    信封内容
                    <textarea
                      className="tt-input mt-1.5 h-28 py-2"
                      value={String(selectedData?.config.body ?? "")}
                      maxLength={2000}
                      onChange={(e) => updateSelectedConfig("body", e.target.value)}
                    />
                  </label>
                </>
              )}

              <button
                type="button"
                className="tt-btn-secondary w-full text-sm"
                onClick={() => {
                  const nextNodes = nodes.filter((n) => n.id !== selected.id);
                  const nextEdges = edges.filter(
                    (e) => e.source !== selected.id && e.target !== selected.id
                  );
                  setNodes(nextNodes);
                  setEdges(nextEdges);
                  emitGraph(nextNodes, nextEdges);
                  setSelected(null);
                  setMobileSettingsOpen(false);
                }}
              >
                删除此零件
              </button>
              <p className="text-xs leading-5 text-tt-muted">{selectedDef.description}</p>
            </div>
          ) : null}
        </aside>
      </div>

      {mobileSettingsOpen && selected && selectedDef && (
        <div
          className="fixed inset-0 z-50 bg-[#302740]/40 md:hidden"
          onClick={() => setMobileSettingsOpen(false)}
          role="presentation"
        >
          <div
            className="absolute inset-x-0 bottom-0 max-h-[78vh] overflow-auto rounded-t-[24px] bg-tt-panel p-4 shadow-panel"
            onClick={(e) => e.stopPropagation()}
            role="dialog"
            aria-label="零件设置"
          >
            <div className="mx-auto mb-3 h-1.5 w-12 rounded-full bg-tt-border" />
            <div className="mb-3 flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <PartIcon type={selectedDef.type} size={36} />
                <div className="text-sm font-medium">{selectedDef.label}设置</div>
              </div>
              <button
                type="button"
                className="text-sm text-tt-muted"
                onClick={() => setMobileSettingsOpen(false)}
              >
                完成
              </button>
            </div>
            <p className="mb-3 text-xs leading-5 text-tt-muted">
              改完点顶栏「预览」试玩。点空白处也可关闭。
            </p>
            {selectedDef.type === "button" && (
              <label className="block text-sm">
                显示文字
                <input
                  className="tt-input mt-1.5"
                  value={String(selectedData?.config.label ?? "")}
                  maxLength={24}
                  onChange={(e) => updateSelectedConfig("label", e.target.value)}
                />
              </label>
            )}
            {selectedDef.type === "text" && (
              <label className="mt-3 block text-sm">
                内容
                <textarea
                  className="tt-input mt-1.5 h-28 py-2"
                  value={String(selectedData?.config.content ?? "")}
                  maxLength={2000}
                  onChange={(e) => updateSelectedConfig("content", e.target.value)}
                />
              </label>
            )}
            {selectedDef.type === "counter" && (
              <label className="mt-3 block text-sm">
                初始值
                <input
                  type="number"
                  className="tt-input mt-1.5"
                  value={Number(selectedData?.config.initial ?? 0)}
                  onChange={(e) =>
                    updateSelectedConfig("initial", Number(e.target.value))
                  }
                />
              </label>
            )}
            {selectedDef.type === "envelope" && (
              <label className="mt-3 block text-sm">
                信封内容
                <textarea
                  className="tt-input mt-1.5 h-28 py-2"
                  value={String(selectedData?.config.body ?? "")}
                  maxLength={2000}
                  onChange={(e) => updateSelectedConfig("body", e.target.value)}
                />
              </label>
            )}
            {selectedDef.type === "dateGate" && (
              <p className="mt-2 text-xs leading-5 text-tt-muted">
                同一天只放行一次（{String(selectedData?.config.timezone ?? "Asia/Shanghai")}）。
              </p>
            )}
            {selectedDef.type === "streakCounter" && (
              <p className="mt-2 text-xs leading-5 text-tt-muted">
                连续天数计数；请接到日期门「通过」。
              </p>
            )}
            <p className="mt-4 text-xs text-tt-muted">{selectedDef.description}</p>
          </div>
        </div>
      )}

      {mobilePartsOpen && (
        <div
          className="fixed inset-0 z-50 bg-[#302740]/40 md:hidden"
          onClick={() => setMobilePartsOpen(false)}
          role="presentation"
        >
          <div
            className="absolute inset-x-0 bottom-0 max-h-[78vh] overflow-auto rounded-t-[24px] bg-tt-panel p-4 shadow-panel"
            onClick={(e) => e.stopPropagation()}
            role="dialog"
            aria-label="零件与模板"
          >
            <div className="mx-auto mb-3 h-1.5 w-12 rounded-full bg-tt-border" />
            <div className="mb-3 flex gap-2">
              <button
                type="button"
                className={`flex-1 rounded-[12px] py-2 text-sm ${
                  tab === "parts" ? "bg-tt-primary text-white" : "bg-tt-bg"
                }`}
                onClick={() => setTab("parts")}
              >
                基础零件
              </button>
              <button
                type="button"
                className={`flex-1 rounded-[12px] py-2 text-sm ${
                  tab === "templates" ? "bg-tt-primary text-white" : "bg-tt-bg"
                }`}
                onClick={() => setTab("templates")}
              >
                组合模板
              </button>
            </div>
            {tab === "parts" ? PartsGrid : TemplatesList}
          </div>
        </div>
      )}

      {loveOpen && <LoveLetterComposer draft={{ ...draft, name, graph: fromFlow(nodes, edges, draft.graph) }} onClose={() => setLoveOpen(false)} onApply={(next) => {
        pushHistory(fromFlow(nodes, edges, draft.graph));
        const graph = spreadPositions(next.graph);
        const flow = toFlow(graph);
        setNodes(flow.nodes); setEdges(flow.edges); setName(next.name); setSelected(null);
        onChange({ ...next, graph }); setLoveOpen(false); setHintDismissed(true);
        sessionRef.current = new RuntimeSession(graph, { timezone: "Asia/Shanghai", seed: crypto.getRandomValues(new Uint32Array(1))[0] });
        setRuntimeView(sessionRef.current.getSnapshot().states); setPreviewFlash(null); setPreviewOpen(true);
        window.setTimeout(() => { void fitView({ padding: .18 }); }, 150);
      }} />}
      {previewOpen && (
        <PreviewPlayer
          name={name}
          music={draft.theme.music}
          graph={fromFlow(nodes, edges, draft.graph)}
          states={runtimeView}
          flash={previewFlash}
          onInteract={tickPreview}
          onReset={resetPreview}
          onClose={() => setPreviewOpen(false)}
        />
      )}
    </div>
  );
}

export function MakerCanvas(props: {
  draft: DraftPayload & { id: string };
  onChange: (next: DraftPayload) => void;
  onSave: () => void;
  onPublish: () => void;
  saving?: boolean;
  saveStatus?: string;
}) {
  return (
    <ReactFlowProvider>
      <MakerInner {...props} />
    </ReactFlowProvider>
  );
}
