"use client";

import { useEffect, useState } from "react";
import type { MusicTrack } from "@/lib/music";
import type { DesignGraph } from "@tinythings/schema";
import { ThingPlayView } from "@/components/ThingPlayView";

type States = Record<string, Record<string, unknown>>;

function todayLabel() {
  return new Intl.DateTimeFormat("zh-CN", {
    timeZone: "Asia/Shanghai",
    month: "long",
    day: "numeric",
    weekday: "short",
  }).format(new Date());
}

export function PreviewPlayer({
  name,
  graph,
  states,
  flash,
  onInteract,
  onReset,
  onClose,
  music,
}: {
  name: string;
  graph: DesignGraph;
  states: States;
  flash?: string | null;
  onInteract: (nodeId: string, port: string) => void;
  onReset: () => void;
  onClose: () => void;
  music?: MusicTrack;
}) {

  const [bounce, setBounce] = useState(false);
  const [hearts, setHearts] = useState(false);

  useEffect(() => {
    if (!flash) return;
    setBounce(true);
    setHearts(true);
    const t = setTimeout(() => setBounce(false), 380);
    const t2 = setTimeout(() => setHearts(false), 900);
    return () => {
      clearTimeout(t);
      clearTimeout(t2);
    };
  }, [flash]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center bg-[#3a2a48]/50 p-0 backdrop-blur-[6px] sm:items-center sm:p-6"
      onClick={onClose}
      role="presentation"
    >
      <div
        className="preview-sheet relative flex max-h-[min(940px,100dvh)] w-full max-w-[440px] flex-col overflow-hidden rounded-t-[32px] border border-white/80 shadow-[0_28px_90px_#30274066] sm:rounded-[32px]"
        style={{
          background:
            "linear-gradient(165deg, #fff8fd 0%, #f3efff 42%, #eef6ff 72%, #fff6f0 100%)",
        }}
        onClick={(e) => e.stopPropagation()}
        role="dialog"
        aria-modal="true"
        aria-label="作品预览"
      >
        <div className="mx-auto mt-2 h-1.5 w-12 rounded-full bg-[#d9cfea] sm:hidden" />

        <div className="flex items-start justify-between gap-3 px-5 pb-2 pt-3">
          <div className="min-w-0">
            <div className="inline-flex flex-wrap items-center gap-2">
              <span className="rounded-full bg-white/85 px-2.5 py-0.5 text-[11px] text-tt-deep shadow-soft">
                即时预览
              </span>
              <span className="text-[11px] text-tt-muted">{todayLabel()}</span>
            </div>
            <h3 className="mt-1 truncate text-[20px] font-semibold tracking-tight text-tt-ink">
              {name || "未命名小东西"}
            </h3>
            <p className="mt-0.5 text-xs text-tt-muted">
              和分享出去后别人打开的样子一样
            </p>
          </div>
          <button
            type="button"
            className="shrink-0 rounded-full bg-white/85 px-3 py-1.5 text-sm text-tt-ink shadow-soft"
            onClick={onClose}
          >
            关闭
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-5 pb-5 pt-1">
          <div
            className={`preview-device relative mx-auto transition duration-300 ${
              bounce ? "scale-[1.015]" : "scale-100"
            }`}
          >
            <div
              className="pointer-events-none absolute inset-0 opacity-90"
              style={{
                background:
                  "radial-gradient(120% 90% at 85% -10%, #ffd6ea99, transparent 50%), radial-gradient(90% 80% at 0% 100%, #cfe0ff88, transparent 55%)",
              }}
            />
            {hearts && (
              <div className="pointer-events-none absolute inset-x-0 top-3 z-20 flex justify-center gap-3 text-lg">
                <span className="preview-float">✦</span>
                <span className="preview-float delay-75">♡</span>
                <span className="preview-float delay-150">✧</span>
              </div>
            )}
            <div className="relative">
              <ThingPlayView
                name={name}
                music={music}
                graphOrNodes={graph}
                states={states}
                flash={flash}
                onInteract={onInteract}
              />
            </div>
          </div>

          <div className="mt-4">
            <button type="button" className="tt-btn-secondary w-full" onClick={onReset}>
              重新开始
            </button>
          </div>
          <p className="mt-3 text-center text-[11px] leading-5 text-tt-muted">
            点右上角「关闭」回到制造。连线不同，玩法就会不同。
          </p>
        </div>
      </div>
    </div>
  );
}
