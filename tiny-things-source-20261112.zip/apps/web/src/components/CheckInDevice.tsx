"use client";

import Image from "next/image";
import { useRef, useState, useEffect } from "react";
import { ART } from "@/lib/art";

/** Hotspots are measured against the original 864×1152 artwork, not the page. */
export function CheckInDevice({ streak, label = "打卡!", saving, done, onPress, interactive = true }: {
  streak: number; label?: string; saving?: boolean; done?: boolean; onPress?: () => void; interactive?: boolean;
}) {
  const [pressed, setPressed] = useState(0);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  useEffect(() => () => { if (timer.current) clearTimeout(timer.current); }, []);
  function press() {
    if (!interactive || saving) return;
    setPressed((n) => n + 1);
    onPress?.();
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => setPressed(0), 850);
  }
  return <div className="checkin-device mx-auto w-full max-w-[400px]">
    <div className="checkin-art relative aspect-[3/4] overflow-hidden rounded-[30px]">
      <Image src={ART.deviceCheckin} alt="星星打卡机，轻点粉色爱心按钮" fill sizes="(max-width:480px) 90vw, 400px" className="object-contain" priority />
      <div className="checkin-screen" aria-live="polite" aria-atomic="true" data-testid="device-screen">
        <span className="checkin-screen-label">{done ? "今天也有好好生活" : "收集每一个小日子"}</span>
        <span className="checkin-screen-value">{streak}<span>天</span></span>
        <span className="checkin-screen-footer">{saving ? "正在收藏…" : done ? "♡ 今日已收藏" : "连续打卡 · 等你按下爱心"}</span>
      </div>
      <button type="button" className={`checkin-heart ${pressed ? "is-pressed" : ""}`} aria-label={label} title="轻点爱心" disabled={!interactive || saving} onClick={press} data-testid="device-heart"><span className="sr-only">按下设备上的爱心</span></button>
      {pressed > 0 && <div key={pressed} className="checkin-sparkles" aria-hidden="true"><i>♡</i><i>✦</i><i>♡</i><i>✧</i></div>}
    </div>
    <p className="mt-3 text-center text-[11px] tracking-wide text-[#a18293]">轻轻戳一下爱心，把今天收藏起来 ♡</p>
  </div>;
}
