"use client";
import Link from "next/link";
import { useMemo } from "react";
import { compileGraph, encodeNetlist, compileLetterRule, supportedLetterRule, encodeSequential } from "@tinythings/compiler";
import type { DesignGraph } from "@tinythings/schema";
export function TapeoutCostPanel({ graph }: { graph?: DesignGraph; compact?: boolean }) {
  const result = useMemo(() => graph ? compileGraph(graph) : null, [graph]);
  const letters = useMemo(() => graph?.nodes.flatMap(node => {
    const rule = node.type === "envelope" ? supportedLetterRule(node.config) : null;
    return rule ? [{ id: node.id, rule, circuit: compileLetterRule(rule) }] : []
  }) ?? [], [graph]);
  if (!result) return null;
  return <div className="space-y-3 text-xs leading-5">
    <h3 className="text-sm font-medium">本地电路编译</h3>
    {letters.map(({ id, rule, circuit }) => <div key={id} className="rounded-xl bg-pink-50 p-3 space-y-2">
      <p className="font-medium text-tt-deep">♡ 情书规则 · 本地电路驱动</p>
      <p>{rule.rule === "sum" ? `累计 ${rule.target} 点` : `收集 ${rule.target} 个 ${rule.face} 点`} · {circuit.elements.filter(e => e.op === "nand").length} NAND ＋ 8 LATCH</p>
      <p className="text-tt-muted">试玩用电路计算进度与解锁，并逐步核对原规则。文字、骰子随机数与拆信动画由网页处理。</p>
      <button className="tt-btn-secondary h-9 text-xs" onClick={() => {
        const bytes = encodeSequential(circuit);
        const artifact = { format: "tiny-letter-circuit/1", nodeId: id, rule, circuit,
          encodedHex: "0x" + Array.from(bytes, b => b.toString(16).padStart(2, "0")).join(""),
          pins: { inputs: ["signal", "face0", "face1", "face2", "unlock"], state: ["progress0", "progress1", "progress2", "progress3", "progress4", "progress5", "progress6", "unlocked"], outputs: "next progress[0..6], next unlocked; LSB first" },
          status: "local-verified-not-deployed", note: "本地 NAND/LATCH 包；尚未由目标 TapeOut 合约验证、流片或绑定。状态与随机输入来自网页，不提供防篡改或隐私保证。" };
        const url = URL.createObjectURL(new Blob([JSON.stringify(artifact, null, 2)], { type: "application/json" }));
        const a = document.createElement("a"); a.href = url; a.download = `tiny-letter-${rule.rule}.json`; a.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
      }}>导出情书电路包</button>
      <p className="text-tt-muted">尚未流片到 X Layer · 未产生费用</p>
    </div>)}
    {result.netlist ? <><p>{result.netlist.nState} 位状态 · {result.report.gateCount} NAND · {result.report.byteLength} 字节</p><button className="tt-btn-secondary h-9 text-xs" onClick={() => {
      const net = result.netlist!;
      const artifact = { format: "tiny-nand/1", ir: result.ir, netlist: net, encodedHex: Array.from(encodeNetlist(net), (b) => b.toString(16).padStart(2, "0")).join(""), note: "本地下一状态组合逻辑，状态由宿主提供；未转换为 TapeOut LATCH 电路，不能作为已验证流片包。" };
      const url = URL.createObjectURL(new Blob([JSON.stringify(artifact, null, 2)], { type: "application/json" }));
      const a = document.createElement("a"); a.href = url; a.download = "tiny-nand.json"; a.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
    }}>导出 NAND 编译结果</button></> : <p>{letters.length ? "以上仅编译信封的点数规则，其他零件仍在网页运行。" : "当前组合在网页运行，尚不支持完整转为 NAND。"}</p>}
    {(letters.length ? [] : result.ir.diagnostics).map((d, i) => <p key={i} className="text-tt-muted">{d.message}</p>)}
    <p className="rounded-xl bg-tt-bg p-3 text-tt-muted">本地 NAND 与链上流片分开验证。实际费用需读取目标合约，当前不提供固定报价。</p>
    <Link href="/circuits" className="inline-block text-tt-deep underline underline-offset-4">打开电路观察室 →</Link>
  </div>;
}
