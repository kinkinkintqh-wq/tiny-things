"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const links = [
  { href: "/demo", label: "试玩" },
  { href: "/discover", label: "发现" },
  { href: "/make", label: "制造" },
  { href: "/studio", label: "我的" },
  { href: "/about", label: "关于" },
];

export function SiteNav() {
  const pathname = usePathname();
  const compact = pathname.startsWith("/make");

  return (
    <header
      className={`sticky top-0 z-40 border-b border-tt-border/70 bg-tt-panel/75 backdrop-blur-md ${
        compact ? "h-14" : "h-[72px]"
      }`}
    >
      <div className="mx-auto flex h-full max-w-[1440px] items-center justify-between px-4 md:px-12">
        <Link href="/" className="flex items-baseline gap-2">
          <span className="font-pixel text-[11px] leading-none text-tt-deep md:text-[13px]">
            Tiny Things
          </span>
          <span className="hidden text-sm text-tt-muted lg:inline lg:text-base">小东西制造所</span>
        </Link>
        <nav className="flex items-center gap-1 md:gap-3">
          {links.map((l) => {
            const active = pathname === l.href || pathname.startsWith(`${l.href}/`);
            return (
              <Link
                key={l.href}
                href={l.href}
                className={`rounded-btn px-2 py-2 text-xs transition md:px-4 md:text-sm ${
                  active
                    ? "bg-tt-primary/15 font-medium text-tt-deep"
                    : "text-tt-muted hover:bg-white/60 hover:text-tt-ink"
                }`}
              >
                {l.label}
              </Link>
            );
          })}
        </nav>
      </div>
    </header>
  );
}
