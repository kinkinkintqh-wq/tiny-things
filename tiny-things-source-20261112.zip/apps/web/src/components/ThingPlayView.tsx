"use client";

import { useMemo } from "react";
import { getBlock, templateGraph } from "@tinythings/block-registry";
import type { DesignGraph } from "@tinythings/schema";
import { CheckInDevice } from "@/components/CheckInDevice";
import { DiceLetterDevice } from "@/components/play/DiceLetterDevice";
import { PlayDeviceShell } from "@/components/play/PlayDeviceShell";
import { MusicPlayer } from "@/components/play/MusicPlayer";
import type { MusicTrack } from "@/lib/music";
import { dayIndexInTimeZone } from "@tinythings/runtime";
import { PartIcon } from "@/components/VoxelIcons";

type States = Record<string, Record<string, unknown>>;

export type PlayNode = {
  id: string;
  type: string;
  config: Record<string, unknown>;
};

function asNodes(graphOrNodes: DesignGraph | PlayNode[]): PlayNode[] {
  if (Array.isArray(graphOrNodes)) return graphOrNodes;
  return graphOrNodes.nodes.map((n) => ({
    id: n.id,
    type: n.type,
    config: n.config ?? {},
  }));
}

function find(nodes: PlayNode[], type: string) {
  return nodes.filter((n) => n.type === type);
}

export function detectPlayMood(nodes: PlayNode[]) {
  const has = (t: string) => find(nodes, t).length > 0;
  if (has("dateGate") && has("streakCounter")) return "checkin" as const;
  if (has("randomBox") && has("envelope")) return "diceLetter" as const;
  if (has("randomBox")) return "random" as const;
  if (has("envelope")) return "letter" as const;
  if (has("timer") && !has("counter")) return "timer" as const;
  if (has("counter") || has("progress")) return "habit" as const;
  return "mixed" as const;
}

function CuteButton({
  label,
  onClick,
  tone = "pink",
  disabled,
}: {
  label: string;
  onClick: () => void;
  tone?: "pink" | "violet" | "mint" | "cream";
  disabled?: boolean;
}) {
  const bg =
    tone === "violet"
      ? "#9274DD"
      : tone === "mint"
        ? "#CBE6CF"
        : tone === "cream"
          ? "#F5E6B8"
          : "#F1B0C9";
  const color = tone === "violet" ? "#fff" : "#302740";
  return (
    <button
      type="button"
      disabled={disabled}
      onClick={onClick}
      className="preview-press w-full rounded-[18px] px-5 py-3.5 text-[15px] font-medium shadow-soft transition active:translate-y-[1px] disabled:opacity-50"
      style={{ background: bg, color }}
    >
      {label}
    </button>
  );
}

/** Shared playable surface for maker preview and shared /run links. */
export function ThingPlayView({
  name,
  graphOrNodes,
  states,
  flash,
  onInteract,
  compact,
  music = "musicbox",
}: {
  name?: string;
  graphOrNodes: DesignGraph | PlayNode[];
  states: States;
  flash?: string | null;
  onInteract: (nodeId: string, port: string) => void;
  compact?: boolean;
  music?: MusicTrack;
}) {
  const experience = (content: React.ReactNode) => <div className="play-experience"><MusicPlayer preferredTrack={music} />{content}</div>;
  const nodes = useMemo(() => asNodes(graphOrNodes), [graphOrNodes]);
  const mood = detectPlayMood(nodes);
  const graph = Array.isArray(graphOrNodes) ? null : graphOrNodes;
  const signature = (g: DesignGraph) => JSON.stringify({
    nodes: g.nodes.map((n) => n.type).sort(),
    edges: g.edges.map((e) => [g.nodes.find((n) => n.id === e.source)?.type, e.sourcePort, g.nodes.find((n) => n.id === e.target)?.type, e.targetPort, e.kind].join(":")).sort(),
  });
  const exactDevice = graph && ["daily-checkin", "dice-letter"].some((id) => signature(graph) === signature(templateGraph(id)));
  const connectedButton = (target: string, port: string) => {
    const edge = graph?.edges.find((e) => e.target === target && e.targetPort === port && e.kind === "event" && e.sourcePort === "click");
    return nodes.find((n) => n.id === edge?.source && n.type === "button");
  };
  const buttons = find(nodes, "button");
  const streakNode = find(nodes, "streakCounter")[0];
  const streak = streakNode ? Number(states[streakNode.id]?.streak ?? 0) : 0;
  const total = streakNode ? Number(states[streakNode.id]?.total ?? 0) : 0;

  const counters = find(nodes, "counter").map((n) => ({
    id: n.id,
    value: Number(states[n.id]?.value ?? n.config.initial ?? 0),
  }));

  const progresses = find(nodes, "progress").map((n) => {
    const target = Number(n.config.target ?? 30);
    const value = Number(states[n.id]?.value ?? 0);
    const ratio = Number(
      states[n.id]?.ratio ?? Math.min(100, Math.floor((value / target) * 100))
    );
    return {
      id: n.id,
      value,
      target,
      ratio,
      done: Boolean(states[n.id]?.done),
    };
  });

  const randoms = find(nodes, "randomBox").map((n) => ({
    id: n.id,
    mode: String(n.config.mode ?? "list"),
    last: (states[n.id]?.last as string | null | undefined) ?? null,
    value: Number(states[n.id]?.value ?? 0),
    items: ((n.config.items as string[]) ?? []).slice(0, 8),
  }));

  const envelopes = find(nodes, "envelope").map((n) => {
    const st = states[n.id] ?? {};
    return {
      id: n.id,
      body: String(st.body || n.config.body || ""),
      opened: Boolean(st.opened),
      unlocked: Boolean(st.unlocked) || st.locked === false,
      locked: st.locked !== false && !st.unlocked,
      signalCount: Number(st.signalCount ?? 0),
      need: Number(n.config.needSignals ?? st.need ?? 3),
      match: String(n.config.matchPayload ?? "6"),
      mode: String(n.config.unlockMode ?? "event"),
      rule: String(n.config.signalRule ?? "matches"),
    };
  });

  const switches = find(nodes, "switch").map((n) => ({
    id: n.id,
    on: Boolean(states[n.id]?.on ?? n.config.initial),
  }));

  const texts = find(nodes, "text").map((n) => ({
    id: n.id,
    content: String(n.config.content ?? ""),
  }));

  const timers = find(nodes, "timer").map((n) => ({
    id: n.id,
    duration: Number(n.config.durationSec ?? 60),
    remaining: Number(states[n.id]?.remaining ?? 0),
    started: states[n.id]?.deadline != null,
  }));

  const primary =
    mood === "habit" ? "violet" : mood === "random" || mood === "diceLetter" ? "cream" : "pink";

  if (exactDevice && mood === "checkin" && streakNode && buttons[0]) {
    const checkedToday = states[streakNode.id]?.lastDay === dayIndexInTimeZone(Date.now(), "Asia/Shanghai");
    return experience(<div>
      <CheckInDevice streak={streak} label={String(buttons[0].config.label ?? "打卡!")} done={checkedToday} onPress={() => onInteract(buttons[0]!.id, "press")} />
      <p className="mt-4 text-center text-[11px] text-[#ad8b9d]">累计收藏 {total} 天 · 每一天，都值得被好好对待</p>
    </div>);
  }

  if (exactDevice && mood === "diceLetter" && randoms[0]?.mode === "dice" && envelopes[0]?.mode === "signals") {
    const rollBtn = connectedButton(randoms[0].id, "draw");
    const openBtn = connectedButton(envelopes[0].id, "open");
    const envelopeConfig = nodes.find((n) => n.id === envelopes[0].id)!.config;
    return experience(
      <DiceLetterDevice
        name={name}
        last={randoms[0].last}
        signalCount={envelopes[0].signalCount}
        need={envelopes[0].need}
        match={envelopes[0].match}
        body={envelopes[0].body}
        opened={envelopes[0].opened}
        unlocked={envelopes[0].unlocked}
        flash={flash}
        recipient={String(envelopeConfig.recipient ?? "最可爱的你")}
        sender={String(envelopeConfig.sender ?? "")}
        letterTitle={String(envelopeConfig.letterTitle ?? "有些话，想亲手交给你")}
        rule={String(envelopeConfig.signalRule ?? "matches")}
        onRoll={() => {
          if (rollBtn) onInteract(rollBtn.id, "press");
          else onInteract(randoms[0]!.id, "draw");
        }}
        onOpen={() => {
          if (openBtn) onInteract(openBtn.id, "press");
          else onInteract(envelopes[0]!.id, "open");
        }}
      />
    );
  }

  const moodEyebrow =
    mood === "habit"
      ? "习惯小设备"
      : mood === "random"
        ? "随机小盒子"
        : mood === "letter"
          ? "信封小设备"
          : mood === "timer"
            ? "计时小设备"
            : "我的小东西";

  return experience(
    <PlayDeviceShell eyebrow={!compact ? moodEyebrow : undefined} title={!compact ? name : undefined} flash={flash}>
      <div className="space-y-3.5">
        {nodes.filter((n) => ["dateGate", "condition", "checklist", "proofCard"].includes(n.type)).map((n) => <div key={n.id} className="rounded-[18px] border border-tt-border/60 bg-white/70 px-4 py-3 text-sm">
          <span className="font-medium">{getBlock(n.type)?.label}</span>
          <p className="mt-1 text-xs text-tt-muted">{n.type === "condition" ? `结果：${states[n.id]?.result ? "为真" : "为假"}` : n.type === "dateGate" ? "同一天只放行一次" : n.type === "checklist" ? ((n.config.items as string[] | undefined) ?? []).join(" · ") : "本地作品信息 · 未进行链上验证"}</p>
        </div>)}

        {texts.map((t) => (
          <p
            key={t.id}
            className="rounded-[20px] bg-white/90 px-4 py-3.5 text-center text-[15px] leading-7 text-tt-ink shadow-soft"
          >
            {t.content || "你好呀，小东西"}
          </p>
        ))}

        {counters.map((c, i) => (
          <div
            key={c.id}
            className="rounded-[24px] bg-white/90 px-5 py-6 text-center shadow-soft"
          >
            <div className="text-[11px] tracking-wide text-tt-muted">
              {counters.length > 1 ? `计数 ${i + 1}` : "当前计数"}
            </div>
            <div
              className="mt-1 font-semibold tabular-nums text-tt-ink"
              style={{ fontSize: 56, lineHeight: 1 }}
            >
              {c.value}
            </div>
          </div>
        ))}

        {progresses.map((p) => (
          <div key={p.id} className="rounded-[22px] bg-white/90 px-4 py-4 shadow-soft">
            <div className="mb-2 flex items-center justify-between text-xs text-tt-muted">
              <span>进度</span>
              <span className="tabular-nums text-tt-ink">
                {p.value}/{p.target}
              </span>
            </div>
            <div className="h-3.5 overflow-hidden rounded-full bg-[#efe7f8]">
              <div
                className="h-full rounded-full bg-[linear-gradient(90deg,#f7c4d8,#b8a0ef,#9ec9ff)] transition-all duration-500"
                style={{ width: `${Math.min(100, p.ratio)}%` }}
              />
            </div>
            {p.done ? (
              <p className="mt-2 text-center text-xs text-tt-deep">目标达成啦</p>
            ) : null}
          </div>
        ))}

        {randoms.map((r) => (
          <div
            key={r.id}
            className="rounded-[24px] bg-white/90 px-4 py-6 text-center shadow-soft"
          >
            <div className="mx-auto mb-2 flex justify-center">
              <PartIcon type="randomBox" size={52} />
            </div>
            <div className="text-[11px] text-tt-muted">
              {r.mode === "dice" ? "骰子点数" : "抽到了"}
            </div>
            <div className="mt-2 text-[40px] font-semibold tabular-nums leading-none text-tt-ink">
              {r.last ?? "—"}
            </div>
            {r.mode !== "dice" && r.items.length > 0 ? (
              <div className="mt-3 flex flex-wrap justify-center gap-1.5">
                {r.items.map((item) => (
                  <span
                    key={item}
                    className="rounded-full bg-[#f3eefb] px-2.5 py-1 text-[10px] text-tt-muted"
                  >
                    {item}
                  </span>
                ))}
              </div>
            ) : null}
          </div>
        ))}

        {envelopes.map((e) => (
          <div
            key={e.id}
            className="rounded-[24px] bg-white/90 px-4 py-5 text-center shadow-soft"
          >
            <div className="mx-auto mb-2 flex justify-center">
              <PartIcon type="envelope" size={48} />
            </div>
            {e.mode === "signals" ? (
              <div className="mb-3">
                <div className="text-[11px] text-tt-muted">
                  {e.rule === "sum" ? `累计 ${e.need} 点才能读信` : `收集 ${e.need} 次「${e.match || "信号"}」才能读信`}
                </div>
                <div className="mt-2 flex justify-center gap-1.5">
                  {Array.from({ length: Math.min(e.need, 10) }).map((_, i) => (
                    <span
                      key={i}
                      className={`inline-flex h-8 w-8 items-center justify-center rounded-full text-sm font-semibold shadow-soft ${
                        i < e.signalCount
                          ? "bg-[#f1b0c9] text-tt-ink"
                          : "bg-[#efe7f8] text-tt-muted"
                      }`}
                    >
                      {e.match || "★"}
                    </span>
                  ))}
                </div>
                <div className="mt-2 text-xs tabular-nums text-tt-muted">
                  {Math.min(e.signalCount, e.need)}/{e.need}
                </div>
              </div>
            ) : null}

            {e.opened && !e.locked ? (
              <p className="text-[15px] leading-7 text-tt-ink">{e.body}</p>
            ) : (
              <p className="text-sm text-tt-muted">
                {e.unlocked
                  ? "信封已解锁，点「读信」打开"
                  : e.mode === "signals"
                    ? "还没凑齐，继续掷吧"
                    : e.mode === "time"
                      ? "还没到拆信的日子"
                      : "需要解锁信号才会打开（把线接到信封）"}
              </p>
            )}
          </div>
        ))}

        {timers.map((t) => (
          <div
            key={t.id}
            className="rounded-[24px] bg-white/90 px-4 py-5 text-center shadow-soft"
          >
            <div className="text-[11px] text-tt-muted">
              {t.started ? "剩余" : `准备 ${t.duration} 秒`}
            </div>
            <div
              className="mt-1 font-semibold tabular-nums"
              style={{ fontSize: 48, lineHeight: 1 }}
            >
              {t.started ? t.remaining : t.duration}
              <span className="ml-1 text-base font-medium text-tt-muted">秒</span>
            </div>
            <div className="mt-4">
              <CuteButton
                label={t.started ? "再来一次" : "开始计时"}
                tone="mint"
                onClick={() => onInteract(t.id, "start")}
              />
            </div>
          </div>
        ))}

        {switches.map((s) => (
          <button
            key={s.id}
            type="button"
            onClick={() => onInteract(s.id, "toggle")}
            className="flex w-full items-center justify-between rounded-[20px] bg-white/85 px-4 py-3.5 shadow-soft"
          >
            <div className="flex items-center gap-2 text-sm">
              <PartIcon type="switch" size={28} />
              小开关
            </div>
            <span
              className={`rounded-full px-3 py-1 text-xs ${
                s.on ? "bg-emerald-100 text-emerald-800" : "bg-tt-bg text-tt-muted"
              }`}
            >
              {s.on ? "开" : "关"}
            </span>
          </button>
        ))}

        {streakNode ? (
          <div className="rounded-[22px] bg-white/90 px-4 py-5 text-center shadow-soft">
            <div className="text-[11px] text-tt-muted">连续天数</div>
            <div className="mt-1 text-4xl font-semibold tabular-nums">{streak}</div>
          </div>
        ) : null}

        {buttons.length > 0 ? (
          <div className="space-y-2 pt-1">
            {buttons.map((n, i) => (
              <CuteButton
                key={n.id}
                label={String(n.config.label ?? getBlock("button")?.label ?? "点我")}
                tone={i === 0 ? primary : i % 2 ? "violet" : "pink"}
                onClick={() => onInteract(n.id, "press")}
              />
            ))}
          </div>
        ) : null}
      </div>
    </PlayDeviceShell>
  );
}
