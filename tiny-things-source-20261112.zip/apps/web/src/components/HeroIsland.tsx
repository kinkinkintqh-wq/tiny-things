import Image from "next/image";
import { ART } from "@/lib/art";

export function HeroIsland() {
  return (
    <div className="relative hero-island relative aspect-[5/4] w-full">
      <Image
        src={ART.hero}
        alt="漂浮小岛上的微缩工作室"
        fill
        priority
        sizes="(max-width:768px) 100vw, 58vw"
        className="object-contain object-center animate-[floaty_7s_ease-in-out_infinite]"
      />
    </div>
  );
}
