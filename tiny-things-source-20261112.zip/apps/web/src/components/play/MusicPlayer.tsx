"use client";
import { useEffect, useRef, useState } from "react";
import { MUSIC_TRACKS, type MusicTrack } from "@/lib/music";

export function MusicPlayer({ preferredTrack = "musicbox" }: { preferredTrack?: MusicTrack }) {
  const audio = useRef<HTMLAudioElement | null>(null);
  const request = useRef({ id: 0 });
  const [track, setTrack] = useState<MusicTrack>(preferredTrack);
  const [playing, setPlaying] = useState(false);
  const [volume, setVolume] = useState(.35);
  const [error, setError] = useState("");
  useEffect(() => {
    const el = audio.current;
    const generation = request.current;
    const stop = () => { if (document.hidden) { request.current.id++; el?.pause(); } };
    document.addEventListener("visibilitychange", stop);
    return () => { generation.id++; el?.pause(); document.removeEventListener("visibilitychange", stop); };
  }, []);
  useEffect(() => {
    request.current.id++;
    audio.current?.pause(); setTrack(preferredTrack); setPlaying(false); setError("");
  }, [preferredTrack]);
  useEffect(() => { if (audio.current) audio.current.volume = volume; }, [volume]);
  async function play(next: MusicTrack = track) {
    if (next === "none" || !audio.current) return;
    const seq = ++request.current.id;
    const el = audio.current;
    if (!el.currentSrc.endsWith(`/audio/${next}.wav`)) { el.src = `/audio/${next}.wav`; el.load(); }
    el.volume = volume;
    setError("");
    try { await el.play(); if (seq === request.current.id) setPlaying(true); }
    catch { if (seq === request.current.id) { setPlaying(false); setError("没放出来，再轻点一次音符试试"); } }
  }
  function choose(next: MusicTrack) {
    const resume = playing;
    request.current.id++; audio.current?.pause();
    setTrack(next); setPlaying(false); setError("");
    if (resume && next !== "none") void play(next);
  }
  function toggle() {
    if (playing) { request.current.id++; audio.current?.pause(); setPlaying(false); }
    else void play();
  }
  return <div className="tiny-music-wrap">
    <audio ref={audio} loop preload="none" data-testid="background-audio" onPause={() => setPlaying(false)} onError={() => { setPlaying(false); setError("小曲子暂时没加载好，请再试一次"); }} />
    <div className={`tiny-music ${playing ? "is-playing" : ""}`}>
      <button type="button" className="music-record" aria-label={playing ? "暂停背景音乐" : "播放背景音乐"} aria-pressed={playing} disabled={track === "none"} onClick={toggle}><span aria-hidden="true">♪</span></button>
      <label className="music-choice"><span className="sr-only">背景音乐</span><select aria-label="背景音乐" value={track} onChange={(e) => choose(e.target.value as MusicTrack)}>{MUSIC_TRACKS.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}<option value="none">安静地玩</option></select><small>{playing ? "正在轻轻播放" : "轻点音符，听一小会儿"}</small></label>
      <label className="music-volume"><span className="sr-only">音乐音量</span><input aria-label="音乐音量" type="range" min="0" max="1" step="0.05" value={volume} onChange={(e) => setVolume(Number(e.target.value))} /></label>
    </div>
    {error && <p role="status" className="mt-1 text-center text-[11px] text-tt-muted">{error}</p>}
  </div>;
}
