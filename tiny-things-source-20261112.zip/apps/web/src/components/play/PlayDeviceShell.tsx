"use client";

export function PlayDeviceShell({
  eyebrow,
  title,
  children,
  flash,
}: {
  eyebrow?: string;
  title?: string;
  children: React.ReactNode;
  flash?: string | null;
}) {
  return (
    <div className="play-device relative overflow-hidden rounded-[28px] border border-white/90 bg-gradient-to-b from-[#fff9fd] via-[#f4f0ff] to-[#eef6ff] p-5 shadow-panel">
      <div
        className="pointer-events-none absolute inset-0 opacity-80"
        style={{
          background:
            "radial-gradient(90% 70% at 100% 0%, #ffd6ea88, transparent 50%), radial-gradient(70% 60% at 0% 100%, #cfe0ff77, transparent 55%)",
        }}
      />
      <div className="relative space-y-4">
        {(eyebrow || title) && (
          <div className="text-center">
            {eyebrow ? (
              <div className="text-[11px] tracking-[0.16em] text-tt-muted">{eyebrow}</div>
            ) : null}
            {title ? (
              <div className="mt-1 text-lg font-semibold text-tt-ink">{title}</div>
            ) : null}
          </div>
        )}
        {children}
        {flash ? (
          <p className="rounded-full bg-white/95 px-4 py-2 text-center text-sm text-tt-deep shadow-soft">
            {flash}
          </p>
        ) : null}
      </div>
    </div>
  );
}
