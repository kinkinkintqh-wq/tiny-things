"use client";
import { useEffect, useRef, useState, type CSSProperties } from "react";

const DOTS: Record<number, number[]> = { 1: [4], 2: [0,8], 3: [0,4,8], 4: [0,2,6,8], 5: [0,2,4,6,8], 6: [0,2,3,5,6,8] };
const ROTATIONS: Record<number, string> = { 1:"rotateX(-12deg) rotateY(-14deg)", 2:"rotateX(-102deg) rotateY(-14deg)", 3:"rotateX(-12deg) rotateY(-104deg)", 4:"rotateX(-12deg) rotateY(76deg)", 5:"rotateX(78deg) rotateY(-14deg)", 6:"rotateX(-12deg) rotateY(166deg)" };
export function DiceLetterDevice({ name, last, signalCount, need, match, body, opened, unlocked, onRoll, onOpen, recipient = "最可爱的你", sender = "", letterTitle = "有些话，想亲手交给你", rule = "matches" }: {
  name?: string; last: string | null; signalCount: number; need: number; match: string; body: string; opened: boolean; unlocked: boolean;
  flash?: string | null; onRoll: () => void; onOpen: () => void; recipient?: string; sender?: string; letterTitle?: string; rule?: string;
}) {
  const [rolling, setRolling] = useState(false);
  const timeout = useRef<ReturnType<typeof setTimeout> | null>(null);
  useEffect(() => () => { if (timeout.current) clearTimeout(timeout.current); }, []);
  const target = Math.max(1, Number.isFinite(need) ? Math.floor(need) : 1);
  const filled = Math.min(signalCount, target);
  const canRead = unlocked;
  const face = Number(last ?? 1);
  const sum = rule === "sum";
  const milestones = sum ? 3 : Math.min(target, 5);
  function roll() {
    if (rolling || canRead) return;
    setRolling(true); onRoll();
    timeout.current = setTimeout(() => setRolling(false), 650);
  }
  const status = rolling ? "小骰子正在酝酿好运…" : canRead ? "小心意已送达，点开信封吧" : !last ? "轻轻摇一下，让好运靠近你" : sum ? `这次是 ${last} 点，再收集 ${Math.max(0, target - filled)} 点` : last === match || !match ? "收集到一颗小心心 ♡" : `掷出了 ${last}，再试一次，好运在路上`;
  const envelope = <div className={`love-envelope-scene ${canRead ? "is-unlocked" : ""} ${opened && canRead ? "is-open" : ""}`}>
      {opened && canRead ? <article className="love-letter" data-testid="opened-letter"><span className="letter-tape" aria-hidden="true" /><span className="letter-small-heart" aria-hidden="true">♡</span><p className="letter-to">To. {recipient || "最可爱的你"}</p><h3>{letterTitle}</h3><p className="letter-body">{body || "有你在，平凡的日子也会闪闪发光。"}</p>{sender && <p className="letter-from">偷偷喜欢你的，{sender}</p>}<span className="letter-bottom-heart" aria-hidden="true">made with a little love ♡</span></article> : <button type="button" className="love-envelope" disabled={!canRead || rolling} onClick={onOpen} aria-label={canRead ? "拆开信封" : "信封尚未解锁"} data-testid="love-envelope"><span className="envelope-back" /><span className="envelope-note">TO. {recipient || "YOU"}</span><span className="envelope-front" /><span className="envelope-flap" /><span className="envelope-seal" aria-hidden="true">♥</span></button>}
    </div>;
  return <div className={`love-device ${opened && canRead ? "is-open" : ""}`} data-testid="love-device">
    <span className="love-sticker love-sticker-star" aria-hidden="true">✦</span><span className="love-sticker love-sticker-heart" aria-hidden="true">♡</span>
    <div className="love-device-heading"><span className="love-eyebrow">A LITTLE SURPRISE, JUST FOR YOU</span><h2>{name || "给你的一点小心意"}</h2><p>给 {recipient || "最可爱的你"} 的专属投递</p></div>
    {!opened && <>
      <div className="love-challenge"><span>小小约定</span><p>{sum ? <>累计掷出 <strong>{target}</strong> 点，就能拆开这封信</> : <>收集 <strong>{target}</strong> 次 <strong>{match || "任意"}</strong> 点，就能拆开这封信</>}</p></div>
      <div className="love-game-scene">
        <div className="love-cloud cloud-left" aria-hidden="true" /><div className="love-cloud cloud-right" aria-hidden="true" />
        <span className="scene-spark s1" aria-hidden="true">✧</span><span className="scene-spark s2" aria-hidden="true">✦</span>
        <button type="button" className="love-dice-button" onClick={roll} disabled={rolling || canRead} aria-label="掷骰子" data-testid="love-dice">
          <span className={`love-dice ${rolling ? "is-rolling" : ""}`} style={{ transform: ROTATIONS[face] ?? ROTATIONS[1] } as CSSProperties} aria-hidden="true">
            {[1,2,3,4,5,6].map((number) => <span key={number} className={`dice-face face-${number}`}>{Array.from({length:9}, (_,i) => <i key={i} className={DOTS[number].includes(i) ? "pip" : ""} />)}</span>)}
          </span>
          <span className="dice-ground" aria-hidden="true" />
        </button>
        <div className="love-toy-envelope">{envelope}</div>
        <span className="dice-tap-note">{canRead ? "愿望已达成 ♡" : rolling ? "摇呀摇…" : "戳一下小骰子"}</span>
      </div>
      <div className="love-progress" aria-label={`解锁进度 ${filled}/${target}`}><div className="love-hearts" aria-hidden="true">{Array.from({length:milestones}, (_,i) => <span key={i} className={filled >= Math.ceil((i+1)*target/milestones) ? "collected" : ""}>♥</span>)}</div><span>{sum ? `已收集 ${filled} / ${target} 点` : `小心心 ${filled} / ${target}`}</span><div className="love-progress-track"><i style={{width:`${100*filled/target}%`}} /></div></div>
      <p className="love-game-status" role="status">{status}</p>
    </>}
    {opened && canRead && envelope}
    <p className="love-envelope-caption">{opened && canRead ? "这一次，把心意好好接住了。" : canRead ? "封蜡亮起来了，轻点爱心拆信 ♡" : "这里藏着一封，还没说出口的信。"}</p>
    <div className="love-device-footer" aria-hidden="true"><span>✿</span><span>今天的好运，是遇见你</span><span>✿</span></div>
  </div>;
}
