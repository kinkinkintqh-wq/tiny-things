"use client";

import { useEffect, useState } from "react";
import { subscribeToast } from "@/lib/toast";

export function ToastHost() {
  const [msg, setMsg] = useState<{
    text: string;
    tone?: "info" | "error" | "ok";
  } | null>(null);

  useEffect(() => subscribeToast(setMsg), []);

  if (!msg) return null;
  const tone =
    msg.tone === "error"
      ? "border-red-200 bg-red-50 text-red-900"
      : msg.tone === "ok"
        ? "border-emerald-200 bg-emerald-50 text-emerald-900"
        : "border-tt-border bg-tt-panel text-tt-ink";

  return (
    <div
      role="status"
      className={`fixed bottom-6 right-6 z-[80] max-w-sm rounded-card border px-4 py-3 text-sm shadow-panel ${tone}`}
    >
      {msg.text}
    </div>
  );
}
