"use client";

import Image from "next/image";
import { partArt } from "@/lib/art";

export function PartIcon({
  type,
  size = 44,
}: {
  type: string;
  size?: number;
}) {
  return (
    <Image
      src={partArt(type)}
      alt=""
      width={size}
      height={size}
      className="rounded-2xl object-cover shadow-soft"
      unoptimized
    />
  );
}

export function CategoryIcon({
  id,
  size = 28,
}: {
  id: string;
  size?: number;
}) {
  const map: Record<string, string> = {
    all: "proofCard",
    life: "dateGate",
    study: "timer",
    mood: "button",
    play: "random",
  };
  return <PartIcon type={map[id] ?? "button"} size={size} />;
}

export function ValueIcon({
  kind,
}: {
  kind: "code" | "usable" | "share" | "tapeout";
}) {
  const src =
    kind === "code"
      ? partArt("button")
      : kind === "usable"
        ? partArt("counter")
        : kind === "share"
          ? partArt("random")
          : partArt("switch");
  return (
    <Image
      src={src}
      alt=""
      width={40}
      height={40}
      className="rounded-2xl object-cover shadow-soft"
      unoptimized
    />
  );
}
