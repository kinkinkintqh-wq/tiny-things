import { compileGraph, encodeNetlist } from "@tinythings/compiler";
import type { DesignGraph } from "@tinythings/schema";
import { eq } from "drizzle-orm";
import { Hono } from "hono";
import { nanoid } from "nanoid";
import { db } from "../db/client";
import { compilations } from "../db/schema";
import { apiError } from "../lib/errors";
import { manifestHash } from "../lib/hash";

export const compileRoutes = new Hono();

compileRoutes.post("/compilations", async (c) => {
  const body = await c.req.json();
  const graph = body.graph as DesignGraph | undefined;
  if (!graph?.nodes) return apiError(c, 400, "bad_request", "需要 graph");

  const sourceHash = manifestHash(graph);
  const id = `cmp_${nanoid(10)}`;
  const result = compileGraph(graph);
  const encoded = result.netlist
    ? Buffer.from(encodeNetlist(result.netlist)).toString("hex")
    : null;

  await db.insert(compilations).values({
    id,
    ownerId: c.get("userId") as string,
    sourceHash,
    status: result.netlist ? "succeeded" : "unsupported",
    result: {
      ...result,
      netlistHex: encoded,
      compilerVersion: "tiny-compiler/0.1.0",
    },
  });

  return c.json(
    {
      jobId: id,
      status: result.netlist ? "succeeded" : "unsupported",
      sourceHash,
      diagnostics: result.ir.diagnostics,
      report: result.report,
      netlist: result.netlist
        ? {
            nIn: result.netlist.nIn,
            nOut: result.netlist.nOut,
            nState: result.netlist.nState,
            gateCount: result.netlist.gates.length,
            hex: encoded,
          }
        : null,
      ir: result.ir,
    },
    202
  );
});

compileRoutes.get("/compilations/:id", async (c) => {
  const id = c.req.param("id");
  const rows = await db.select().from(compilations).where(eq(compilations.id, id)).limit(1);
  const row = rows[0];
  if (!row) return apiError(c, 404, "not_found", "编译任务不存在");
  if (row.ownerId !== c.get("userId")) return apiError(c, 403, "forbidden", "无权查看");
  return c.json({
    jobId: row.id,
    status: row.status,
    sourceHash: row.sourceHash,
    result: row.result,
  });
});

/** TapeOut cost: local estimate only (chain probe deferred). */
compileRoutes.post("/tapeout/cost", async (c) => {
  const body = await c.req.json().catch(() => ({}));
  const graph = body.graph as DesignGraph | undefined;
  if (!graph?.nodes) return apiError(c, 400, "bad_request", "需要 graph");
  const result = compileGraph(graph);
  const gateCount = result.report.gateCount ?? 0;

  return c.json({
    matched: Boolean(result.netlist),
    gateCount,
    depth: result.report.depth ?? 0,
    feeOkb: null,
    feeWei: null,
    verifiedFee: false,
    note: result.netlist
      ? "本地 NAND 结果 · 未提供流片报价；请在电路观察室读取目标合约"
      : "当前图尚未匹配 C0/C1，仅本地可运行",
    diagnostics: result.ir.diagnostics,
  });
});
