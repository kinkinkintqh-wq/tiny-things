import type { MiddlewareHandler } from "hono";
import { getCookie, setCookie } from "hono/cookie";
import { nanoid } from "nanoid";
import { db } from "../db/client";
import { users } from "../db/schema";
import { eq } from "drizzle-orm";
import {
  mintSessionToken,
  sessionCookieName,
  verifySessionToken,
} from "../lib/sessionToken";

export type AppVars = {
  requestId: string;
  userId: string;
  displayName: string;
};

export const withRequestId: MiddlewareHandler = async (c, next) => {
  const id = c.req.header("x-request-id") ?? nanoid(12);
  c.set("requestId", id);
  c.header("x-request-id", id);
  await next();
};

function setSessionCookie(c: Parameters<MiddlewareHandler>[0], userId: string) {
  setCookie(c, sessionCookieName(), mintSessionToken(userId), {
    path: "/",
    httpOnly: true,
    sameSite: "Lax",
    secure:
      process.env.COOKIE_SECURE === "true" ||
      process.env.NODE_ENV === "production",
    maxAge: 60 * 60 * 24 * 365,
  });
}

/**
 * Authenticated guest session via HMAC-signed cookie.
 * - Only signed tokens are trusted.
 * - New accounts are created only when we mint a fresh id (never from client input).
 */
export const withSession: MiddlewareHandler = async (c, next) => {
  // Drop legacy unsigned cookie if present so it cannot be confused with identity.
  const legacy = getCookie(c, "tt_uid");
  if (legacy) {
    setCookie(c, "tt_uid", "", { path: "/", maxAge: 0 });
  }

  const verifiedId = verifySessionToken(getCookie(c, sessionCookieName()));

  if (verifiedId) {
    const existing = await db
      .select()
      .from(users)
      .where(eq(users.id, verifiedId))
      .limit(1);
    if (existing[0]) {
      c.set("userId", existing[0].id);
      c.set("displayName", existing[0].displayName);
      await next();
      return;
    }
    // Signed but user row missing (DB reset) — mint a new account, do not recreate with old id from cookie alone without insert path we control.
  }

  const userId = `u_${nanoid(10)}`;
  const displayName = `创作者${userId.slice(-4)}`;
  await db.insert(users).values({ id: userId, displayName }).onConflictDoNothing();
  setSessionCookie(c, userId);
  c.set("userId", userId);
  c.set("displayName", displayName);
  await next();
};
