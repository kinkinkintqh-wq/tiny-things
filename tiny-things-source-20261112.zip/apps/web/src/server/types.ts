import "hono";

declare module "hono" {
  interface ContextVariableMap {
    requestId: string;
    userId: string;
    displayName: string;
  }
}
