import { createHash } from "node:crypto";

/** Canonical JSON (sorted keys) then keccak256-like digest via sha3-256 hex labeled. */
export function canonicalStringify(value: unknown): string {
  return JSON.stringify(sortValue(value));
}

function sortValue(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(sortValue);
  if (value && typeof value === "object") {
    const obj = value as Record<string, unknown>;
    const out: Record<string, unknown> = {};
    for (const key of Object.keys(obj).sort()) {
      out[key] = sortValue(obj[key]);
    }
    return out;
  }
  return value;
}

export function manifestHash(manifest: unknown): string {
  const bytes = Buffer.from(canonicalStringify(manifest), "utf8");
  const digest = createHash("sha256").update(bytes).digest("hex");
  return `sha256:${digest}`;
}

export function shortId(prefix = ""): string {
  return `${prefix}${createHash("sha256")
    .update(`${Date.now()}-${Math.random()}`)
    .digest("hex")
    .slice(0, 12)}`;
}
