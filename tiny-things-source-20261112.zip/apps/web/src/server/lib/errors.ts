import type { Context } from "hono";
import { nanoid } from "nanoid";

export function apiError(
  c: Context,
  status: number,
  code: string,
  message: string,
  extra?: { fieldPath?: string; nodeId?: string; retryable?: boolean }
) {
  return c.json(
    {
      code,
      message,
      fieldPath: extra?.fieldPath,
      nodeId: extra?.nodeId,
      requestId: c.get("requestId") ?? nanoid(10),
      retryable: extra?.retryable ?? false,
    },
    status as 400
  );
}
