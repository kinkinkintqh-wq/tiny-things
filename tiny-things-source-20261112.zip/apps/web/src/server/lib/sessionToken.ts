import { createHmac, randomBytes, timingSafeEqual } from "node:crypto";

const COOKIE_NAME = "tt_sid";

/** In-memory secret for local/dev only — never written to disk or shipped. */
let ephemeralDevSecret: string | null = null;

export function sessionCookieName() {
  return COOKIE_NAME;
}

export function sessionSecret(): string {
  const fromEnv = process.env.SESSION_SECRET?.trim();
  if (fromEnv) return fromEnv;
  // No secret is embedded in source. Until SESSION_SECRET is bound on the host,
  // use a process-local ephemeral key (sessions reset on restart).
  if (!ephemeralDevSecret) {
    ephemeralDevSecret = randomBytes(32).toString("hex");
  }
  return ephemeralDevSecret;
}

function sign(userId: string, secret: string): string {
  return createHmac("sha256", secret).update(userId).digest("base64url");
}

/** Mint a signed session value. Never put an unsigned user id in a cookie. */
export function mintSessionToken(userId: string): string {
  const secret = sessionSecret();
  return `${userId}.${sign(userId, secret)}`;
}

/**
 * Verify a signed session cookie. Returns userId only when signature matches.
 * Raw / forged ids are rejected — never used to look up or create accounts.
 */
export function verifySessionToken(token: string | undefined): string | null {
  if (!token) return null;
  const i = token.lastIndexOf(".");
  if (i <= 0) return null;
  const userId = token.slice(0, i);
  const sig = token.slice(i + 1);
  if (!userId.startsWith("u_") || !sig) return null;
  let expected: string;
  try {
    expected = sign(userId, sessionSecret());
  } catch {
    return null;
  }
  const a = Buffer.from(sig);
  const b = Buffer.from(expected);
  if (a.length !== b.length) return null;
  if (!timingSafeEqual(a, b)) return null;
  return userId;
}
