import {
  integer,
  jsonb,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/pg-core";

export const users = pgTable("users", {
  id: text("id").primaryKey(),
  displayName: varchar("display_name", { length: 80 }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const projects = pgTable("projects", {
  id: text("id").primaryKey(),
  ownerId: text("owner_id").notNull(),
  name: varchar("name", { length: 40 }).notNull(),
  visibility: varchar("visibility", { length: 16 }).notNull().default("private"),
  rootProjectId: text("root_project_id"),
  category: varchar("category", { length: 16 }).notNull().default("life"),
  description: text("description").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  deletedAt: timestamp("deleted_at", { withTimezone: true }),
});

export const drafts = pgTable("drafts", {
  id: text("id").primaryKey(),
  projectId: text("project_id").notNull(),
  schemaVersion: varchar("schema_version", { length: 32 }).notNull(),
  revision: integer("revision").notNull().default(0),
  graph: jsonb("graph").notNull(),
  layout: jsonb("layout").notNull(),
  theme: jsonb("theme").notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

export const releases = pgTable("releases", {
  id: text("id").primaryKey(),
  projectId: text("project_id").notNull(),
  version: integer("version").notNull(),
  parentReleaseId: text("parent_release_id"),
  slug: varchar("slug", { length: 64 }).notNull(),
  manifestHash: varchar("manifest_hash", { length: 80 }).notNull(),
  manifest: jsonb("manifest").notNull(),
  license: varchar("license", { length: 32 }).notNull().default("remixable"),
  visibility: varchar("visibility", { length: 16 }).notNull().default("public"),
  status: varchar("status", { length: 24 }).notNull().default("webPublished"),
  publishedAt: timestamp("published_at", { withTimezone: true }).defaultNow().notNull(),
  withdrawnAt: timestamp("withdrawn_at", { withTimezone: true }),
  withdrawReason: text("withdraw_reason"),
});

export const runtimeStates = pgTable(
  "runtime_states",
  {
    id: text("id").primaryKey(),
    releaseId: text("release_id").notNull(),
    subjectId: text("subject_id").notNull(),
    instanceId: text("instance_id").notNull(),
    revision: integer("revision").notNull().default(0),
    state: jsonb("state").notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => ({
    uniq: uniqueIndex("runtime_unique").on(t.releaseId, t.subjectId, t.instanceId),
  })
);

export const eventLog = pgTable("event_log", {
  id: text("id").primaryKey(),
  releaseId: text("release_id").notNull(),
  subjectId: text("subject_id").notNull(),
  eventId: text("event_id").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const favorites = pgTable("favorites", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull(),
  releaseId: text("release_id").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const anchors = pgTable("anchors", {
  id: text("id").primaryKey(),
  releaseId: text("release_id").notNull(),
  chainId: integer("chain_id").notNull(),
  registry: text("registry"),
  txHash: text("tx_hash"),
  blockHash: text("block_hash"),
  status: varchar("status", { length: 24 }).notNull().default("prepared"),
  manifestHash: varchar("manifest_hash", { length: 80 }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const compilations = pgTable("compilations", {
  id: text("id").primaryKey(),
  ownerId: text("owner_id").notNull(),
  sourceHash: varchar("source_hash", { length: 80 }).notNull(),
  status: varchar("status", { length: 24 }).notNull().default("queued"),
  result: jsonb("result"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const stats = pgTable("release_stats", {
  releaseId: text("release_id").primaryKey(),
  views: integer("views").notNull().default(0),
  likes: integer("likes").notNull().default(0),
  uses: integer("uses").notNull().default(0),
});
