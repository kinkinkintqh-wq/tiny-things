import { blockVersions, draftFromTemplate } from "@tinythings/block-registry";
import { SCHEMA_VERSION } from "@tinythings/schema";
import { db, sql } from "./client";
import { drafts, projects, releases, stats, users } from "./schema";
import { manifestHash } from "../lib/hash";

async function main() {
  const ownerId = "u_official";
  await db
    .insert(users)
    .values({ id: ownerId, displayName: "Tiny Things 官方" })
    .onConflictDoNothing();

  const templates = ["daily-checkin", "habit-builder", "random-task-box"] as const;
  for (const tid of templates) {
    const draft = draftFromTemplate(tid);
    const projectId = `p_official_${tid}`;
    const draftId = `d_official_${tid}`;
    const releaseId = `r_official_${tid}`;

    await db
      .insert(projects)
      .values({
        id: projectId,
        ownerId,
        name: draft.name,
        visibility: "public",
        rootProjectId: projectId,
        category: tid === "random-task-box" ? "play" : "life",
        description: draft.name,
      })
      .onConflictDoNothing();

    await db
      .insert(drafts)
      .values({
        id: draftId,
        projectId,
        schemaVersion: SCHEMA_VERSION,
        revision: 1,
        graph: draft.graph,
        layout: draft.layout,
        theme: draft.theme,
      })
      .onConflictDoNothing();

    const manifest = {
      schemaVersion: SCHEMA_VERSION,
      graph: draft.graph,
      layout: draft.layout,
      theme: draft.theme,
      blockVersions: blockVersions(),
      assets: [],
      license: "remixable",
      parentReleaseId: null,
      category: tid === "random-task-box" ? "play" : "life",
      description: draft.name,
      coverUrl: null,
    };
    const hash = manifestHash(manifest);

    await db
      .insert(releases)
      .values({
        id: releaseId,
        projectId,
        version: 1,
        parentReleaseId: null,
        slug: tid,
        manifestHash: hash,
        manifest,
        license: "remixable",
        visibility: "public",
        status: "webPublished",
      })
      .onConflictDoNothing();

    await db
      .insert(stats)
      .values({ releaseId, views: 0, likes: 0, uses: 0 })
      .onConflictDoNothing();
  }

  console.log("Seeded official templates.");
  await sql.end();
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
