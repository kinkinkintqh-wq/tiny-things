import { blockVersions, draftFromTemplate } from "@tinythings/block-registry";
import { SCHEMA_VERSION } from "@tinythings/schema";
import { sql, db } from "./client";
import { drafts, projects, releases, stats, users } from "./schema";
import { manifestHash } from "../lib/hash";

let migrating: Promise<void> | null = null;
let ready = false;

async function seedOfficial() {
  const ownerId = "u_official";
  await db
    .insert(users)
    .values({ id: ownerId, displayName: "Tiny Things 官方" })
    .onConflictDoNothing();

  const templates = [
    "daily-checkin",
    "habit-builder",
    "random-task-box",
    "dice-letter",
  ] as const;
  for (const tid of templates) {
    const draft = draftFromTemplate(tid);
    const projectId = `p_official_${tid}`;
    const draftId = `d_official_${tid}`;
    const releaseId = `r_official_${tid}`;
    const category = tid === "random-task-box" ? "play" : "life";

    await db
      .insert(projects)
      .values({
        id: projectId,
        ownerId,
        name: draft.name,
        visibility: "public",
        rootProjectId: projectId,
        category,
        description: draft.name,
      })
      .onConflictDoNothing();

    await db
      .insert(drafts)
      .values({
        id: draftId,
        projectId,
        schemaVersion: SCHEMA_VERSION,
        revision: 1,
        graph: draft.graph,
        layout: draft.layout,
        theme: draft.theme,
      })
      .onConflictDoNothing();

    const manifest = {
      schemaVersion: SCHEMA_VERSION,
      graph: draft.graph,
      layout: draft.layout,
      theme: draft.theme,
      blockVersions: blockVersions(),
      assets: [],
      license: "remixable" as const,
      parentReleaseId: null,
      category,
      description: draft.name,
      coverUrl: null,
    };

    await db
      .insert(releases)
      .values({
        id: releaseId,
        projectId,
        version: 1,
        parentReleaseId: null,
        slug: tid,
        manifestHash: manifestHash(manifest),
        manifest,
        license: "remixable",
        visibility: "public",
        status: "webPublished",
      })
      .onConflictDoNothing();

    await db
      .insert(stats)
      .values({ releaseId, views: 0, likes: 0, uses: 0 })
      .onConflictDoNothing();
  }
}

/** Idempotent schema bootstrap for published / cold-start environments. */
export function ensureSchema(): Promise<void> {
  if (ready) return Promise.resolve();
  if (migrating) return migrating;
  migrating = (async () => {
    await sql`
      CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY,
        display_name VARCHAR(80) NOT NULL,
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      );
    `;
    await sql`
      CREATE TABLE IF NOT EXISTS projects (
        id TEXT PRIMARY KEY,
        owner_id TEXT NOT NULL,
        name VARCHAR(40) NOT NULL,
        visibility VARCHAR(16) NOT NULL DEFAULT 'private',
        root_project_id TEXT,
        category VARCHAR(16) NOT NULL DEFAULT 'life',
        description TEXT NOT NULL DEFAULT '',
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        deleted_at TIMESTAMPTZ
      );
    `;
    await sql`
      CREATE TABLE IF NOT EXISTS drafts (
        id TEXT PRIMARY KEY,
        project_id TEXT NOT NULL,
        schema_version VARCHAR(32) NOT NULL,
        revision INTEGER NOT NULL DEFAULT 0,
        graph JSONB NOT NULL,
        layout JSONB NOT NULL,
        theme JSONB NOT NULL,
        updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      );
    `;
    await sql`
      CREATE TABLE IF NOT EXISTS releases (
        id TEXT PRIMARY KEY,
        project_id TEXT NOT NULL,
        version INTEGER NOT NULL,
        parent_release_id TEXT,
        slug VARCHAR(64) NOT NULL,
        manifest_hash VARCHAR(80) NOT NULL,
        manifest JSONB NOT NULL,
        license VARCHAR(32) NOT NULL DEFAULT 'remixable',
        visibility VARCHAR(16) NOT NULL DEFAULT 'public',
        status VARCHAR(24) NOT NULL DEFAULT 'webPublished',
        published_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        withdrawn_at TIMESTAMPTZ,
        withdraw_reason TEXT
      );
    `;
    await sql`
      CREATE TABLE IF NOT EXISTS runtime_states (
        id TEXT PRIMARY KEY,
        release_id TEXT NOT NULL,
        subject_id TEXT NOT NULL,
        instance_id TEXT NOT NULL,
        revision INTEGER NOT NULL DEFAULT 0,
        state JSONB NOT NULL,
        updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      );
    `;
    await sql`
      CREATE UNIQUE INDEX IF NOT EXISTS runtime_unique
      ON runtime_states (release_id, subject_id, instance_id);
    `;
    await sql`
      CREATE TABLE IF NOT EXISTS event_log (
        id TEXT PRIMARY KEY,
        release_id TEXT NOT NULL,
        subject_id TEXT NOT NULL,
        event_id TEXT NOT NULL,
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      );
    `;
    await sql`
      CREATE UNIQUE INDEX IF NOT EXISTS event_dedupe
      ON event_log (release_id, subject_id, event_id);
    `;
    await sql`
      CREATE TABLE IF NOT EXISTS favorites (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        release_id TEXT NOT NULL,
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      );
    `;
    await sql`
      CREATE TABLE IF NOT EXISTS anchors (
        id TEXT PRIMARY KEY,
        release_id TEXT NOT NULL,
        chain_id INTEGER NOT NULL,
        registry TEXT,
        tx_hash TEXT,
        block_hash TEXT,
        status VARCHAR(24) NOT NULL DEFAULT 'prepared',
        manifest_hash VARCHAR(80) NOT NULL,
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      );
    `;
    await sql`
      CREATE TABLE IF NOT EXISTS compilations (
        id TEXT PRIMARY KEY,
        owner_id TEXT NOT NULL,
        source_hash VARCHAR(80) NOT NULL,
        status VARCHAR(24) NOT NULL DEFAULT 'queued',
        result JSONB,
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      );
    `;
    await sql`
      CREATE TABLE IF NOT EXISTS release_stats (
        release_id TEXT PRIMARY KEY,
        views INTEGER NOT NULL DEFAULT 0,
        likes INTEGER NOT NULL DEFAULT 0,
        uses INTEGER NOT NULL DEFAULT 0
      );
    `;
    await seedOfficial();
    ready = true;
  })().finally(() => {
    migrating = null;
  });
  return migrating;
}
