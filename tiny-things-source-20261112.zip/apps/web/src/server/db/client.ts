import { drizzle } from "drizzle-orm/postgres-js";
import postgres from "postgres";
import * as schema from "./schema";

/**
 * Database URL comes only from the environment (Cursor Apps injects DATABASE_URL
 * when cursor-app.json requests postgres). No passwords are embedded in source.
 */
function requireDatabaseUrl(): string {
  const url = process.env.DATABASE_URL?.trim();
  if (!url) {
    throw new Error(
      "DATABASE_URL is not set. For local dev, put it in .env.local (gitignored)."
    );
  }
  return url;
}

const url = requireDatabaseUrl();

export const sql = postgres(url, {
  max: process.env.NODE_ENV === "production" ? 1 : 10,
  idle_timeout: 20,
  prepare: false,
});
export const db = drizzle(sql, { schema });
