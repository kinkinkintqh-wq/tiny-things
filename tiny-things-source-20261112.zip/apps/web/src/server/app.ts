import "./types";
import { Hono } from "hono";
import { ensureSchema } from "./db/ensure";
import { withRequestId, withSession } from "./middleware/session";
import { compileRoutes } from "./routes/compile";
import { projectRoutes } from "./routes/projects";

export const app = new Hono().basePath("/api/v1");

app.use("*", async (c, next) => {
  try {
    await ensureSchema();
  } catch (err) {
    console.error("[tinythings] schema ensure failed", err);
    return c.json(
      {
        code: "db_unavailable",
        message: "数据库暂不可用，请稍后重试",
        requestId: c.req.header("x-request-id") ?? "boot",
        retryable: true,
      },
      503
    );
  }
  await next();
});
app.use("*", withRequestId);
app.use("*", withSession);

app.get("/health", (c) => c.json({ ok: true, service: "tinythings-web-api" }));
app.route("/", projectRoutes);
app.route("/", compileRoutes);
