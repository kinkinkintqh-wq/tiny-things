import { decodeNetlist, evalNand, packBits, unpackBits } from "@tinythings/compiler";

// Function selectors independently generated from the signatures with viem.
export const SELECTOR = { info: "0x084d60f1", netlist: "0x3fc4be56", eval: "0x934d06ea", factory: "0xc45a0155", isCPU: "0x5f5a364f", cpus: "0xd2c26963", fee: "0xadfb2b69" };
export const FACTORY = "0x1f09daefa827f02cbb40967cc91b259763760761";
const ENDPOINTS = ["https://rpc.xlayer.tech", "https://xlayerrpc.okx.com"];
const word = (n: bigint | number) => BigInt(n).toString(16).padStart(64, "0");
function bytes(hex: string) { if (!/^0x(?:[0-9a-f]{2})*$/i.test(hex)) throw new Error("RPC 字节格式无效"); return Uint8Array.from(hex.slice(2).match(/../g) ?? [], (b) => parseInt(b, 16)); }
function hex(bytes: Uint8Array) { return `0x${Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("")}`; }
function dynamicBytes(value: string) {
  const raw = bytes(value);
  if (raw.length < 64) throw new Error("合约返回值被截断");
  const offset = Number(BigInt(`0x${value.slice(2, 66)}`));
  if (!Number.isSafeInteger(offset) || offset < 32 || offset % 32 || offset + 32 > raw.length) throw new Error("合约返回偏移无效");
  const length = Number(BigInt(hex(raw.slice(offset, offset + 32))));
  if (!Number.isSafeInteger(length) || length < 0 || length > 100_000 || offset + 32 + length > raw.length) throw new Error("合约返回字节长度无效");
  return raw.slice(offset + 32, offset + 32 + length);
}

export async function readCircuit(processorInput: string, circuitIdInput: string) {
  if (processorInput && !/^0x[0-9a-f]{40}$/i.test(processorInput)) throw new Error("请输入有效的 Circuits 合约地址");
  if (!/^\d{1,20}$/.test(circuitIdInput) || BigInt(circuitIdInput) < BigInt(1)) throw new Error("电路 ID 需为正整数");
  let lastError: unknown;
  for (const rpcUrl of ENDPOINTS) {
    try {
      let requestId = 0;
      async function rpc<T>(method: string, params: unknown[]): Promise<T> {
        const response = await fetch(rpcUrl, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ jsonrpc: "2.0", id: ++requestId, method, params }), signal: AbortSignal.timeout(12_000), cache: "no-store" });
        const data = await response.json();
        if (!response.ok || data.error || data.result === undefined) throw new Error(data.error?.message ?? `RPC ${response.status}`);
        return data.result as T;
      }
      const chainId = Number(BigInt(await rpc<string>("eth_chainId", [])));
      if (chainId !== 196) throw new Error("RPC 网络不符，停止验证");
      const block = await rpc<{ number: string; hash: string }>("eth_getBlockByNumber", ["latest", false]);
      const call = (to: string, data: string) => rpc<string>("eth_call", [{ to, data }, block.number]);
      const processor = processorInput || `0x${(await call(FACTORY, SELECTOR.cpus + word(0))).slice(-40)}`;
      if (!/^0x[0-9a-f]{40}$/i.test(processor)) throw new Error("Factory 返回的合约地址无效");
      const registered = BigInt(await call(FACTORY, SELECTOR.isCPU + processor.slice(2).padStart(64, "0"))) === BigInt(1);
      if (!registered) throw new Error("该合约未在配置的 TapeOut Factory 注册");
      const factory = `0x${(await call(processor, SELECTOR.factory)).slice(-40)}`;
      if (factory.toLowerCase() !== FACTORY) throw new Error("Circuits 合约的 Factory 不匹配");
      const id = word(BigInt(circuitIdInput));
      const info = await call(processor, SELECTOR.info + id);
      if (!/^0x[0-9a-f]{256}$/i.test(info)) throw new Error("circuitInfo ABI 返回值不匹配");
      const [nIn, nOut, nState, gateCount] = Array.from({ length: 4 }, (_, i) => Number(BigInt(`0x${info.slice(2 + i * 64, 66 + i * 64)}`)));
      const feeWei = BigInt(await call(processor, SELECTOR.fee)).toString();
      const base = { chainId, rpcUrl, processor, circuitId: circuitIdInput, factory, blockNumber: BigInt(block.number).toString(), blockHash: block.hash, checkedAt: new Date().toISOString(), registered, nIn, nOut, nState, gateCount, feeWei };
      if (nState !== 0 || nIn > 4 || nOut < 1 || nOut > 32 || gateCount > 2000) return { ...base, verified: false, vectors: [], note: "合约信息已读取；逐位验证仅支持 ≤4 输入、≤2000 NAND 门且不含状态/REF 的组合电路。" };
      const netlistBytes = dynamicBytes(await call(processor, SELECTOR.netlist + id));
      let net;
      try { net = decodeNetlist(netlistBytes, nIn, nOut); }
      catch { return { ...base, verified: false, vectors: [], note: "电路包含本地解码器不支持的元素（如 REF/LATCH），未宣称比对通过。" }; }
      const vectors: Array<{ input: boolean[]; local: boolean[]; chain: boolean[]; match: boolean }> = [];
      for (let mask = 0; mask < 2 ** nIn; mask++) {
        const input = Array.from({ length: nIn }, (_, i) => Boolean((mask >>> i) & 1));
        const packed = packBits(input);
        const payload = SELECTOR.eval + id + word(64) + word(packed.length) + hex(packed).slice(2).padEnd(Math.ceil(packed.length / 32) * 64, "0");
        const output = dynamicBytes(await call(processor, payload));
        if (output.length < Math.ceil(nOut / 8)) throw new Error("电路输出字节不足");
        const chain = unpackBits(output, nOut);
        const local = evalNand(net, input);
        vectors.push({ input, local, chain, match: local.every((bit, i) => bit === chain[i]) });
      }
      const finalBlock = await rpc<{ hash: string }>("eth_getBlockByNumber", [block.number, false]);
      if (finalBlock.hash !== block.hash) throw new Error("读取期间区块发生变化，请重新验证");
      return { ...base, netlistHex: hex(netlistBytes), verified: vectors.every((v) => v.match), vectors, note: "仅验证此链、此合约、此 ID、此区块的电路输出；不代表当前作品已流片。" };
    } catch (err) { lastError = err; }
  }
  throw lastError instanceof Error ? lastError : new Error("X Layer RPC 暂不可用");
}
