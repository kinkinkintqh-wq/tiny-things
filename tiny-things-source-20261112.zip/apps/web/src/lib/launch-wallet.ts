export interface WalletProvider {
 request(args:{method:string;params?:unknown[]}):Promise<unknown>;
 on?(name:string,listener:(...args:unknown[])=>void):void;
 removeListener?(name:string,listener:(...args:unknown[])=>void):void;
}
export interface WalletChoice {id:string;name:string;provider:WalletProvider}
export interface LaunchJournal {account:string;confirmed:number;hashes:string[];uncertain:boolean}
export function walletMessage(error:unknown):string {
 const e=error&&typeof error==='object'?error as {code?:unknown;message?:unknown}:null;
 if(e?.code===4001)return '你已取消钱包请求，可以准备好后重新连接。';
 if(e?.code===-32002)return '钱包已有待处理请求，请打开 OKX Wallet 完成或取消原请求，再回来连接。';
 return typeof e?.message==='string'?e.message.slice(0,500):'这次没有完成，请打开钱包检查待处理请求和交易记录';
}
// Only connection/read requests time out. A timeout cannot cancel an extension popup.
// Never use this wrapper for signing or sending transactions: an unknown send must stay uncertain.
export async function walletRead<T>(request:()=>Promise<T>,timeoutMs=30000):Promise<T>{
 let timer:ReturnType<typeof setTimeout>|undefined;
 try{return await Promise.race([Promise.resolve().then(request),new Promise<never>((_,reject)=>{
  timer=setTimeout(()=>reject(Error('钱包暂未回应。请打开 OKX Wallet 查看待处理连接请求；超时没有取消钱包请求，也没有发送交易。')),timeoutMs);
 })]);}finally{if(timer!==undefined)clearTimeout(timer);}
}
export async function connectAccounts(provider:WalletProvider):Promise<unknown>{
 const existing=await walletRead(()=>provider.request({method:'eth_accounts'}),6000);
 if(Array.isArray(existing)&&existing.length)return existing;
 return walletRead(()=>provider.request({method:'eth_requestAccounts'}));
}
export const JOURNAL_KEY='tinythings:letter-launch:c3e83ac2:v1';
export function parseJournal(raw:string|null):LaunchJournal|null {
 if(!raw)return null;
 try{const j=JSON.parse(raw);if(!/^0x[0-9a-f]{40}$/i.test(j.account)||!Number.isInteger(j.confirmed)||j.confirmed<0||j.confirmed>4||!Array.isArray(j.hashes)||j.hashes.length<j.confirmed||j.hashes.length>Math.min(4,j.confirmed+1)||j.hashes.some((h:unknown)=>typeof h!=='string'||!/^0x[0-9a-f]{64}$/i.test(h))||new Set(j.hashes.map((h:string)=>h.toLowerCase())).size!==j.hashes.length||typeof j.uncertain!=='boolean')return null;return j;}catch{return null;}
}
export async function assertWallet(provider:WalletProvider,account:string){
 const chain=await provider.request({method:'eth_chainId'});
 const accounts=await provider.request({method:'eth_accounts'});
 if(chain!=='0xc4'||!Array.isArray(accounts)||typeof accounts[0]!=='string'||accounts[0].toLowerCase()!==account.toLowerCase())throw Error('钱包账号或网络已变化，请重新连接并检查');
}
export function okb(wei:string){const n=BigInt(wei);const whole=n/BigInt(10)**BigInt(18);const decimal=(n%BigInt(10)**BigInt(18)).toString().padStart(18,'0').replace(/0+$/,'');return `${whole}${decimal?'.'+decimal:''}`;}
