export const MUSIC_TRACKS = [
  { id: "musicbox", name: "云朵八音盒", mood: "叮叮咚咚的小心动" },
  { id: "picnic", name: "草莓汽水", mood: "轻快一点，甜一点" },
  { id: "moon", name: "月亮晚安", mood: "慢慢把心事说给你听" },
] as const;
export type MusicTrack = typeof MUSIC_TRACKS[number]['id'] | "none";
