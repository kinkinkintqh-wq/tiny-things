/** Generated visual assets for Tiny Things (soft clay / voxel). */

export const ART = {
  hero: "/art/hero-island.jpg",
  deviceCheckin: "/art/device-checkin.jpg",
  covers: {
    checkin: "/art/cover-checkin.jpg",
    habit: "/art/cover-habit.jpg",
    random: "/art/cover-random.jpg",
    timer: "/art/cover-timer.jpg",
    mood: "/art/cover-mood.jpg",
    letter: "/art/cover-letter.jpg",
  },
  parts: {
    button: "/art/parts/button.jpg",
    switch: "/art/parts/switch.jpg",
    counter: "/art/parts/counter.jpg",
    timer: "/art/parts/timer.jpg",
    randomBox: "/art/parts/random.jpg",
    random: "/art/parts/random.jpg",
    envelope: "/art/parts/envelope.jpg",
    text: "/art/parts/text.jpg",
    progress: "/art/parts/progress.jpg",
    condition: "/art/parts/switch.jpg",
    // Distinct from streak: calendar gate vs habit growth cover.
    dateGate: "/art/parts/timer.jpg",
    streakCounter: "/art/cover-habit.jpg",
    checklist: "/art/cover-habit.jpg",
    proofCard: "/art/cover-checkin.jpg",
  },
} as const;

export function coverFor(category: string, name: string): string {
  if (name.includes("心意") || name.includes("情书")) return ART.covers.letter;
  if (name.includes("打卡")) return ART.covers.checkin;
  if (name.includes("习惯")) return ART.covers.habit;
  if (name.includes("随机") || name.includes("决定")) return ART.covers.random;
  if (name.includes("倒计时") || name.includes("计时")) return ART.covers.timer;
  if (name.includes("情绪")) return ART.covers.mood;
  if (name.includes("信")) return ART.covers.letter;
  if (category === "study") return ART.covers.timer;
  if (category === "play") return ART.covers.random;
  if (category === "mood") return ART.covers.mood;
  return ART.covers.checkin;
}

export function partArt(type: string): string {
  const map = ART.parts as Record<string, string>;
  return map[type] ?? ART.parts.button;
}
