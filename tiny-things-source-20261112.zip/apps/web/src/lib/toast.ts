"use client";

type Listener = (msg: { text: string; tone?: "info" | "error" | "ok" } | null) => void;
let listener: Listener | null = null;
let timer: ReturnType<typeof setTimeout> | null = null;

export function subscribeToast(fn: Listener) {
  listener = fn;
  return () => {
    if (listener === fn) listener = null;
  };
}

export function toast(text: string, tone: "info" | "error" | "ok" = "info") {
  listener?.({ text, tone });
  if (timer) clearTimeout(timer);
  timer = setTimeout(() => listener?.(null), 4000);
}
