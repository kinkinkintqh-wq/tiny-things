import type { LetterTransition } from '@tinythings/runtime';
export interface ChainRun {mode:'local'|'chain'|'mixed'; blockNumber?:string; circuitIds?:string[]}
/** Sends only packed rule inputs/state, never the letter text or recipient name. */
export async function checkLetterTransitions(steps:LetterTransition[]):Promise<ChainRun>{
 const r=await fetch('/api/circuit/letter/step',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({steps}),signal:AbortSignal.timeout(45000)});
 const data=await r.json();
 if(!r.ok)throw Error(data.error??'规则核对失败，已保留上一步状态');
 if(!['local','chain','mixed'].includes(data.mode))throw Error('电路返回无效，已保留上一步状态');
 return data;
}
export function chainRunLabel(run:ChainRun|null){
 if(!run)return '本地电路 · 正式接入待核对';
 if(run.mode==='local')return '本地电路 · 此规则未绑定正式 ID';
 return `${run.mode==='mixed'?'部分规则':'规则'}已核对 X Layer · 区块 ${run.blockNumber} · 电路 ${run.circuitIds?.join(' / ')}`;
}
