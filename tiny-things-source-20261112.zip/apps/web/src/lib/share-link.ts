/** Same-origin public links only; never treat a local preview as a public deployment. */
export function demoLink(origin:string,template:string){
 const base=new URL(origin);
 if(!['http:','https:'].includes(base.protocol))throw new Error('站点地址无效');
 const allowed=['love-letter','daily-checkin','habit-builder'];
 if(!allowed.includes(template))throw new Error('未知试玩模板');
 return new URL(`/demo?thing=${encodeURIComponent(template)}`,base.origin).href;
}
export function localPreview(url:string){
 const h=new URL(url).hostname;
 return h==='localhost'||h==='127.0.0.1'||h==='[::1]'||/^192\.168\./.test(h)||/^10\./.test(h)||/^172\.(1[6-9]|2\d|3[01])\./.test(h);
}
