import { draftFromTemplate } from "@tinythings/block-registry";
import type { DraftPayload } from "@tinythings/schema";
import type { MusicTrack } from "./music";
export interface LoveLetterOptions {
  name: string; recipient: string; sender: string; letterTitle: string; body: string;
  rule: "matches" | "sum"; target: number; match: string; music: MusicTrack;
}
export const DEFAULT_LOVE_LETTER: LoveLetterOptions = {
  name: "给你的一点小心意", recipient: "最可爱的你", sender: "", letterTitle: "有你在，日子就闪闪发光",
  body: "想把今天的小事，都讲给你听。\n\n也想把明天的好天气，和每一个平凡的日子，都留一个位置给你。\n\n如果你看到这里，我想说：\n遇见你，是我最喜欢的小概率事件。♡",
  rule: "sum", target: 12, match: "6", music: "musicbox",
};
export function configureLoveLetter(draft: DraftPayload, value: LoveLetterOptions): DraftPayload {
  if (!value.body.trim()) throw new Error("先写几句想对 TA 说的话吧");
  if (!Number.isInteger(value.target) || value.target < 1 || value.target > (value.rule === "sum" ? 36 : 6)) throw new Error("请设置有效的解锁目标");
  if (!/^[1-6]$/.test(value.match)) throw new Error("骰子点数需要在 1–6 之间");
  const base = draft.graph.nodes.some((n) => n.type === "envelope") && draft.graph.nodes.some((n) => n.type === "randomBox") ? draft : { ...draft, graph: draftFromTemplate("love-letter").graph };
  const env = base.graph.nodes.find((n) => n.type === "envelope")!;
  const dice = base.graph.nodes.find((n) => n.type === "randomBox")!;
  const graph = { ...base.graph, nodes: base.graph.nodes.map((n) => n.id === env.id ? { ...n, config: { ...n.config, unlockMode: "signals", signalRule: value.rule, needSignals: value.target, matchPayload: value.match, recipient: value.recipient.trim().slice(0,24), sender: value.sender.trim().slice(0,24), letterTitle: value.letterTitle.trim().slice(0,60), body: value.body.slice(0,2000) } } : n.id === dice.id ? { ...n, config: { ...n.config, mode: "dice", items: ["1","2","3","4","5","6"], noRepeat: false } } : n), edges: [...base.graph.edges] };
  const unique = (prefix: string) => {
    let id = prefix;
    let i = 1;
    while (graph.nodes.some((n) => n.id === id) || graph.edges.some((e) => e.id === id)) id = `${prefix}_${i++}`;
    return id;
  };
  const ensureButton = (target: string, targetPort: string, action: string, label: string) => {
    if (graph.edges.some((e) => e.target === target && e.targetPort === targetPort && e.kind === "event" && e.sourcePort === "click" && graph.nodes.find((n) => n.id === e.source)?.type === "button")) return;
    const id = unique(`love_${action}`);
    graph.nodes.push({ id, type: "button", version: "1.0.0", config: { label, action, targetNodeId: target }, position: { x: 0, y: action === "draw" ? 0 : 300 } });
    graph.edges.push({ id: unique(`wire_${action}`), source: id, sourcePort: "click", target, targetPort, kind: "event" });
  };
  ensureButton(dice.id, "draw", "draw", "掷骰子");
  ensureButton(env.id, "open", "open", "拆开信封");
  if (!graph.edges.some((e) => e.source === dice.id && e.sourcePort === "picked" && e.target === env.id && e.targetPort === "signal" && e.kind === "event")) graph.edges.push({ id: unique("wire_love_signal"), source: dice.id, sourcePort: "picked", target: env.id, targetPort: "signal", kind: "event" });
  return { ...base, name: value.name.trim().slice(0,40) || "给你的一点小心意", theme: { ...base.theme, music: value.music }, graph };
}
