import { DraftPayloadSchema, type DraftPayload } from "@tinythings/schema";
import { validateGraph } from "@tinythings/block-registry";

const MAX_BYTES = 500_000;
export function parseDesign(value: unknown): DraftPayload {
  const draft = DraftPayloadSchema.parse(value);
  if (draft.graph.nodes.length > 100 || draft.graph.edges.length > 300) throw new Error("作品最多支持 100 个零件、300 条连线");
  const issues = validateGraph(draft.graph);
  if (issues.length) throw new Error(issues.map((i) => i.message).join("；"));
  return draft;
}
export function serializeDesign(draft: DraftPayload): string {
  const text = JSON.stringify(parseDesign(draft));
  if (new TextEncoder().encode(text).length > MAX_BYTES) throw new Error("作品文件超过 500 KB，请减少文本或零件");
  return text;
}
export function encodeDesign(draft: DraftPayload): string {
  const bytes = new TextEncoder().encode(serializeDesign(draft));
  return btoa(Array.from(bytes, (b) => String.fromCharCode(b)).join(""))
    .replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
export function decodeDesign(encoded: string): DraftPayload {
  if (encoded.length > Math.ceil(MAX_BYTES * 4 / 3) + 4) throw new Error("作品链接过大");
  const base = encoded.replace(/-/g, "+").replace(/_/g, "/");
  const text = new TextDecoder("utf-8", { fatal: true }).decode(Uint8Array.from(atob(base), (c) => c.charCodeAt(0)));
  return parseDesign(JSON.parse(text));
}
export function downloadDesign(draft: DraftPayload) {
  const url = URL.createObjectURL(new Blob([serializeDesign(draft)], { type: "application/json" }));
  const a = document.createElement("a");
  a.href = url; a.download = `${draft.name.replace(/[\\/:*?"<>|]/g, "_") || "tiny-thing"}.tinythings.json`;
  a.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
}
