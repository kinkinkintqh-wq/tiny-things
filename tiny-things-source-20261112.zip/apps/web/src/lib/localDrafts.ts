"use client";

import { get, set, del, keys } from "idb-keyval";
import type { DraftPayload } from "@tinythings/schema";

const PREFIX = "tt-draft:";

export interface LocalDraft extends DraftPayload {
  id: string;
  projectId?: string;
  remoteDraftId?: string;
  updatedAt: string;
  storage: "local";
}

export async function listLocalDrafts(): Promise<LocalDraft[]> {
  const all = await keys();
  const ids = all.filter((k) => String(k).startsWith(PREFIX));
  const drafts: LocalDraft[] = [];
  for (const k of ids) {
    const d = await get<LocalDraft>(k);
    if (d) drafts.push(d);
  }
  return drafts.sort((a, b) => b.updatedAt.localeCompare(a.updatedAt)).slice(0, 20);
}

export async function saveLocalDraft(draft: LocalDraft) {
  await set(`${PREFIX}${draft.id}`, {
    ...draft,
    updatedAt: new Date().toISOString(),
    storage: "local",
  });
}

export async function getLocalDraft(id: string) {
  return get<LocalDraft>(`${PREFIX}${id}`);
}

export async function deleteLocalDraft(id: string) {
  await del(`${PREFIX}${id}`);
}
