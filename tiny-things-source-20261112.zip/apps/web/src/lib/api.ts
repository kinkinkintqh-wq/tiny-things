const API_URL = process.env.NEXT_PUBLIC_API_URL || "";

export class ApiClientError extends Error {
  status: number;
  code: string;
  body: unknown;
  constructor(status: number, code: string, message: string, body: unknown) {
    super(message);
    this.status = status;
    this.code = code;
    this.body = body;
  }
}

export async function api<T>(
  path: string,
  init: RequestInit = {},
  retries = 2
): Promise<T> {
  const url = `${API_URL}/api/v1${path}`;
  let lastErr: unknown;
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      const res = await fetch(url, {
        ...init,
        credentials: "include",
        headers: {
          "content-type": "application/json",
          ...(init.headers ?? {}),
        },
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        throw new ApiClientError(
          res.status,
          (data as { code?: string }).code ?? "error",
          (data as { message?: string }).message ?? res.statusText,
          data
        );
      }
      return data as T;
    } catch (err) {
      lastErr = err;
      // Retry only network failures / 5xx, not 4xx business errors
      const retryable =
        !(err instanceof ApiClientError) ||
        err.status >= 500 ||
        err.status === 429;
      if (!retryable || (err instanceof ApiClientError && (err.body as { retryable?: boolean })?.retryable === false) || attempt === retries) break;
      await new Promise((r) => setTimeout(r, 300 * 2 ** attempt));
    }
  }
  if (lastErr instanceof Error) {
    if (
      lastErr instanceof TypeError ||
      lastErr.message.toLowerCase().includes("fetch")
    ) {
      throw new ApiClientError(0, "network", "网络不可用，请确认 API 已启动后重试", {});
    }
    throw lastErr;
  }
  throw new ApiClientError(0, "network", "请求失败", {});
}

export { API_URL };
