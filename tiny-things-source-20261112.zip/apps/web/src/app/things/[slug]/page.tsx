"use client";

import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import { useEffect, useMemo, useState } from "react";
import { RuntimeSession } from "@tinythings/runtime";
import type { DesignGraph } from "@tinythings/schema";
import { ThingPlayView, detectPlayMood } from "@/components/ThingPlayView";
import { api } from "@/lib/api";
import { toast } from "@/lib/toast";

type Release = {
  id: string;
  slug: string;
  name: string;
  description: string;
  author: { displayName: string };
  manifestHash: string;
  status: string;
  stats: { views: number; likes: number; uses: number };
  manifest?: { graph: DesignGraph };
  parentReleaseId?: string | null;
};

export default function ThingDetailPage() {
  const { slug } = useParams<{ slug: string }>();
  const router = useRouter();
  const [data, setData] = useState<Release | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [remixing, setRemixing] = useState(false);
  const [demoStates, setDemoStates] = useState<
    Record<string, Record<string, unknown>>
  >({});

  useEffect(() => {
    api<Release>(`/releases/${slug}`)
      .then((rel) => {
        setData(rel);
        if (rel.manifest?.graph) {
          try {
            const rt = new RuntimeSession(rel.manifest.graph, {
              timezone: "Asia/Shanghai",
              seed: 7,
            });
            setDemoStates(rt.getSnapshot().states);
          } catch {
            setDemoStates({});
          }
        }
      })
      .catch((err) => setError(err instanceof Error ? err.message : "加载失败"));
  }, [slug]);

  const mood = useMemo(() => {
    if (!data?.manifest?.graph) return "mixed";
    return detectPlayMood(
      data.manifest.graph.nodes.map((n) => ({
        id: n.id,
        type: n.type,
        config: n.config ?? {},
      }))
    );
  }, [data]);

  const remix = async () => {
    if (!data) return;
    setRemixing(true);
    try {
      const res = await api<{ draftId: string }>(`/releases/${data.id}/remix`, {
        method: "POST",
        headers: { "Idempotency-Key": `remix_${data.id}_${Date.now()}` },
        body: JSON.stringify({ name: `改造·${data.name}` }),
      });
      toast("已复制为新草稿，可继续改零件与连线", "ok");
      router.push(`/make/${res.draftId}`);
    } catch (err) {
      toast(err instanceof Error ? err.message : "复制失败", "error");
    } finally {
      setRemixing(false);
    }
  };

  const share = async () => {
    if (!data) return;
    const url = `${window.location.origin}/run/${data.id}`;
    try {
      await navigator.clipboard.writeText(url);
      toast("已复制固定版本链接", "ok");
    } catch {
      toast(url, "info");
    }
  };

  if (error) {
    return (
      <div className="mx-auto max-w-lg p-10 text-center">
        <p>{error}</p>
        <Link href="/discover" className="tt-btn mt-4 inline-flex">
          返回发现
        </Link>
      </div>
    );
  }

  if (!data) {
    return <div className="p-10 text-center text-tt-muted">加载作品…</div>;
  }

  return (
    <div className="mx-auto grid max-w-[1280px] gap-8 px-4 py-8 md:grid-cols-[58%_42%] md:gap-10 md:px-8 md:py-12">
      <div className="relative overflow-hidden rounded-[28px] border border-tt-border/70 bg-gradient-to-b from-[#d7e7ff] via-[#e9ddff] to-[#f6f0ff] px-6 py-10 shadow-panel md:px-10">
        <div className="pointer-events-none absolute inset-0 opacity-40">
          <div className="absolute left-[8%] top-[12%] h-16 w-28 rounded-full bg-white/70" />
          <div className="absolute right-[12%] top-[18%] h-10 w-20 rounded-full bg-white/50" />
        </div>
        <div className="relative">
          {data.manifest?.graph ? (
            <ThingPlayView
              name={data.name}
              graphOrNodes={data.manifest.graph}
              states={demoStates}
              onInteract={() =>
                toast("点「使用这个小东西」进入完整可玩页", "info")
              }
              compact
            />
          ) : (
            <p className="text-center text-tt-muted">预览加载中…</p>
          )}
        </div>
        <p className="relative mt-6 text-center text-sm text-tt-muted">
          {mood === "checkin"
            ? "打卡小设备预览 · 正式记录在使用页"
            : "组合玩法预览 · 正式互动在使用页"}
        </p>
      </div>

      <div className="flex flex-col justify-center">
        <h1 className="text-3xl font-medium text-tt-ink md:text-4xl">{data.name}</h1>
        <p className="mt-2 text-tt-muted">作者 {data.author.displayName}</p>
        <p className="mt-4 text-base leading-7 text-tt-ink/90">
          {data.description || "一个可以真正运行的小东西。"}
        </p>
        <div className="mt-4 flex flex-wrap gap-2 text-xs">
          <span className="rounded-full bg-white/80 px-3 py-1 text-tt-ink">本机已部署</span>
          <span className="rounded-full bg-white/80 px-3 py-1 text-tt-muted">
            可复制改造
          </span>
          <span className="rounded-full bg-white/80 px-3 py-1 text-tt-muted">
            {data.stats.uses} 次使用
          </span>
        </div>
        <div className="mt-8 flex flex-col gap-3">
          <Link href={`/run/${data.id}`} className="tt-btn h-14 text-center text-base">
            使用这个小东西
          </Link>
          <button className="tt-btn-secondary h-12" disabled={remixing} onClick={remix}>
            {remixing ? "复制中…" : "复制并改造"}
          </button>
          <button className="tt-btn-secondary h-12" onClick={share}>
            分享固定版本链接
          </button>
        </div>
      </div>
    </div>
  );
}
