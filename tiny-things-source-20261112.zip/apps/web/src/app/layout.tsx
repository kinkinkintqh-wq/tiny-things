import type { Metadata } from "next";
import localFont from "next/font/local";
import { SiteNav } from "@/components/SiteNav";
import { ToastHost } from "@/components/ToastHost";
import "./globals.css";

const pixel = localFont({ src: "../../public/fonts/PressStart2P-Regular.ttf", variable: "--font-pixel", display: "swap" });

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || (process.env.VERCEL_PROJECT_PRODUCTION_URL ? `https://${process.env.VERCEL_PROJECT_PRODUCTION_URL}` : "http://localhost:3846")),
  title: "Tiny Things 小东西制造所",
  description: "把功能拼成真正可用的小工具：拖拽制造、即时运行、分享改造。",
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="zh-CN">
      <body className={`${pixel.variable} font-sans antialiased`}>
        <SiteNav />
        <main className="min-h-[calc(100vh-72px)]">{children}</main>
        <ToastHost />
      </body>
    </html>
  );
}
