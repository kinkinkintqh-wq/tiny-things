"use client";

import Image from "next/image";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useEffect, useState } from "react";
import { CategoryIcon } from "@/components/VoxelIcons";
import { api } from "@/lib/api";
import { TEMPLATES } from "@tinythings/block-registry";
import { coverFor } from "@/lib/art";

const categories = [
  { id: "all", label: "全部" },
  { id: "life", label: "生活小工具" },
  { id: "study", label: "学习效率" },
  { id: "mood", label: "情绪陪伴" },
  { id: "play", label: "创意玩法" },
];

type Item = {
  id: string;
  localTemplate?: boolean;
  slug: string;
  name: string;
  description: string;
  category: string;
  author: string;
  stats: { views: number; likes: number; uses: number };
};

function DiscoverInner() {
  const sp = useSearchParams();
  const router = useRouter();
  const category = sp.get("category") ?? "all";
  const query = sp.get("query") ?? "";
  const sort = sp.get("sort") ?? "newest";
  const [q, setQ] = useState(query);
  const [items, setItems] = useState<Item[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const t = setTimeout(() => {
      const params = new URLSearchParams({ category, sort });
      if (q) params.set("query", q);
      router.replace(`/discover?${params.toString()}`);
    }, 300);
    return () => clearTimeout(t);
  }, [q, category, sort, router]);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    api<{ items: Item[] }>(
      `/discover?category=${category}&sort=${sort}&query=${encodeURIComponent(query)}`
    )
      .then((res) => {
        if (cancelled) return;
        setItems(res.items);
        setError(null);
      })
      .catch((err) => {
        if (cancelled) return;
        setError(err instanceof Error ? err.message : "加载失败");
        setItems(TEMPLATES.filter((t) => (category === "all" || t.category === category) && `${t.name}${t.description}`.includes(query)).map((t) => ({ id: t.id, slug: t.id, name: t.name, description: t.description, category: t.category, author: "内置模板", stats: { views: 0, likes: 0, uses: 0 }, localTemplate: true })));
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [category, sort, query]);

  const empty = !loading && items.length === 0;

  return (
    <div className="mx-auto max-w-[1280px] px-4 py-6 md:px-8 md:py-8">
      <div className="flex h-16 items-center justify-between gap-4">
        <div className="flex gap-2 overflow-x-auto pb-1">
          {categories.map((c) => (
            <Link
              key={c.id}
              href={`/discover?category=${c.id}&sort=${sort}${q ? `&query=${encodeURIComponent(q)}` : ""}`}
              className={`flex h-11 shrink-0 items-center gap-2 rounded-btn px-4 text-sm transition ${
                category === c.id
                  ? "bg-tt-primary text-white shadow-soft"
                  : "bg-white/75 text-tt-ink hover:bg-white"
              }`}
            >
              <CategoryIcon id={c.id} size={22} />
              {c.label}
            </Link>
          ))}
        </div>
        <div className="hidden gap-2 sm:flex">
          <input
            className="tt-input max-w-[200px]"
            placeholder="搜索小东西"
            value={q}
            onChange={(e) => setQ(e.target.value)}
          />
          <select
            className="tt-input max-w-[130px]"
            value={sort}
            onChange={(e) =>
              router.replace(
                `/discover?category=${category}&sort=${e.target.value}${q ? `&query=${encodeURIComponent(q)}` : ""}`
              )
            }
          >
            <option value="newest">最新发布</option>
            <option value="hot">最近热度</option>
          </select>
        </div>
      </div>

      <div className="mt-3 flex gap-2 sm:hidden">
        <input
          className="tt-input flex-1"
          placeholder="搜索小东西"
          value={q}
          onChange={(e) => setQ(e.target.value)}
        />
        <select
          className="tt-input w-[118px] shrink-0"
          value={sort}
          onChange={(e) =>
            router.replace(
              `/discover?category=${category}&sort=${e.target.value}${q ? `&query=${encodeURIComponent(q)}` : ""}`
            )
          }
        >
          <option value="newest">最新</option>
          <option value="hot">热度</option>
        </select>
      </div>

      {error && (
        <div className="tt-panel mt-6 p-4 text-sm">
          社区服务暂不可用，先玩玩内置模板。你的本机作品不受影响。
          <button className="tt-btn-secondary ml-3 h-9" onClick={() => location.reload()}>
            重试
          </button>
        </div>
      )}

      {loading && (
        <div className="mt-6 grid grid-cols-2 gap-4 md:grid-cols-3 xl:grid-cols-4 md:gap-5">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="h-[300px] animate-pulse rounded-card bg-white/55" />
          ))}
        </div>
      )}

      {empty && (
        <div className="tt-panel mt-10 p-8 text-center">
          <p className="text-tt-ink">没有结果</p>
          <div className="mt-4 flex justify-center gap-3">
            <Link href="/discover" className="tt-btn-secondary">
              清除筛选
            </Link>
            <Link href="/make" className="tt-btn">
              从模板开始
            </Link>
          </div>
        </div>
      )}

      <div className="mt-6 grid grid-cols-2 gap-4 md:grid-cols-3 xl:grid-cols-4 md:gap-5">
        {items.map((item) => (
          <article
            key={item.id}
            className="group overflow-hidden rounded-card border border-white/80 bg-white/92 shadow-soft transition hover:-translate-y-1 hover:shadow-panel"
          >
            <Link href={item.localTemplate ? `/play?template=${item.id}` : `/things/${item.id}`} className="block">
              <div className="relative h-[176px] overflow-hidden bg-gradient-to-b from-[#efe7ff] to-[#f8f4ff]">
                <Image
                  src={coverFor(item.category, item.name)}
                  alt=""
                  fill
                  sizes="294px"
                  className="object-cover transition duration-300 group-hover:scale-105"
                  unoptimized
                />
              </div>
              <div className="p-4">
                <h3 className="line-clamp-2 text-base font-medium text-tt-ink">
                  {item.name}
                </h3>
                <p className="mt-1 line-clamp-2 text-sm text-tt-muted">
                  {item.description || "一个可爱的小工具"}
                </p>
                <div className="mt-3 flex items-center justify-between text-xs text-tt-muted">
                  <span>{item.author}</span>
                  {!item.localTemplate && <span>
                    使用 {item.stats.uses}
                    {item.stats.likes > 0 ? ` · 喜欢 ${item.stats.likes}` : ""}
                  </span>}
                </div>
              </div>
            </Link>
            <div className="flex gap-2 border-t border-tt-border/50 p-3">
              <Link href={item.localTemplate ? `/play?template=${item.id}` : `/run/${item.id}`} className="tt-btn h-10 flex-[1.4] text-sm">
                使用
              </Link>
              <Link
                href={item.localTemplate ? `/play?template=${item.id}` : `/things/${item.id}`}
                className="tt-btn-secondary h-10 flex-1 text-sm"
              >
                详情
              </Link>
            </div>
          </article>
        ))}

        <Link
          href="/make"
          className="flex h-[300px] flex-col items-center justify-center rounded-card border border-dashed border-tt-primary/40 bg-white/55 text-tt-primary transition hover:bg-white"
        >
          <span className="flex h-14 w-14 items-center justify-center rounded-full bg-tt-primary/10 text-2xl">
            ＋
          </span>
          <span className="mt-3 text-sm">创造一个新东西</span>
        </Link>
      </div>
    </div>
  );
}

export default function DiscoverPage() {
  return (
    <Suspense fallback={<div className="p-10 text-tt-muted">加载发现页…</div>}>
      <DiscoverInner />
    </Suspense>
  );
}
