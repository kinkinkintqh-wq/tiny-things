"use client";

import { useRouter } from "next/navigation";
import { useEffect } from "react";
import { nanoid } from "nanoid";
import { draftFromTemplate, TEMPLATES } from "@tinythings/block-registry";
import { createDraft } from "@tinythings/schema";
import { saveLocalDraft } from "@/lib/localDrafts";
import { useRef } from "react";

export default function MakeIndexPage() {
  const router = useRouter();
  const started = useRef(false);
  useEffect(() => {
    if (started.current) return;
    started.current = true;
    (async () => {
      const localId = `local_${nanoid(8)}`;
      const templateId = new URLSearchParams(window.location.search).get("template");
      const seeded = templateId && TEMPLATES.some((t) => t.id === templateId) ? draftFromTemplate(templateId) : { ...createDraft(), name: "未命名小东西" };
      await saveLocalDraft({
        ...seeded,
        id: localId,
        name: seeded.name,
        updatedAt: new Date().toISOString(),
        storage: "local",
      });
      router.replace(`/make/${localId}${templateId === "love-letter" ? "?write=1" : ""}`);
    })();
  }, [router]);
  return (
    <div className="flex min-h-[50vh] items-center justify-center text-tt-muted">
      正在打开制造工作台…
    </div>
  );
}
