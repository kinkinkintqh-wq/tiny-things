"use client";

import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import { useCallback, useEffect, useRef, useState } from "react";
import { createDraft, type DraftPayload } from "@tinythings/schema";
import { MakerCanvas } from "@/components/maker/MakerCanvas";
import { api, ApiClientError } from "@/lib/api";
import { getLocalDraft, saveLocalDraft } from "@/lib/localDrafts";
import { toast } from "@/lib/toast";
import { encodeDesign, downloadDesign } from "@/lib/portable";

type PublishResult = {
  releaseId: string;
  url: string;
  shareUrl: string;
};

export default function MakeDraftPage() {
  const params = useParams<{ draftId: string }>();
  const draftId = params.draftId;
  const router = useRouter();
  const [draft, setDraft] = useState<(DraftPayload & { id: string }) | null>(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [publishOpen, setPublishOpen] = useState(false);
  const [publishing, setPublishing] = useState(false);
  const [published, setPublished] = useState<PublishResult | null>(null);
  const latest = useRef<(DraftPayload & { id: string }) | null>(null);
  const saveQueue = useRef<Promise<void>>(Promise.resolve());
  const revisionRef = useRef(0);
  const editVersion = useRef(0);
  const [saveStatus, setSaveStatus] = useState("已保存到本机");
  latest.current = draft;
  const remote = !draftId.startsWith("local_");

  useEffect(() => {
    (async () => {
      try {
        if (remote) {
          const data = await api<{
            id: string;
            name: string;
            revision: number;
            graph: DraftPayload["graph"];
            layout: DraftPayload["layout"];
            theme: DraftPayload["theme"];
            schemaVersion: DraftPayload["schemaVersion"];
          }>(`/drafts/${draftId}`);
          revisionRef.current = data.revision;
          setDraft({
            id: data.id,
            name: data.name,
            revision: data.revision,
            graph: data.graph,
            layout: data.layout,
            theme: data.theme,
            schemaVersion: data.schemaVersion,
          });
        } else {
          const local = await getLocalDraft(draftId);
          if (local) setDraft(local);
          else {
            const d = createDraft();
            const saved = {
              ...d,
              id: draftId,
              updatedAt: new Date().toISOString(),
              storage: "local" as const,
            };
            await saveLocalDraft(saved);
            setDraft(saved);
          }
        }
      } catch (err) {
        const cached = await getLocalDraft(draftId).catch(() => undefined);
        if (cached) { revisionRef.current = cached.revision; setDraft(cached); setSaveStatus("已打开本机备份 · 服务端未连接"); }
        else setError(err instanceof Error ? err.message : "加载失败");
      }
    })();
  }, [draftId, remote]);

  const persist = useCallback((next: DraftPayload & { id: string }) => {
    const version = ++editVersion.current;
    setSaving(true);
    setSaveStatus("正在保存…");
    let localSaved = false;
    const job = saveQueue.current.then(async () => {
      await saveLocalDraft({ ...next, updatedAt: new Date().toISOString(), storage: "local" });
      localSaved = true;
      if (remote) {
        const result = await api<{ revision: number }>(`/drafts/${draftId}`, {
          method: "PUT", body: JSON.stringify({ baseRevision: revisionRef.current, name: next.name, graph: next.graph, layout: next.layout, theme: next.theme }),
        }, 0);
        revisionRef.current = result.revision;
        setDraft((current) => current ? { ...current, revision: result.revision } : current);
      }
      if (version === editVersion.current) setSaveStatus(remote ? "已保存并同步" : "已保存到本机");
    });
    saveQueue.current = job.catch((err) => {
      if (version === editVersion.current) setSaveStatus(localSaved ? "本机已保存 · 同步失败" : "保存失败 · 请导出备份");
      toast(err instanceof ApiClientError && err.status === 409 ? "服务端已有其他修改，本机副本已保留，请先导出备份" : err instanceof Error ? err.message : "保存失败", "error");
    }).finally(() => { if (version === editVersion.current) setSaving(false); });
    return job;
  }, [draftId, remote]);

  const onChange = (next: DraftPayload) => {
    const current = latest.current;
    if (!current) return;
    const merged = { ...current, ...next };
    latest.current = merged;
    setDraft(merged);
    void persist(merged).catch(() => {});
  };

  const onPublish = async () => {
    if (!draft) return;
    if (draft.graph.nodes.length === 0) {
      toast("画布还是空的，先放模板或零件再部署", "info");
      return;
    }
    setPublished(null);
    setPublishOpen(true);
  };

  /** Ensure we have a server draft id before creating a release (local-first). */
  async function ensureRemoteDraft(
    current: DraftPayload & { id: string; remoteDraftId?: string; projectId?: string }
  ): Promise<{ draftId: string; revision: number }> {
    const existingRemote =
      !current.id.startsWith("local_")
        ? current.id
        : current.remoteDraftId && current.remoteDraftId.startsWith("d_")
          ? current.remoteDraftId
          : null;

    if (existingRemote) {
      const baseRevision = remote ? revisionRef.current : current.revision;
      const saved = await api<{ revision: number }>(`/drafts/${existingRemote}`, {
        method: "PUT",
        body: JSON.stringify({
          baseRevision,
          name: current.name,
          graph: current.graph,
          layout: current.layout,
          theme: current.theme,
        }),
      });
      return { draftId: existingRemote, revision: saved.revision };
    }

    const created = await api<{ draftId: string; projectId: string }>("/projects", {
      method: "POST",
      body: JSON.stringify({ name: current.name || "未命名小东西" }),
    });
    const put = await api<{ revision: number }>(`/drafts/${created.draftId}`, {
      method: "PUT",
      body: JSON.stringify({
        baseRevision: 0,
        name: current.name,
        graph: current.graph,
        layout: current.layout,
        theme: current.theme,
      }),
    });
    await saveLocalDraft({
      ...current,
      id: current.id,
      remoteDraftId: created.draftId,
      projectId: created.projectId,
      updatedAt: new Date().toISOString(),
      storage: "local",
    });
    return { draftId: created.draftId, revision: put.revision };
  }

  const confirmPublish = async (visibility: "public" | "unlisted" | "private") => {
    if (!draft) return;
    setPublishing(true);
    try {
      await saveQueue.current;
      const { draftId: remoteId, revision } = await ensureRemoteDraft(draft);
      const res = await api<{ releaseId: string; url: string; hash: string }>(
        "/releases",
        {
          method: "POST",
          headers: { "Idempotency-Key": `pub_${remoteId}_${revision}` },
          body: JSON.stringify({
            draftId: remoteId,
            revision,
            visibility,
            description: `${draft.name} · 由 Tiny Things 制造`,
            category: "life",
          }),
        }
      );
      const shareUrl = `${window.location.origin}/run/${res.releaseId}`;
      setPublished({
        releaseId: res.releaseId,
        url: res.url,
        shareUrl,
      });
      setDraft({ ...draft, revision, id: remoteId.startsWith("d_") ? remoteId : draft.id });
      toast("部署成功，可以分享试玩链接了", "ok");
      if (draft.id.startsWith("local_") && remoteId.startsWith("d_")) {
        router.replace(`/make/${remoteId}`);
      }
    } catch (err) {
      toast(err instanceof Error ? err.message : "部署失败", "error");
    } finally {
      setPublishing(false);
    }
  };

  const copyShare = async () => {
    if (!published) return;
    try {
      await navigator.clipboard.writeText(published.shareUrl);
      toast("已复制试玩链接", "ok");
    } catch {
      toast(published.shareUrl, "info");
    }
  };

  if (error) {
    return (
      <div className="mx-auto max-w-lg p-10 text-center">
        <p className="text-tt-ink">{error}</p>
        <button className="tt-btn mt-4" onClick={() => router.push("/")}>
          返回首页
        </button>
      </div>
    );
  }

  if (!draft) {
    return (
      <div className="flex min-h-[50vh] items-center justify-center text-tt-muted">
        加载草稿…
      </div>
    );
  }

  return (
    <>
      <MakerCanvas
        draft={draft}
        onChange={onChange}
        onSave={() => { void persist(draft).catch(() => {}); }}
        onPublish={onPublish}
        saving={saving}
        saveStatus={saveStatus}
      />
      {publishOpen && (
        <div className="fixed inset-0 z-[60] flex items-end justify-center bg-[#302740]/40 p-0 md:items-center md:p-4">
          <div className="tt-panel max-h-[90vh] w-full max-w-[520px] overflow-auto rounded-t-panel p-6 md:rounded-panel">
            {!published ? (
              <>
                <h3 className="text-lg font-medium">保存一个可分享的版本</h3>
                <p className="mt-2 text-sm leading-6 text-tt-muted">
                  作品快照链接包含当前设计，无需数据库。对方需要能访问这个网站；运行进度各自保存在浏览器。
                </p>
                <div className="mt-4 rounded-[14px] bg-tt-bg/90 p-3 text-xs leading-5 text-tt-muted">
                  <div className="font-medium text-tt-ink">{draft.name || "未命名小东西"}</div>
                  <p className="mt-1">
                    {draft.graph.nodes.length} 个零件 · {draft.graph.edges.length} 条连线
                  </p>
                  <p className="mt-1">链接包含作品文字。游戏解锁是惊喜玩法，并非加密保密；拿到链接的人可以提取信件内容。</p>
                </div>
                <div className="mt-5 flex flex-col gap-2">
                  <button className="tt-btn" onClick={() => {
                    try {
                      const encoded = encodeDesign(draft);
                      if (encoded.length > 24000) { toast("作品较大，请用导出作品文件分享", "info"); return; }
                      const shareUrl = `${window.location.origin}/play#${encoded}`;
                      setPublished({ releaseId: "snapshot", url: shareUrl, shareUrl });
                    } catch (err) { toast(err instanceof Error ? err.message : "无法分享", "error"); }
                  }}>生成作品快照链接</button>
                  <button className="tt-btn-secondary" onClick={() => { try { downloadDesign(draft); } catch (err) { toast(err instanceof Error ? err.message : "导出失败", "error"); } }}>导出作品文件</button>
                  <p className="my-2 text-xs leading-5 text-tt-muted">以下发布选项需要已配置的数据库服务。地址以 localhost / 127.0.0.1 开头时，仅当前电脑可访问。</p>

                  <button
                    className="tt-btn"
                    disabled={publishing}
                    onClick={() => void confirmPublish("public")}
                  >
                    {publishing ? "部署中…" : "公开部署（发现页可见）"}
                  </button>
                  <button
                    className="tt-btn-secondary"
                    disabled={publishing}
                    onClick={() => void confirmPublish("unlisted")}
                  >
                    {publishing ? "部署中…" : "仅链接可访问"}
                  </button>
                  <button
                    className="tt-btn-secondary"
                    disabled={publishing}
                    onClick={() => setPublishOpen(false)}
                  >
                    取消
                  </button>
                </div>
              </>
            ) : (
              <>
                <div className="text-[11px] tracking-[0.16em] text-tt-muted">{published.releaseId === "snapshot" ? "作品快照已生成" : "发布成功"}</div>
                <h3 className="mt-1 text-lg font-medium">可以分享给别人玩了</h3>
                <p className="mt-2 text-sm leading-6 text-tt-muted">
                  复制下面的试玩链接，或直接打开。固定版本不会随你继续改草稿而变化。
                </p>
                <div className="mt-4 max-h-32 overflow-auto break-all rounded-[14px] border border-tt-border/70 bg-white/90 px-3 py-3 text-sm text-tt-ink">
                  {published.shareUrl}
                </div>
                <div className="mt-5 flex flex-col gap-2">
                  <button className="tt-btn" onClick={() => void copyShare()}>
                    复制试玩链接
                  </button>
                  <Link href={published.shareUrl} className="tt-btn-secondary text-center">
                    打开试玩页
                  </Link>
                  {published.releaseId !== "snapshot" && <Link
                    href={`/things/${published.releaseId}`}
                    className="tt-btn-secondary text-center"
                  >
                    查看作品详情
                  </Link>}
                  <button
                    className="tt-btn-secondary"
                    onClick={() => {
                      setPublishOpen(false);
                      setPublished(null);
                    }}
                  >
                    回到制造
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </>
  );
}
