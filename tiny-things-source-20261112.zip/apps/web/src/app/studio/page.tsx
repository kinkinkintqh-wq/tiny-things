"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import { listLocalDrafts, type LocalDraft } from "@/lib/localDrafts";
import { toast } from "@/lib/toast";

function formatWhen(iso?: string) {
  if (!iso) return "";
  try {
    return new Intl.DateTimeFormat("zh-CN", {
      timeZone: "Asia/Shanghai",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    }).format(new Date(iso));
  } catch {
    return iso;
  }
}

export default function StudioPage() {
  const [tab, setTab] = useState<"local" | "drafts" | "published">("local");
  const [local, setLocal] = useState<LocalDraft[]>([]);
  const [studio, setStudio] = useState<{
    drafts: Array<{
      projectId: string;
      draftId?: string;
      name: string;
      revision: number;
      updatedAt?: string;
    }>;
    published: Array<{
      releaseId: string;
      slug: string;
      name: string;
      version: number;
      status: string;
    }>;
  } | null>(null);
  const [me, setMe] = useState<{ displayName: string } | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      setLoading(true);
      const locals = await listLocalDrafts().catch(() => []);
      if (!cancelled) {
        setLocal(locals);
        setLoading(false);
      }
      api<{ displayName: string }>("/me")
        .then((m) => !cancelled && setMe(m))
        .catch(() => null);
      api<{
        drafts: Array<{
          projectId: string;
          draftId?: string;
          name: string;
          revision: number;
          updatedAt?: string;
        }>;
        published: Array<{
          releaseId: string;
          slug: string;
          name: string;
          version: number;
          status: string;
        }>;
      }>("/studio")
        .then((s) => !cancelled && setStudio(s))
        .catch(() => !cancelled && setStudio({ drafts: [], published: [] }))
        .finally(() => !cancelled && setLoading(false));
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const copyRun = async (releaseId: string) => {
    const url = `${window.location.origin}/run/${releaseId}`;
    try {
      await navigator.clipboard.writeText(url);
      toast("已复制试玩链接", "ok");
    } catch {
      toast(url, "info");
    }
  };

  return (
    <div className="mx-auto max-w-5xl px-4 py-8 md:px-8">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-medium text-tt-ink">我的制造所</h1>
          <p className="mt-2 text-sm text-tt-muted">
            {me ? `你好，${me.displayName}` : "本地访客"}
            。草稿自动保存；部署后可复制试玩链接。
          </p>
        </div>
        <Link href="/make" className="tt-btn h-11">
          新建小东西
        </Link>
      </div>

      <div className="mt-6 flex flex-wrap gap-2">
        {(
          [
            ["local", "本机草稿", local.length],
            ["drafts", "已同步草稿", studio?.drafts.length ?? 0],
            ["published", "已部署", studio?.published.length ?? 0],
          ] as const
        ).map(([id, label, count]) => (
          <button
            key={id}
            className={`rounded-btn px-4 py-2 text-sm transition ${
              tab === id ? "bg-tt-primary text-white shadow-soft" : "bg-white/70 text-tt-ink"
            }`}
            onClick={() => setTab(id)}
          >
            {label}
            <span className="ml-1.5 tabular-nums opacity-70">{count}</span>
          </button>
        ))}
      </div>

      {loading && (
        <div className="mt-6 space-y-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="h-20 animate-pulse rounded-card bg-white/55" />
          ))}
        </div>
      )}

      {!loading && (
        <div className="mt-6 grid gap-3">
          {tab === "local" &&
            local.map((d) => (
              <Link
                key={d.id}
                href={`/make/${d.id}`}
                className="tt-panel flex items-center justify-between gap-3 p-4 transition hover:-translate-y-0.5 hover:shadow-panel"
              >
                <div className="min-w-0">
                  <div className="truncate font-medium text-tt-ink">{d.name}</div>
                  <div className="mt-1 text-xs text-tt-muted">
                    本机 · {formatWhen(d.updatedAt)} · {d.graph.nodes.length} 零件
                  </div>
                </div>
                <span className="shrink-0 text-sm font-medium text-tt-primary">继续编辑</span>
              </Link>
            ))}

          {tab === "drafts" &&
            (studio?.drafts ?? []).map((d) => (
              <Link
                key={d.projectId}
                href={d.draftId ? `/make/${d.draftId}` : "/make"}
                className="tt-panel flex items-center justify-between gap-3 p-4 transition hover:-translate-y-0.5 hover:shadow-panel"
              >
                <div className="min-w-0">
                  <div className="truncate font-medium text-tt-ink">{d.name}</div>
                  <div className="mt-1 text-xs text-tt-muted">
                    revision {d.revision}
                    {d.updatedAt ? ` · ${formatWhen(d.updatedAt)}` : ""}
                  </div>
                </div>
                <span className="shrink-0 text-sm font-medium text-tt-primary">打开</span>
              </Link>
            ))}

          {tab === "published" &&
            (studio?.published ?? []).map((p) => (
              <div
                key={p.releaseId}
                className="tt-panel flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between"
              >
                <div className="min-w-0">
                  <div className="truncate font-medium text-tt-ink">{p.name}</div>
                  <div className="mt-1 text-xs text-tt-muted">
                    v{p.version} · {p.status === "webPublished" ? "网页已部署" : p.status}
                  </div>
                </div>
                <div className="flex flex-wrap gap-2">
                  <Link href={`/run/${p.releaseId}`} className="tt-btn h-9 px-3 text-sm">
                    试玩
                  </Link>
                  <button
                    type="button"
                    className="tt-btn-secondary h-9 px-3 text-sm"
                    onClick={() => void copyRun(p.releaseId)}
                  >
                    复制链接
                  </button>
                  <Link
                    href={`/things/${p.releaseId}`}
                    className="tt-btn-secondary h-9 px-3 text-sm"
                  >
                    详情
                  </Link>
                </div>
              </div>
            ))}

          {((tab === "local" && local.length === 0) ||
            (tab === "drafts" && (studio?.drafts.length ?? 0) === 0) ||
            (tab === "published" && (studio?.published.length ?? 0) === 0)) && (
            <div className="tt-panel p-10 text-center">
              <p className="text-tt-ink">这里还空着</p>
              <p className="mt-2 text-sm text-tt-muted">
                {tab === "published"
                  ? "在制造台点「部署」，这里就会出现可分享的版本。"
                  : "从模板或空白画布开始做一个小东西吧。"}
              </p>
              <div className="mt-5 flex justify-center gap-2">
                <Link href="/make" className="tt-btn">
                  开始创造
                </Link>
                <Link href="/discover" className="tt-btn-secondary">
                  逛逛发现
                </Link>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
