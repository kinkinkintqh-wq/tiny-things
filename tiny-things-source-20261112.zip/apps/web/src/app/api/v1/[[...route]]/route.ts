async function handle(req: Request) {
  if (!process.env.DATABASE_URL) return Response.json({ code: "local_mode", message: "当前为本机模式，社区发布需要配置数据库", retryable: false }, { status: 503 });
  try {
    const { app } = await import("@/server/app");
    return await app.fetch(req);
  } catch {
    return Response.json({ code: "service_unavailable", message: "社区服务暂不可用，本机制作不受影响", retryable: true }, { status: 503 });
  }
}
export const GET = handle;
export const POST = handle;
export const PUT = handle;
export const PATCH = handle;
export const DELETE = handle;
export const OPTIONS = handle;
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
