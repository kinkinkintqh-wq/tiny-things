import { NextRequest, NextResponse } from "next/server";
import { readCircuit } from "@/lib/circuit-reader";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export async function GET(req: NextRequest) {
  const { searchParams } = req.nextUrl;
  try { return NextResponse.json(await readCircuit(searchParams.get("processor") ?? "", searchParams.get("id") ?? "1"), { headers: { "Cache-Control": "no-store" } }); }
  catch (err) { return NextResponse.json({ error: err instanceof Error ? err.message : "电路读取失败", verified: false }, { status: 502 }); }
}
