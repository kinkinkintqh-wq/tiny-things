import {NextRequest,NextResponse} from 'next/server';
import {runLetterSteps} from '../../../../../../../../packages/tapeout-adapter/src/letter-step';
export const runtime='nodejs';export const dynamic='force-dynamic';
export async function POST(req:NextRequest){
 try{const raw=await req.text();if(raw.length>8000)throw Error('请求过大');
 const result=await runLetterSteps(JSON.parse(raw).steps);return NextResponse.json(result,{headers:{'Cache-Control':'no-store'}});
 }catch(e){return NextResponse.json({error:e instanceof Error?e.message:'电路核对失败，未推进状态'},{status:400,headers:{'Cache-Control':'no-store'}});}
}
