import {NextRequest,NextResponse} from 'next/server';
import {readLetterProof} from '../../../../../../../packages/tapeout-adapter/src/letter-proof';
export const runtime='nodejs';export const dynamic='force-dynamic';
export async function GET(req:NextRequest){
 try{return NextResponse.json(await readLetterProof(req.nextUrl.searchParams.get('id')??'',req.nextUrl.searchParams.get('rule')??''),{headers:{'Cache-Control':'no-store'}});}
 catch(e){return NextResponse.json({verified:false,error:e instanceof Error?e.message:'本次未验证'},{status:400,headers:{'Cache-Control':'no-store'}});}
}
