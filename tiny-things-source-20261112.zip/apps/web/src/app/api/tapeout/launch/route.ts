import { NextRequest, NextResponse } from 'next/server';
import { LAUNCH_SUMMARY, liveLaunch, verifyLetterReceipt } from '../../../../../../../packages/tapeout-adapter/src/letter-launch';
export const runtime='nodejs';
export const dynamic='force-dynamic';
export function GET(){return NextResponse.json(LAUNCH_SUMMARY,{headers:{'Cache-Control':'no-store'}});}
export async function POST(req:NextRequest){
 try {
  const raw=await req.text();if(raw.length>3000)throw Error('请求过大');
  const body=JSON.parse(raw);
  if(typeof body.account!=='string'||!Number.isInteger(body.step)||!Array.isArray(body.hashes)||body.hashes.some((h:unknown)=>typeof h!=='string'))throw Error('请求参数无效');
  const result=body.action==='receipt'
   ? await verifyLetterReceipt(body.account,body.hashes[body.step],body.step)
   : await liveLaunch(body.account,body.step,body.hashes);
  return NextResponse.json(result,{headers:{'Cache-Control':'no-store'}});
 }catch(err){return NextResponse.json({error:err instanceof Error?err.message:'本次核对失败'},{status:400,headers:{'Cache-Control':'no-store'}});}
}
