"use client";

import Link from "next/link";
import { useParams } from "next/navigation";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { RuntimeSession } from "@tinythings/runtime";
import type { DesignGraph } from "@tinythings/schema";
import { nanoid } from "nanoid";
import { ThingPlayView } from "@/components/ThingPlayView";
import { api } from "@/lib/api";
import { toast } from "@/lib/toast";

type Release = {
  id: string;
  name: string;
  description?: string;
  author?: { displayName: string };
  manifest: { graph: DesignGraph; theme?: { music?: import("@/lib/music").MusicTrack } };
};

export default function RunPage() {
  const { releaseId } = useParams<{ releaseId: string }>();
  const [release, setRelease] = useState<Release | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [ready, setReady] = useState(false);
  const [saving, setSaving] = useState(false);
  const [flash, setFlash] = useState<string | null>(null);
  const [states, setStates] = useState<Record<string, Record<string, unknown>>>({});
  const session = useRef<RuntimeSession | null>(null);
  const serverRevision = useRef(0);
  const writeQueue = useRef<Promise<void>>(Promise.resolve());
  const instanceId = useMemo(() => `inst_${releaseId}`, [releaseId]);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const rel = await api<Release>(`/releases/${releaseId}`);
        if (cancelled) return;
        setRelease(rel);
        try {
          const rt = new RuntimeSession(rel.manifest.graph, {
            timezone: "Asia/Shanghai",
            seed: crypto.getRandomValues(new Uint32Array(1))[0],
          });
          session.current = rt;
          try {
            const remote = await api<{
              state: Record<string, Record<string, unknown>> | null;
              revision: number;
            }>(`/runtime/${instanceId}/state?releaseId=${releaseId}`);
            if (remote.state) {
              rt.loadState(remote.state, remote.revision);
              serverRevision.current = remote.revision;
              setStates(remote.state);
            } else {
              setStates(rt.getSnapshot().states);
            }
          } catch {
            setStates(rt.getSnapshot().states);
          }
          if (!cancelled) setReady(true);
        } catch (err) {
          if (!cancelled) {
            setError(
              err instanceof Error
                ? `运行时初始化失败：${err.message}`
                : "运行时初始化失败"
            );
          }
        }
      } catch (err) {
        if (!cancelled) {
          setError(err instanceof Error ? err.message : "无法加载作品");
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [releaseId, instanceId]);

  const persist = useCallback(
    (eventId: string, nextState: Record<string, Record<string, unknown>>) => {
      const job = writeQueue.current.then(async () => {
      setSaving(true);
      try {
        const res = await api<{ revision: number }>(`/runtime/${instanceId}/state`, {
          method: "PUT",
          body: JSON.stringify({
            releaseId,
            expectedRevision: serverRevision.current,
            eventId,
            nextState,
          }),
        });
        serverRevision.current = res.revision;
      } catch (err) {
        toast(
          err instanceof Error ? err.message : "云端保存失败，本地仍可继续玩",
          "error"
        );
      } finally {
        setSaving(false);
      }
      });
      writeQueue.current = job;
      return job;
    },
    [instanceId, releaseId]
  );

  useEffect(() => {
    if (!ready) return;
    const id = setInterval(() => {
      const rt = session.current;
      if (!rt) return;
      const before = rt.getSnapshot().revision;
      const snap = rt.updateTime(Date.now());
      if (snap.errors.length) return;
      if (snap.revision !== before) {
        setStates(snap.states);
        void persist(`clock_${nanoid(10)}`, snap.states);
      }
    }, 250);
    return () => clearInterval(id);
  }, [ready, persist]);

  const onInteract = async (nodeId: string, port: string) => {
    if (!ready || !session.current || !release) {
      toast("还在加载，请稍后再点", "info");
      return;
    }
    try {
      session.current.updateTime(Date.now());
      const before = session.current.getSnapshot().states;
      const eventId = `run_${nanoid(10)}`;
      const snap = session.current.tick({ eventId, nodeId, port });
      if (snap.errors.length) toast(snap.errors.join("；"), "error");
      setStates(snap.states);

      let message: string | null = null;
      for (const [id, st] of Object.entries(snap.states)) {
        const prev = before[id] ?? {};
        if ("streak" in st && Number(st.streak) > Number(prev.streak ?? 0)) {
          message = `打卡成功 · 连续 ${st.streak} 天`;
          break;
        }
        if ("last" in st && st.last && st.last !== prev.last) {
          message = `掷出 ${String(st.last)}`;
        }
        if (
          "signalCount" in st &&
          Number(st.signalCount) > Number(prev.signalCount ?? 0)
        ) {
          const need = Number(st.need ?? 3);
          message = st.unlocked
            ? "条件达成，可以读信了"
            : `进度 ${st.signalCount}/${need}`;
        }
        if ("opened" in st && st.opened && !prev.opened) {
          message = "信封打开了";
        }
        if (
          "value" in st &&
          !("ratio" in st) &&
          Number(st.value) !== Number(prev.value ?? Number.NaN)
        ) {
          message = `计数 ${st.value}`;
        }
      }
      if (
        !message &&
        release.manifest.graph.nodes.some((n) => n.type === "dateGate") &&
        port === "press"
      ) {
        message = "今天已经打过卡啦";
      }
      setFlash(message);
      await persist(eventId, snap.states);
    } catch (err) {
      toast(err instanceof Error ? err.message : "运行失败", "error");
    }
  };

  if (error) {
    return (
      <div className="mx-auto max-w-md p-10 text-center">
        <p className="text-tt-ink">{error}</p>
        <div className="mt-4 flex justify-center gap-3">
          <button className="tt-btn-secondary" onClick={() => location.reload()}>
            重试
          </button>
          <Link href="/discover" className="tt-btn">
            返回
          </Link>
        </div>
      </div>
    );
  }

  if (!release) {
    return <div className="p-10 text-center text-tt-muted">读取发布清单…</div>;
  }

  return (
    <div className="mx-auto flex min-h-[70vh] max-w-[480px] flex-col px-4 py-8">
      <div className="mb-4 text-center">
        <h1 className="text-2xl font-medium text-tt-ink">{release.name}</h1>
        <p className="mt-1 text-sm text-tt-muted">
          {release.author?.displayName
            ? `作者 ${release.author.displayName} · `
            : ""}
          固定版本链接
          {saving ? " · 保存中…" : ""}
        </p>
      </div>

      <div
        className="relative overflow-hidden rounded-[30px] border border-white/80 p-4 shadow-panel"
        style={{
          background:
            "linear-gradient(165deg, #fff8fd 0%, #f3efff 45%, #eef6ff 100%)",
        }}
      >
        <ThingPlayView
          name={release.name}
          music={release.manifest.theme?.music}
          graphOrNodes={release.manifest.graph}
          states={states}
          flash={flash}
          onInteract={onInteract}
        />
      </div>

      <div className="mt-8 flex w-full gap-3 pb-[env(safe-area-inset-bottom)]">
        <Link
          href={`/things/${release.id}`}
          className="tt-btn-secondary flex-1 text-center"
        >
          作品详情
        </Link>
        <Link href="/discover" className="tt-btn flex-1 text-center">
          发现更多
        </Link>
      </div>
    </div>
  );
}
