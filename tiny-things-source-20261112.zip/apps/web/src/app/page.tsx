"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { nanoid } from "nanoid";
import { createDraft } from "@tinythings/schema";
import { HeroIsland } from "@/components/HeroIsland";
import { ValueIcon } from "@/components/VoxelIcons";
import { listLocalDrafts, saveLocalDraft } from "@/lib/localDrafts";
import { TEMPLATES } from "@tinythings/block-registry";
import Image from "next/image";
import { coverFor } from "@/lib/art";
import { toast } from "@/lib/toast";

const values = [
  {
    kind: "code" as const,
    title: "无需编程",
    desc: "拖拽零件就能拼出逻辑",
  },
  {
    kind: "usable" as const,
    title: "真实可用",
    desc: "不只是玩具，能真正运行",
  },
  {
    kind: "share" as const,
    title: "可分享与复用",
    desc: "固定版本链接，复制继续改造",
  },
  {
    kind: "tapeout" as const,
    title: "本地就能跑",
    desc: "作品自动存本机，随时导出带走",
  },
];

export default function HomePage() {
  const router = useRouter();
  const [pending, setPending] = useState<{ id: string; name: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const [chooser, setChooser] = useState(false);

  useEffect(() => {
    listLocalDrafts().then((d) => {
      if (d[0]) setPending({ id: d[0].id, name: d[0].name });
    });
  }, []);

  async function startCreate() {
    setBusy(true);
    setChooser(false);
    try {
      const localId = `local_${nanoid(8)}`;
      const seeded = { ...createDraft(), name: "未命名小东西" };
      await saveLocalDraft({
        ...seeded,
        id: localId,
        name: "未命名小东西",
        updatedAt: new Date().toISOString(),
        storage: "local",
      });
      router.push(`/make/${localId}`);
    } catch (err) {
      toast(err instanceof Error ? err.message : "创建失败", "error");
    } finally {
      setBusy(false);
    }
  }

  function onStartClick() {
    if (pending) setChooser(true);
    else void startCreate();
  }

  return (
    <div className="mx-auto max-w-[1440px] px-4 pb-16 pt-6 md:px-12 md:pt-10">
      <section className="grid items-center gap-8 md:grid-cols-[minmax(0,0.85fr)_minmax(0,1.15fr)] md:gap-10">
        <div className="max-w-[460px] md:pt-8">
          <h1 className="font-pixel text-[32px] leading-[1.15] text-tt-deep md:whitespace-nowrap md:text-[clamp(24px,3.4vw,44px)] md:leading-[1.4]">
            Tiny Things
          </h1>
          <p className="mt-3 text-[28px] font-medium leading-9 text-tt-ink md:text-[32px] md:leading-10">
            小东西制造所
          </p>
          <p className="mt-4 text-base leading-7 text-tt-muted md:text-lg md:leading-7">
            把简单的零件拼在一起，创造一个属于你的数字小物件。拖进去、连上线、立刻能玩。
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <button
              className="tt-btn h-14 min-w-[200px] rounded-[14px] text-base"
              disabled={busy}
              onClick={onStartClick}
            >
              {busy ? "创建中…" : "开始创造 →"}
            </button>
            <Link href="/demo" className="tt-btn-secondary h-14 rounded-[14px]">
              先玩一下 ♡
            </Link>
          </div>
        </div>
        <div className="md:min-h-[420px]">
          <HeroIsland />
        </div>
      </section>

      <section className="gift-invite mt-8 flex flex-wrap items-center justify-between gap-6 rounded-[24px] p-6 md:mt-10 md:px-8 md:py-7">
        <div className="relative z-10"><span className="text-[10px] tracking-[0.16em] text-[#b1859c]">FOR SOMEONE SPECIAL</span><h2 className="mt-2 text-xl font-medium text-[#8a5675] md:text-2xl">有些话，想让你亲手拆开 ♡</h2><p className="mt-2 text-xs leading-6 text-[#aa8196]">摇一颗小骰子，解锁一封信。把平凡的一天，变成你们的小纪念。</p></div>
        <div className="relative z-10 flex flex-wrap gap-3"><Link href="/make?template=love-letter" className="love-apply inline-flex items-center">做一封小情书 →</Link><Link href="/play?template=love-letter" className="inline-flex items-center rounded-xl border border-[#efd0e0] bg-white/60 px-4 py-3 text-sm text-[#a3718c]">先拆一封看看</Link></div>
      </section>

      <section className="tt-panel mt-10 grid gap-5 p-5 md:mt-12 md:grid-cols-4 md:p-6 md:py-7">
        {values.map((v) => (
          <div key={v.title} className="flex gap-3 px-1">
            <ValueIcon kind={v.kind} />
            <div>
              <div className="text-base font-medium text-tt-ink">{v.title}</div>
              <p className="mt-1 text-sm leading-5 text-tt-muted">{v.desc}</p>
            </div>
          </div>
        ))}
      </section>

      <section className="mt-10">
        <div className="mb-5 flex items-end justify-between"><div><p className="text-xs tracking-[0.2em] text-tt-deep">SMALL THINGS, REAL JOY</p><h2 className="mt-2 text-2xl font-medium">从一个小东西开始</h2></div><Link href="/discover" className="text-sm text-tt-deep">逛逛制造所 →</Link></div>
        <div className="grid gap-5 sm:grid-cols-3">{["love-letter", "daily-checkin", "habit-builder"].map((id) => { const t = TEMPLATES.find((v) => v.id === id)!; return <Link key={id} href={`/play?template=${id}`} className="home-thing group tt-panel overflow-hidden"><div className="relative aspect-[16/9] overflow-hidden"><Image src={coverFor(t.category, t.name)} alt={t.name} fill sizes="(max-width:640px) 100vw, 33vw" className="object-cover transition duration-500 group-hover:scale-105" /></div><div className="p-5"><h3 className="font-medium">{t.name}<span className="float-right text-tt-primary">↗</span></h3><p className="mt-2 text-xs leading-5 text-tt-muted">{t.description}</p><span className="mt-4 inline-block rounded-full bg-tt-bg px-3 py-1 text-xs text-tt-deep">先试玩，再改造</span></div></Link>; })}</div>
      </section>

      {chooser && pending && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-[#302740]/40 p-0 md:items-center md:p-4">
          <div className="tt-panel w-full max-w-[480px] rounded-t-panel p-6 md:rounded-panel">
            <h3 className="text-lg font-medium">继续未完成的草稿？</h3>
            <p className="mt-2 text-sm text-tt-muted">
              检测到「{pending.name}」。可以继续编辑，或新建一份。
            </p>
            <div className="mt-5 flex flex-col gap-2">
              <button
                className="tt-btn"
                onClick={() => router.push(`/make/${pending.id}`)}
              >
                继续编辑
              </button>
              <button className="tt-btn-secondary" disabled={busy} onClick={() => void startCreate()}>
                新建草稿
              </button>
              <button className="tt-btn-secondary" onClick={() => setChooser(false)}>
                取消
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
