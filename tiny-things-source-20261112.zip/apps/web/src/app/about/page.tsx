import Link from "next/link";
export default function AboutPage() {
  return <div className="mx-auto max-w-3xl px-4 py-12 md:px-8">
    <span className="text-xs tracking-[0.2em] text-tt-deep">A SMALL WORKSHOP FOR YOUR IDEAS</span>
    <h1 className="mt-4 font-pixel text-xl text-tt-deep md:text-2xl">Tiny Things</h1>
    <p className="mt-4 text-lg">把一个小想法，做成每天都能用的小东西。</p>
    <section className="tt-panel mt-8 space-y-4 p-6 text-sm leading-7 text-tt-muted">
      <h2 className="text-lg font-medium text-tt-ink">你的桌面，你的零件</h2>
      <p>放一个按钮，接上计数器，再加一条进度。你可以从模板开始，也可以从空白工作台慢慢拼。每条线决定零件之间如何协作。</p>
      <p>草稿保存在当前浏览器。导出作品文件可以备份或带到另一台电脑；快照链接可以让别人试玩和复制改造。清除浏览器数据前，请先导出备份。</p>
      <Link href="/make" className="tt-btn">做一个小东西 →</Link>
    </section>
    <section className="tt-panel mt-6 space-y-4 p-6 text-sm leading-7 text-tt-muted">
      <h2 className="text-lg font-medium text-tt-ink">好奇零件背后的逻辑？</h2>
      <p>工作台能把两种情书解锁规则编译为有状态 NAND＋LATCH 电路，也支持范围内的计数器 NAND 编译。电路观察室还能读取 X Layer 上的真实 TapeOut 电路，比较本地计算与合约输出。</p>
      <p>本地编译、读取链上电路与把作品流片是不同步骤。当前试玩使用本地电路。两种固定情书规则已通过隔离合约演练；正式流片需要用户在自己的钱包逐笔确认。观察室提供正式情书电路的网表与 step 比对，未流片的作品不会标为已上链。</p>
      <Link href="/circuits" className="tt-btn-secondary">打开电路观察室 →</Link>
    </section>
  </div>;
}
