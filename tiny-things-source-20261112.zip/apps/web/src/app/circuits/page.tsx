"use client";
import { LetterCircuitProof } from "@/components/LetterCircuitProof";
import { useState } from "react";
import Link from "next/link";
import type { readCircuit } from "@/lib/circuit-reader";
type Evidence = Awaited<ReturnType<typeof readCircuit>>;
export default function CircuitsPage() {
  const [processor, setProcessor] = useState("");
  const [id, setId] = useState("1");
  const [result, setResult] = useState<Evidence | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  async function verify() {
    setBusy(true); setResult(null); setError("");
    try {
      const response = await fetch(`/api/circuit?${new URLSearchParams({ processor, id })}`);
      const data = await response.json();
      if (!response.ok) throw new Error(data.error ?? "读取失败");
      setResult(data);
    } catch (err) { setError(err instanceof Error ? err.message : "读取失败"); }
    finally { setBusy(false); }
  }
  return <div className="mx-auto max-w-3xl px-4 py-10">
    <Link href="/make" className="text-sm text-tt-deep">← 回到制造台</Link>
    <Link href="/launch" className="mt-5 block rounded-2xl border border-pink-200 bg-pink-50 p-4 text-sm text-tt-deep">💌 情书电路准备好了 · 连接钱包，逐步流片 →</Link>
    <LetterCircuitProof />
    <div className="mt-6 tt-panel p-6 md:p-8"><span className="text-xs tracking-widest text-tt-deep">TAPEOUT × X LAYER</span><h1 className="mt-2 text-3xl font-medium">电路观察室</h1><p className="my-4 text-sm leading-7 text-tt-muted">读取真实电路，在同一区块比较链上输出与本地 NAND 结果。无需钱包，不发送交易。</p>
      <label className="block text-sm">Circuits 合约地址<input className="tt-input mt-2" placeholder="留空使用 Factory 登记的第一个处理器" value={processor} onChange={(e) => setProcessor(e.target.value)} /></label>
      <label className="mt-4 block text-sm">电路 ID<input className="tt-input mt-2" inputMode="numeric" value={id} onChange={(e) => setId(e.target.value)} /></label>
      <button className="tt-btn mt-5" disabled={busy} onClick={() => void verify()}>{busy ? "读取并比对中…" : "读取真实电路"}</button>
      {error && <p role="alert" className="mt-5 rounded-xl bg-rose-50 p-4 text-sm text-rose-800">本次未验证：{error}</p>}
      {result && <div className="mt-6 space-y-4"><p className={`rounded-xl p-4 text-sm ${result.verified ? "bg-emerald-50 text-emerald-800" : "bg-amber-50 text-amber-900"}`}>{result.verified ? `${result.vectors.length} 组输入逐位一致` : "已读取，未完成输出验证"} · {result.note}</p>
        <div className="grid grid-cols-2 gap-3 text-sm"><div>网络：X Layer / {result.chainId}</div><div>区块：{result.blockNumber}</div><div>输入 / 输出：{result.nIn} / {result.nOut}</div><div>NAND 门：{result.gateCount}</div></div>
        <p className="break-all text-xs leading-6 text-tt-muted">合约 {result.processor}<br />区块哈希 {result.blockHash}<br />读取时间 {new Date(result.checkedAt).toLocaleString("zh-CN", { timeZone: "Asia/Shanghai", hour12: false })}（上海时间）<br />该合约流片协议费 {result.feeWei} wei（不含晶体管与网络费用）</p>
        {result.vectors.length > 0 && <div className="overflow-x-auto"><table className="w-full text-left text-sm"><thead><tr><th className="p-2">输入</th><th>本地</th><th>链上</th><th>比对</th></tr></thead><tbody>{result.vectors.map((v, i) => <tr key={i} className="border-t border-tt-border"><td className="p-2 font-mono">{v.input.map(Number).join("")}</td><td>{v.local.map(Number).join("")}</td><td>{v.chain.map(Number).join("")}</td><td>{v.match ? "一致" : "不一致"}</td></tr>)}</tbody></table></div>}
      </div>}
    </div>
  </div>;
}
