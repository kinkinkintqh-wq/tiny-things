import type { Metadata } from 'next';
export const metadata:Metadata={title:'先玩一下 ♡｜Tiny Things 小东西制造所',description:'掷骰拆一封情书，按爱心记录今天。不写代码，把零件拼成能玩的数字小礼物。',openGraph:{title:'有一份小心意，等你亲手拆开 ♡',description:'Tiny Things｜无需登录，打开就能玩的数字小礼物。',type:'website',images:[{url:'/art/device-checkin.jpg',width:864,height:1152,alt:'Tiny Things 爱心打卡机'}]}};
export default function DemoLayout({children}:{children:React.ReactNode}){return children;}
