"use client";
import Link from 'next/link';
import { useEffect,useRef,useState } from 'react';
import { draftFromTemplate, getBlock } from '@tinythings/block-registry';
import { RuntimeSession } from '@tinythings/runtime';
import type { DraftPayload } from '@tinythings/schema';
import { ThingPlayView } from '@/components/ThingPlayView';
import { demoLink,localPreview } from '@/lib/share-link';
import { checkLetterTransitions,chainRunLabel,type ChainRun } from '@/lib/letter-chain';
const things=[{id:'love-letter',icon:'💌',name:'骰子情书',hint:'掷出 12 点，亲手拆一封信',copy:'做一封自己的情书'},{id:'daily-checkin',icon:'🌷',name:'爱心打卡机',hint:'按下爱心，让今天被记住',copy:'改造我的打卡机'},{id:'habit-builder',icon:'🌱',name:'小习惯养成',hint:'每一小步，都看得见',copy:'做一个习惯小物件'}];
type States=Record<string,Record<string,unknown>>;
export default function DemoPage(){
 const [active,setActive]=useState('love-letter'),[draft,setDraft]=useState<DraftPayload|null>(null),[states,setStates]=useState<States>({});
 const [error,setError]=useState(''),[shareUrl,setShareUrl]=useState(''),[notice,setNotice]=useState(''),[showParts,setShowParts]=useState(false),[version,setVersion]=useState(0);
 const session=useRef<RuntimeSession|null>(null);
 const checking=useRef(false);
 const [chainRun,setChainRun]=useState<ChainRun|null>(null),[checkingUI,setCheckingUI]=useState(false);
 useEffect(()=>{const id=new URLSearchParams(location.search).get('thing');if(things.some(t=>t.id===id))setActive(id!);},[]);
 useEffect(()=>{
  const d=draftFromTemplate(active);
  const rt=new RuntimeSession(d.graph,{seed:crypto.getRandomValues(new Uint32Array(1))[0]});session.current=rt;setDraft(d);setStates(rt.getSnapshot().states);setError('');setNotice('');setShareUrl('');setShowParts(false);setChainRun(null);checking.current=false;setCheckingUI(false);
  const timer=setInterval(()=>{const before=rt.getSnapshot().revision;const snap=rt.updateTime(Date.now());if(snap.errors.length)setError(snap.errors.join('；'));if(snap.revision!==before)setStates(snap.states);},250);
  return()=>{clearInterval(timer);session.current=null;};
 },[active,version]);
 async function interact(nodeId:string,port:string){const rt=session.current;if(!rt||checking.current)return;checking.current=true;setCheckingUI(true);rt.updateTime(Date.now());let run:ChainRun|null=null;const snap=await rt.tickVerified({eventId:crypto.randomUUID(),nodeId,port},async steps=>{run=await checkLetterTransitions(steps);});if(session.current!==rt)return;setStates(snap.states);setError(snap.errors.join('；'));if(run)setChainRun(run);checking.current=false;setCheckingUI(false);}
 async function share(){
  const url=demoLink(location.origin,active);setShareUrl(url);
  if(localPreview(url)){setNotice('这是本机预览地址，暂时只能在这台电脑打开。正式上线后，同一个入口就能分享给朋友。');return;}
  try{if(navigator.share){await navigator.share({title:'Tiny Things｜来拆一封小心意',text:'不写代码，把一个小想法拼成能玩的小礼物。',url});setNotice('分享面板已打开');}else{await navigator.clipboard.writeText(url);setNotice('链接已复制，发给喜欢的人吧 ♡');}}
  catch(e){if((e as {name?:string}).name!=='AbortError')setNotice('可以复制下方链接，发给朋友。');}
 }
 const selected=things.find(t=>t.id===active)!;
 const env=draft?.graph.nodes.find(n=>n.type==='envelope');const opened=env&&Boolean(states[env.id]?.opened);
 return <div className="mx-auto max-w-6xl px-4 py-6 md:px-8 md:py-10">
  <div className="mb-7 flex flex-wrap items-end justify-between gap-4"><div><p className="text-[10px] tracking-[.2em] text-tt-deep">TINY THINGS · LITTLE JOYS, MADE BY YOU</p><h1 className="mt-3 text-3xl font-medium leading-tight text-[#805d78] md:text-4xl">先玩一下，再做一个 ♡</h1><p className="mt-3 text-sm leading-7 text-tt-muted">一封要亲手拆开的信，一台记住今天的小机器。这里的小东西，都由零件连接而成。</p></div><span className="rounded-full border border-white bg-white/70 px-4 py-2 text-xs text-tt-deep">无需登录 · 无需钱包</span></div>
  <div className="grid items-start gap-6 lg:grid-cols-[minmax(0,1fr)_340px]">
   <section className="tt-panel min-w-0 overflow-hidden"><div className="flex gap-2 border-b border-tt-border bg-[#f7f2ff] p-3" role="group" aria-label="选择试玩小东西">{things.map(t=><button key={t.id} aria-pressed={active===t.id} onClick={()=>setActive(t.id)} className={`min-w-0 flex-1 rounded-xl px-2 py-3 text-xs transition md:text-sm ${active===t.id?'bg-white font-medium text-tt-deep shadow-soft':'text-tt-muted hover:bg-white/60'}`}><span className="mr-1" aria-hidden>{t.icon}</span>{t.name}</button>)}</div>
    <div className="mx-auto max-w-[520px] px-3 py-5 md:px-5"><p className="mb-4 text-center text-xs leading-6 text-[#ad849d]">{selected.hint}</p>{draft?<ThingPlayView key={`${active}:${version}`} name={draft.name} graphOrNodes={draft.graph} states={states} onInteract={(id,port)=>void interact(id,port)} music={draft.theme.music}/>:<p className="p-12 text-center text-tt-muted">正在摆好小零件…</p>}{checkingUI&&<p role="status" className="mt-3 text-center text-xs text-tt-muted">正在核对小约定…</p>}{active==='love-letter'&&<p className="mt-3 text-center text-[10px] leading-6 text-tt-muted">{chainRunLabel(chainRun)}</p>}{error&&<p role="alert" className="mt-4 text-sm text-rose-700">{error}</p>}</div>
    <div className="flex flex-wrap items-center justify-between gap-3 border-t border-tt-border px-5 py-4"><p className="text-xs text-tt-muted">{opened?'心意已送达，轮到你写下一封了。':'直接点画面里的骰子或爱心试试。'}</p><button className="text-xs text-tt-deep underline underline-offset-4" onClick={()=>setVersion(n=>n+1)}>重新试玩</button></div>
   </section>
   <aside className="space-y-5">
    <div className="rounded-[24px] border border-pink-100 bg-[#fff4f8] p-6 shadow-soft"><span className="text-3xl" aria-hidden>✉️</span><h2 className="mt-3 text-xl font-medium text-[#8a5675]">把心意，变成小礼物</h2><p className="mt-3 text-sm leading-7 text-tt-muted">写下想说的话，挑一个小约定，再配一首曲子。喜欢的玩法还可以继续拼、继续改。</p><Link href={`/make?template=${active}`} className="love-apply mt-5 inline-flex w-full items-center justify-center text-sm">{selected.copy} →</Link><button className="tt-btn-secondary mt-3 w-full" onClick={()=>void share()}>分享这个小东西</button>{notice&&<p role="status" className="mt-3 text-xs leading-6 text-tt-muted">{notice}</p>}{shareUrl&&<label className="mt-3 block text-xs text-tt-muted">试玩链接<input className="tt-input mt-2 text-xs" readOnly value={shareUrl} onFocus={e=>e.target.select()}/></label>}</div>
    <div className="tt-panel p-6"><h2 className="text-base font-medium">小零件，真的连在一起</h2><p className="mt-3 text-sm leading-7 text-tt-muted">画面里的按钮会发出事件，连线把它送到下一个零件。改一个规则，玩法就会改变。</p><button className="mt-3 text-sm text-tt-deep underline underline-offset-4" aria-expanded={showParts} onClick={()=>setShowParts(v=>!v)}>看看零件怎样连接</button>{showParts&&draft&&<ol className="mt-4 space-y-2">{draft.graph.edges.filter(e=>e.kind==='event').map(e=>{const source=draft.graph.nodes.find(n=>n.id===e.source);const target=draft.graph.nodes.find(n=>n.id===e.target);return <li key={e.id} className="rounded-xl bg-tt-bg p-3 text-xs leading-6"><span>{String(source?.config.label??getBlock(source?.type??"")?.label??"零件")}</span><span className="mx-2 text-tt-primary">→</span><span>{String(target?.config.label??getBlock(target?.type??"")?.label??"零件")}</span><span className="mt-1 block text-[10px] text-tt-muted">{getBlock(source?.type??"")?.outputPorts.find(p=>p.id===e.sourcePort)?.label??"事件"} → {getBlock(target?.type??"")?.inputPorts.find(p=>p.id===e.targetPort)?.label??"事件"}</span></li>;})}</ol>}</div>
    <div className="rounded-[24px] border border-tt-border bg-[#f1ecff] p-6"><p className="text-[10px] tracking-[.16em] text-tt-deep">POWERED BY SMALL RULES</p><h2 className="mt-3 text-lg font-medium">可爱之外，也有逻辑</h2><p className="mt-3 text-sm leading-7 text-tt-muted">情书的进度与解锁由本地 NAND＋LATCH 电路计算。同样的电路包已通过 X Layer 固定区块的隔离合约演练，正式流片仍待钱包签名。</p><Link href="/circuits" className="mt-4 inline-block text-sm text-tt-deep underline underline-offset-4">看看电路与验证 →</Link><p className="mt-3 text-[11px] leading-6 text-tt-muted">骰子随机数和进度存储由网页提供；当前试玩不是链上随机或加密私信。</p></div>
   </aside>
  </div>
  <div className="mt-8 grid gap-4 rounded-[24px] border border-white/80 bg-white/50 p-6 text-sm sm:grid-cols-3">{[['01','选一份小心意','从模板开始，不用面对空白画布。'],['02','拼出你的小约定','写信、连线、选配乐，随时预览。'],['03','送给想送的人','生成作品快照，让对方打开就能玩。']].map(([n,title,desc])=><div key={n}><span className="font-pixel text-[10px] text-tt-primary">{n}</span><h2 className="mt-2 font-medium">{title}</h2><p className="mt-2 text-xs leading-6 text-tt-muted">{desc}</p></div>)}</div>
 </div>;
}
