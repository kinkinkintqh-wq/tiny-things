"use client";

import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { nanoid } from "nanoid";
import { draftFromTemplate, TEMPLATES } from "@tinythings/block-registry";
import { RuntimeSession } from "@tinythings/runtime";
import type { DraftPayload } from "@tinythings/schema";
import { ThingPlayView } from "@/components/ThingPlayView";
import { decodeDesign, downloadDesign, encodeDesign } from "@/lib/portable";
import { saveLocalDraft } from "@/lib/localDrafts";
import { localPreview } from "@/lib/share-link";
import { toast } from "@/lib/toast";
import {checkLetterTransitions,chainRunLabel,type ChainRun} from '@/lib/letter-chain';

type States = Record<string, Record<string, unknown>>;
export default function PortablePlayer() {
  const router = useRouter();
  const [draft, setDraft] = useState<DraftPayload | null>(null);
  const [states, setStates] = useState<States>({});
  const [error, setError] = useState("");
  const [flash, setFlash] = useState<string | null>(null);
  const session = useRef<RuntimeSession | null>(null);
  const checking=useRef(false);
  const [chainRun,setChainRun]=useState<ChainRun|null>(null),[checkingUI,setCheckingUI]=useState(false);
  const key = useRef("");
  const skipCache = useRef(false);
  const [shareUrl,setShareUrl] = useState("");
  const [shareNotice,setShareNotice] = useState("");
  const [storageError, setStorageError] = useState(false);
  const [locationVersion, setLocationVersion] = useState(0);
  useEffect(() => {
    const changed = () => setLocationVersion((n) => n + 1);
    window.addEventListener("hashchange", changed);
    return () => window.removeEventListener("hashchange", changed);
  }, []);

  useEffect(() => {
    setError(""); setDraft(null); setFlash(null); setStorageError(false);
    session.current = null;
    checking.current=false;setCheckingUI(false);setChainRun(null);
    let cancelled = false;
    let interval: ReturnType<typeof setInterval> | undefined;
    async function load() {
      try {
        let encoded = window.location.hash.slice(1);
        const template = new URLSearchParams(window.location.search).get("template");
        if (!encoded && template && TEMPLATES.some((t) => t.id === template)) encoded = encodeDesign(draftFromTemplate(template));
        if (!encoded) throw new Error("链接里没有作品，请从制造台生成分享链接");
        const value = decodeDesign(encoded);
        const digest = crypto.subtle ? await crypto.subtle.digest("SHA-256", new TextEncoder().encode(encoded)) : null;
        if (cancelled) return;
        key.current = `tt-play:${digest ? Array.from(new Uint8Array(digest), (b) => b.toString(16).padStart(2, "0")).join("") : encoded}`;
        const rt = new RuntimeSession(value.graph, { seed: crypto.getRandomValues(new Uint32Array(1))[0] });
        try {
          const cached = skipCache.current ? null : localStorage.getItem(key.current);
          skipCache.current = false;
          if (cached) rt.loadState(JSON.parse(cached));
        } catch { setStorageError(true); }
        session.current = rt;
        setDraft(value);
        setStates(rt.updateTime(Date.now()).states);
        interval = setInterval(() => {
          const before = rt.getSnapshot().revision;
          const snap = rt.updateTime(Date.now());
          if (snap.errors.length) { setFlash(snap.errors.join("；")); return; }
          if (snap.revision !== before) { setStates(snap.states); store(snap.states); }
        }, 250);
      } catch (err) { if (!cancelled) setError(err instanceof Error ? err.message : "作品链接无效"); }
    }
    void load();
    return () => { cancelled = true; clearInterval(interval); };
  }, [locationVersion]);

  function store(next: States) {
    try { localStorage.setItem(key.current, JSON.stringify(next)); }
    catch { setStorageError(true); }
  }
  async function interact(nodeId: string, port: string) {
    const rt = session.current;
    if (!rt||checking.current) return;
    checking.current=true;setCheckingUI(true);
    rt.updateTime(Date.now());
    let run:ChainRun|null=null;
    const snap = await rt.tickVerified({ eventId: nanoid(), nodeId, port },async steps=>{run=await checkLetterTransitions(steps);});
    if(session.current!==rt)return;
    checking.current=false;setCheckingUI(false);if(run)setChainRun(run);
    setStates(snap.states);
    setFlash(snap.errors.length ? snap.errors.join("；") : null);
    if (!snap.errors.length) store(snap.states);
  }
  function reset() {
    skipCache.current = true;
    try { localStorage.removeItem(key.current); } catch { setStorageError(true); }
    setLocationVersion(v=>v+1);
  }
  async function share() {
    if (!draft) return;
    const encoded = encodeDesign(draft);
    if (encoded.length > 12000) { setShareNotice("作品链接较大，请用「导出作品」保存文件并发送。"); return; }
    const url = `${location.origin}/play#${encoded}`;
    setShareUrl(url);
    if (localPreview(url)) { setShareNotice("当前是本机预览，对方暂时无法访问。上线后可以直接分享这个作品；现在可导出文件带走。"); return; }
    try {
      if (navigator.share) await navigator.share({ title:draft.name, text:"给你的一份小心意 ♡", url });
      else { await navigator.clipboard.writeText(url); setShareNotice("作品链接已复制 ♡"); }
    } catch (err) { if ((err as {name?:string}).name !== "AbortError") setShareNotice("可以复制下面的作品链接。"); }
  }
  async function remix() {
    if (!draft) return;
    try {
      const id = `local_${nanoid(8)}`;
      await saveLocalDraft({ ...draft, id, revision: 0, updatedAt: new Date().toISOString(), storage: "local" });
      router.push(`/make/${id}`);
    } catch { toast("无法保存到浏览器，请检查存储权限", "error"); }
  }
  if (error) return <div className="tt-panel mx-auto mt-16 max-w-lg p-8"><h1 className="text-xl">暂时无法打开作品</h1><p className="my-4 text-sm text-tt-muted">{error}</p><Link className="tt-btn" href="/make">去制造台</Link></div>;
  if (!draft) return <p className="p-12 text-center text-tt-muted">正在拆开这个小东西…</p>;
  const isLetter = draft.graph.nodes.some((n) => n.type === "envelope");
  return <div className="mx-auto max-w-[520px] px-4 py-6">
    <div className="mb-5 text-center"><span className="text-[10px] tracking-[0.2em] text-[#a9859c]">TINY THINGS · 小小心意制造所</span>{!isLetter && <h1 className="mt-2 text-xl font-medium text-[#805d78]">{draft.name}</h1>}</div>
    <ThingPlayView name={draft.name} graphOrNodes={draft.graph} states={states} flash={flash} onInteract={(id,port)=>void interact(id,port)} music={draft.theme.music} />
    {checkingUI&&<p role="status" className="mt-3 text-center text-xs text-tt-muted">正在核对小约定…</p>}
    {isLetter&&<p className="mt-3 text-center text-[10px] leading-6 text-tt-muted">{chainRunLabel(chainRun)}</p>}
    {storageError && <p role="status" className="mt-3 text-sm text-tt-muted">浏览器存储不可用，本次进度可能无法保留。</p>}
    <div className="mt-5 flex flex-wrap gap-3"><button className="tt-btn flex-1" onClick={() => void remix()}>我也做一个 ♡</button><button className="tt-btn-secondary" onClick={() => void share()}>分享作品</button><button className="tt-btn-secondary" onClick={() => downloadDesign(draft)}>导出作品</button></div>
    <div className="mt-4 flex justify-between gap-4 text-xs leading-6 text-tt-muted"><button className="shrink-0 text-tt-deep underline underline-offset-4" onClick={reset}>重新试玩</button><span>{isLetter ? "作品链接包含信件原文，请只发给想送的人。" : "草稿与进度保存在当前浏览器。"}</span></div>
    {shareNotice && <p role="status" className="mt-3 text-xs leading-6 text-tt-muted">{shareNotice}</p>}
    {shareUrl && <label className="mt-3 block text-xs text-tt-muted">作品链接<input className="tt-input mt-2 text-xs" readOnly value={shareUrl} onFocus={e=>e.target.select()}/></label>}
  </div>;
}
