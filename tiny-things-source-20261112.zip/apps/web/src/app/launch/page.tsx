"use client";
import Link from 'next/link';
import { useEffect, useRef, useState } from 'react';
import { assertWallet, connectAccounts, JOURNAL_KEY, okb, parseJournal, walletMessage, walletRead, type LaunchJournal, type WalletChoice, type WalletProvider } from '@/lib/launch-wallet';
interface Quote {account:string;step:number;checkedAt:string;balanceWei:string;maximumTotalWei:string;planHash:string;transaction:{from:string;to:string;data:string;value:string;gas:string;gasPrice:string;chainId:string}|null}
const labels=['准备 787 枚 NAND','准备 16 枚 LATCH','流片「累计 12 点」','流片「收集三个 6」'];
const planHash='c3e83ac2a9ac14614468cc2c58a04140eeb220a82004af0ffa05cb1f6f9fc14e';
export default function LaunchPage(){
 const [wallets,setWallets]=useState<WalletChoice[]>([]),[selected,setSelected]=useState<WalletChoice|null>(null);
 const [journal,setJournal]=useState<LaunchJournal|null>(null),[quote,setQuote]=useState<Quote|null>(null);
 const [busy,setBusy]=useState(false),[error,setError]=useState(''),[notice,setNotice]=useState(''),[recover,setRecover]=useState('');
 const [evidence,setEvidence]=useState<unknown[]>([]);
 const [storageFault,setStorageFault]=useState(false);
 const inFlight=useRef(false),epoch=useRef(0);
 useEffect(()=>{
  try{const raw=localStorage.getItem(JOURNAL_KEY);const parsed=parseJournal(raw);setJournal(parsed);if(raw&&!parsed){setStorageFault(true);setError('本机交易记录无法读取，请先在钱包中核对历史，暂勿重复付款。');}}catch{setStorageFault(true);setError('无法读取本机交易记录，请允许此站点保存数据后再操作。');}
  const add=(w:WalletChoice)=>setWallets(old=>old.some(x=>x.provider===w.provider)?old:[...old,w]);
  const announce=(event:Event)=>{const d=(event as CustomEvent).detail;if(d?.provider?.request&&typeof d.info?.name==='string'&&typeof d.info?.uuid==='string')add({id:d.info.uuid,name:d.info.name.slice(0,50),provider:d.provider});};
  window.addEventListener('eip6963:announceProvider',announce);window.dispatchEvent(new Event('eip6963:requestProvider'));
  const legacy=(window as Window&{ethereum?:WalletProvider;okxwallet?:WalletProvider}).okxwallet??(window as Window&{ethereum?:WalletProvider}).ethereum;
  if(legacy?.request)add({id:'injected',name:'浏览器钱包',provider:legacy});
  const storage=(e:StorageEvent)=>{if(e.key!==JOURNAL_KEY)return;epoch.current++;setQuote(null);const saved=parseJournal(e.newValue);setJournal(saved);if(e.newValue&&!saved)setStorageFault(true);setNotice('另一个页面更新了交易记录，请重新核对。');};
  window.addEventListener('storage',storage);
  return ()=>{window.removeEventListener('eip6963:announceProvider',announce);window.removeEventListener('storage',storage);};
 },[]);
 useEffect(()=>{
  if(!selected)return;
  const changed=()=>{epoch.current++;setQuote(null);setSelected(null);setNotice('钱包账号或网络发生变化，请重新连接。');};
  selected.provider.on?.('accountsChanged',changed);selected.provider.on?.('chainChanged',changed);selected.provider.on?.('disconnect',changed);
  return ()=>{selected.provider.removeListener?.('accountsChanged',changed);selected.provider.removeListener?.('chainChanged',changed);selected.provider.removeListener?.('disconnect',changed);};
 },[selected]);
 function persist(j:LaunchJournal){localStorage.setItem(JOURNAL_KEY,JSON.stringify(j));setJournal(j);}
 async function action(fn:()=>Promise<void>){if(inFlight.current)return;inFlight.current=true;setBusy(true);setError('');try{await fn();}catch(e){setError(walletMessage(e));}finally{inFlight.current=false;setBusy(false);}}
 async function api(body:Record<string,unknown>){const r=await fetch('/api/tapeout/launch',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body),signal:AbortSignal.timeout(45000)});const data=await r.json();if(!r.ok)throw Error(data.error??'核对暂未完成');return data;}
 async function connect(w:WalletChoice){await action(async()=>{
  const accounts=await connectAccounts(w.provider);
  if(!Array.isArray(accounts)||typeof accounts[0]!=='string'||!/^0x[0-9a-f]{40}$/i.test(accounts[0]))throw Error('钱包没有返回有效地址');
  const account=accounts[0];
  if(journal&&journal.account.toLowerCase()!==account.toLowerCase())throw Error('这份流片记录属于另一个钱包，请切回原钱包继续。');
  if(await walletRead(()=>w.provider.request({method:'eth_chainId'}))!=='0xc4'){
   try{await walletRead(()=>w.provider.request({method:'wallet_switchEthereumChain',params:[{chainId:'0xc4'}]}));}
   catch(e){if((e as {code?:number}).code!==4902)throw e;await walletRead(()=>w.provider.request({method:'wallet_addEthereumChain',params:[{chainId:'0xc4',chainName:'X Layer',nativeCurrency:{name:'OKB',symbol:'OKB',decimals:18},rpcUrls:['https://rpc.xlayer.tech'],blockExplorerUrls:['https://www.okx.com/web3/explorer/xlayer']}]}));}
  }
  await walletRead(()=>assertWallet(w.provider,account));
  persist(journal??{account,confirmed:0,hashes:[],uncertain:false});setSelected(w);setQuote(null);setNotice('钱包已连接。检查费用不会付款。');
 });}
 async function check(){await action(async()=>{
  if(!selected||!journal)return;await assertWallet(selected.provider,journal.account);
  const token=epoch.current;
  if(journal.uncertain)throw Error('上次签名结果不明，请先核对钱包并填入交易哈希。');
  if(journal.hashes.length>journal.confirmed){
   const receipt=await api({action:'receipt',account:journal.account,step:journal.confirmed,hashes:journal.hashes});
   if(token!==epoch.current)throw Error('钱包已变化，请重新连接');
   persist({...journal,confirmed:journal.confirmed+1});setEvidence(old=>[...old,receipt]);setQuote(null);setNotice('这笔收据已核对成功，可以检查下一步。');return;
  }
  const data:Quote=await api({account:journal.account,step:journal.confirmed,hashes:journal.hashes});
  if(token!==epoch.current||data.planHash!==planHash||data.account.toLowerCase()!==journal.account.toLowerCase()||data.step!==journal.confirmed)throw Error('检查结果已失效');
  setQuote(data);setNotice('费用与合约已核对；只有点击下方按钮才会请求钱包签名。');
 });}
 async function send(){await action(async()=>{
  if(!navigator.locks)throw Error('当前浏览器不支持安全的付款锁，请使用新版 Chrome 或 Edge。');
  await navigator.locks.request(JOURNAL_KEY,{ifAvailable:true},async lock=>{
  if(!lock)throw Error('另一个页面正在请求签名，请先完成那一笔。');
  if(!selected||!journal||!quote?.transaction)return;
  if(Date.now()-Date.parse(quote.checkedAt)>30000){setQuote(null);throw Error('检查已超过 30 秒，请重新检查费用');}
  await assertWallet(selected.provider,journal.account);
  if(quote.step!==journal.confirmed||journal.hashes.length!==journal.confirmed||journal.uncertain)throw Error('请先核对上一笔操作');
  const stored=parseJournal(localStorage.getItem(JOURNAL_KEY));
  if(JSON.stringify(stored)!==JSON.stringify(journal))throw Error('交易记录已更新，请刷新并核对');
  // Persist uncertain intent BEFORE handing control to a wallet; refresh cannot resend silently.
  const waiting={...journal,uncertain:true};persist(waiting);setQuote(null);
  try{
   const hash=await selected.provider.request({method:'eth_sendTransaction',params:[quote.transaction]});
   if(typeof hash!=='string'||!/^0x[0-9a-f]{64}$/i.test(hash))throw Error('钱包未返回交易哈希，请先查看钱包记录');
   const submitted={...journal,hashes:[...journal.hashes,hash],uncertain:false};setJournal(submitted);persist(submitted);setNotice('交易已提交，请点击「核对收据」。不要重复付款。');
  }catch(e){if((e as {code?:number}).code===4001){persist({...journal,uncertain:false});throw Error('你已取消签名，未继续操作。');}throw e;}
  });
 });}
 async function recoverHash(){await action(async()=>{
  if(!journal||!/^0x[0-9a-f]{64}$/i.test(recover))throw Error('请输入钱包记录里的完整交易哈希');
  const hashes=[...journal.hashes,recover];await api({action:'receipt',account:journal.account,step:journal.confirmed,hashes});
  persist({...journal,hashes,confirmed:journal.confirmed+1,uncertain:false});setRecover('');setNotice('已恢复并核对这笔交易。');
 });}
 const step=journal?.confirmed??0;
 return <div className="mx-auto max-w-4xl px-4 py-8 md:py-12">
  <Link href="/circuits" className="text-sm text-tt-deep">← 电路观察室</Link>
  <div className="tt-panel mt-5 overflow-hidden">
   <div className="bg-gradient-to-br from-[#f4e9ff] via-[#fff0f4] to-[#fff7de] p-6 md:p-10"><div className="text-xs tracking-[.18em] text-tt-deep">TINY THINGS · CIRCUIT GARDEN</div><div className="mt-5 text-5xl" aria-hidden>💌 🌱</div><h1 className="mt-4 text-3xl font-medium">让小心意，长出电路</h1><p className="mt-3 max-w-xl text-sm leading-7 text-tt-muted">把「累计 12 点」和「收集三个 6」放进 X Layer。信纸、音乐和可爱的小骰子，继续留在我们的小工作室。</p><div className="mt-5 inline-block rounded-full bg-white/80 px-4 py-2 text-xs text-tt-deep">两枚规则 · 四步完成 · 总支出上限 0.0042 OKB</div></div>
   <div className="space-y-7 p-6 md:p-10">
    <div><h2 className="text-lg font-medium">① 选一个自己的钱包</h2><p className="mt-2 text-sm leading-6 text-tt-muted">连接只获取公开地址；每笔付款都要在你自己的钱包里确认。</p>
     <div className="mt-4 flex flex-wrap gap-3">{wallets.map(w=><button key={w.id} className="tt-btn-secondary" disabled={busy||storageFault} onClick={()=>void connect(w)}>{w.name}{selected?.id===w.id?' · 已连接':''}</button>)}</div>
     {!wallets.length&&<p className="mt-4 rounded-2xl bg-tt-bg p-4 text-sm leading-7">这里还没发现钱包。请在安装了 OKX Wallet 或其他以太坊钱包扩展的浏览器中打开本页。此版本暂不支持扫码连接。</p>}
     {journal&&<p className="mt-3 break-all text-xs leading-6 text-tt-muted">流片钱包：{journal.account}<br/>网络：X Layer 主网（196） · 记录仅保存在当前浏览器</p>}
    </div>
    <div><h2 className="text-lg font-medium">② 一步一步种下规则</h2><ol className="mt-4 grid gap-3 sm:grid-cols-2">{labels.map((label,i)=><li key={label} className={`rounded-2xl border p-4 ${i<step?'border-emerald-200 bg-emerald-50':i===step?'border-pink-200 bg-pink-50':'border-tt-border bg-tt-bg'}`}><div className="text-xs text-tt-muted">{i<step?'已核对成功':`第 ${i+1} 步`}</div><div className="mt-1 text-sm font-medium">{label}</div><div className="mt-2 text-xs text-tt-muted">{i<2?'0.00066':'0.0013'} OKB ＋ 网络费用</div>{journal?.hashes[i]&&<a className="mt-2 block break-all text-[11px] text-tt-deep underline" target="_blank" rel="noreferrer" href={`https://www.okx.com/web3/explorer/xlayer/tx/${journal.hashes[i]}`}>{journal.hashes[i]}</a>}</li>)}</ol></div>
    {notice&&<p role="status" className="rounded-2xl bg-[#f0eaff] p-4 text-sm leading-6 text-tt-deep">{notice}</p>}
    {error&&<p role="alert" className="break-words rounded-2xl bg-rose-50 p-4 text-sm leading-6 text-rose-800">{error}</p>}
    {journal?.uncertain&&<div className="rounded-2xl border border-amber-200 bg-amber-50 p-4 text-sm leading-7"><p>上次签名结果还不明确，先到钱包查看是否已经发送。找到交易后，粘贴哈希恢复，避免重复付款。</p><label className="mt-3 block">已有交易哈希<input className="tt-input mt-2" value={recover} onChange={e=>setRecover(e.target.value)}/></label><button className="tt-btn-secondary mt-3" disabled={busy} onClick={()=>void recoverHash()}>核对并恢复</button></div>}
    <div className="flex flex-wrap gap-3"><button className="tt-btn-secondary" disabled={busy||!selected||!journal||journal.uncertain||step===4} onClick={()=>void check()}>{busy?'正在核对…':journal&&journal.hashes.length>step?'核对收据':'检查当前步骤与费用'}</button>{quote?.transaction&&<button className="tt-btn" disabled={busy||!selected} onClick={()=>void send()}>到钱包确认第 {step+1} 步</button>}</div>
    {quote&&<p className="rounded-2xl bg-tt-bg p-4 text-sm leading-7">钱包余额 {okb(quote.balanceWei)} OKB<br/>本轮已付＋剩余操作预算 {okb(quote.maximumTotalWei)} OKB<br/><span className="text-tt-muted">检查 30 秒内有效；钱包签名时核对目标和金额。</span></p>}
    {step===4&&<div className="rounded-2xl bg-emerald-50 p-5 text-sm leading-7 text-emerald-900">四笔收据已核对。情书流片收据和网表哈希已验证，正式 step 比对与作品绑定仍需完成。<button className="tt-btn-secondary mt-3" onClick={()=>{const url=URL.createObjectURL(new Blob([JSON.stringify({journal,evidence,planHash},null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download='tiny-things-launch-receipts.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}}>导出流片记录</button></div>}
    <details className="text-xs leading-6 text-tt-muted"><summary className="cursor-pointer">查看本次电路与目标</summary><p className="mt-3 break-all">共享处理器 #414：0x9e2849c04A513FE64db07521cBE52d078d905c0E<br/>批准清单 SHA256：{planHash}<br/>协议付款共 0.00392 OKB，剩余预算用于网络费用。不包含红包、代币兑换或网站发布。</p></details>
   </div>
  </div>
 </div>;
}
