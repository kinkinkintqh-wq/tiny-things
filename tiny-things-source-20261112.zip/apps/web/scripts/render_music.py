"""Three original, locally synthesized background loops; no samples or third-party recordings.
Run with Python's standard library. Tails wrap around the loop for click-free repeats.
"""
from pathlib import Path
import math, wave, array, json
RATE=22050
ROOT=Path(__file__).resolve().parents[1]/'public/audio'
SCORES={
 'musicbox': {'name':'云朵八音盒','bpm':88,'kind':'bell','melody':[72,76,79,83,81,79,76,None,74,77,81,84,83,79,77,None,76,79,84,88,86,84,79,76,74,77,81,79,76,74,72,None],'chords':[[48,55,60,64],[53,60,65,69],[57,64,69,72],[55,62,67,71]]},
 'picnic': {'name':'草莓汽水','bpm':112,'kind':'pluck','melody':[67,None,72,74,76,None,79,76,74,72,None,69,72,74,76,None,79,76,74,72,69,None,67,69,72,76,74,None,72,None,67,None],'chords':[[48,55,60,64],[57,64,69,72],[53,60,65,69],[55,62,67,71]]},
 'moon': {'name':'月亮晚安','bpm':72,'kind':'soft','melody':[76,None,79,None,83,81,79,None,74,None,77,None,81,79,77,None,72,None,76,79,84,None,83,79,77,None,74,None,76,None,72,None],'chords':[[48,55,60,64],[50,57,62,65],[53,60,65,69],[55,62,67,71]]},
}
def render(key,score):
 step=60/score['bpm']/2
 length=64*step
 n=round(length*RATE)
 buf=[0.0]*n
 def note(midi,at,duration,gain,kind):
  f=440*2**((midi-69)/12)
  count=round(duration*RATE)
  for j in range(count):
   t=j/RATE
   attack=min(1,t/.012)
   end=min(1,max(0,(duration-t)/.08))
   if kind=='pad':
    env=math.sin(math.pi*t/duration)**2
    y=(math.sin(2*math.pi*f*t)+.18*math.sin(2*math.pi*f*2*t))*.6
   else:
    decay=math.exp(-t*(3.3 if kind=='pluck' else 2.1))
    env=attack*end*decay
    y=math.sin(2*math.pi*f*t)+(.22 if kind=='bell' else .1)*math.sin(2*math.pi*f*2.003*t)*math.exp(-t*4)
   buf[(round(at*RATE)+j)%n]+=gain*env*y
 for bar in range(8):
  chord=score['chords'][bar%4]
  for m in chord:note(m,bar*8*step,8*step,.028,'pad')
  note(chord[0]-12,bar*8*step,5*step,.045,'soft')
  for off in [0,2,4,6]:note(chord[1+(off//2)%3]+12,(bar*8+off)*step,1.7,.035,'bell')
 for i in range(64):
  m=score['melody'][i%32]
  if m is not None: note(m,i*step,2 if score['kind']!='pluck' else .9,.12,score['kind'])
 peak=max(abs(v) for v in buf)
 scale=.55/max(peak,.55)
 samples=array.array('h',(round(max(-1,min(1,v*scale))*32767) for v in buf))
 ROOT.mkdir(exist_ok=True)
 with wave.open(str(ROOT/f'{key}.wav'),'wb') as out:
  out.setparams((1,2,RATE,n,'NONE','not compressed'));out.writeframes(samples.tobytes())
 return {'id':key,'name':score['name'],'bpm':score['bpm'],'seconds':round(length,3),'sampleRate':RATE,'peak':round(peak*scale,4),'rms':round(math.sqrt(sum((v*scale)**2 for v in buf)/n),4),'origin':'Original synthesized score; no external samples'}
if __name__=='__main__':
 meta=[render(k,v) for k,v in SCORES.items()]
 (ROOT/'credits.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps(meta,ensure_ascii=False))
