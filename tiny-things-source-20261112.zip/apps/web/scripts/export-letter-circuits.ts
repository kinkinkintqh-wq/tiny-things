/** Candidate export only. Never signs or broadcasts transactions. */
import { mkdirSync, writeFileSync } from "node:fs";
import { createHash } from "node:crypto";
import { compileLetterRule, stepLetterRule, type LetterRule } from "../packages/compiler/src/letter";
import { encodeSequential, decodeSequential } from "../packages/compiler/src/sequential";
const dir = new URL("../../../verification/letter-circuits/", import.meta.url);
mkdirSync(dir, { recursive: true });
for (const rule of [{ rule: "sum", target: 12, face: 6 }, { rule: "matches", target: 3, face: 6 }] satisfies LetterRule[]) {
  const circuit = compileLetterRule(rule);
  const bytes = encodeSequential(circuit);
  const decoded = decodeSequential(bytes, circuit.nIn, circuit.nOut);
  const vectors = [];
  let progress = 0, unlocked = false;
  for (const face of [1, 6, 2, 6, 6, 3]) {
    const next = stepLetterRule(decoded, progress, unlocked, true, face);
    vectors.push({ before: { progress, unlocked }, face, after: next });
    ({ progress, unlocked } = next);
  }
  const artifact = { format: "tiny-letter-circuit/1", status: "local-verified-not-deployed", rule,
    nIn: circuit.nIn, nOut: circuit.nOut, nState: 8,
    nandCount: circuit.elements.filter(e => e.op === "nand").length, byteLength: bytes.length,
    encodedHex: "0x" + Buffer.from(bytes).toString("hex"), sha256: createHash("sha256").update(bytes).digest("hex"),
    pins: { inputs: ["signal", "face0", "face1", "face2", "unlock"], state: "progress[0..6], unlocked; LSB-first", outputs: "next progress[0..6], next unlocked; LSB-first" },
    note: "Candidate NAND/LATCH bytecode; not accepted by a current TapeOut contract yet. Browser supplies random dice and state. Letter content is excluded.", vectors };
  writeFileSync(new URL(`${rule.rule}.json`, dir), JSON.stringify(artifact, null, 2) + "\n");
  console.log(JSON.stringify({ rule: rule.rule, bytes: artifact.byteLength, nand: artifact.nandCount, latch: 8, sha256: artifact.sha256 }));
}
