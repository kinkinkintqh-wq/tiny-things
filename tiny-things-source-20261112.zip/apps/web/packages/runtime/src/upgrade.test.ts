import { describe, expect, it } from "vitest";
import { draftFromTemplate, getBlock } from "@tinythings/block-registry";
import { RuntimeSession } from "./session";
import { SCHEMA_VERSION, type DesignGraph } from "@tinythings/schema";
import { compileGraph, stepCounterNetlist } from "@tinythings/compiler";
import { encodeDesign, decodeDesign } from "../../../src/lib/portable";
const node = (id: string, type: string, config: Record<string, unknown> = {}) => ({ id, type, version: "1.0.0", config, position: { x: 0, y: 0 } });
const edge = (id: string, source: string, sourcePort: string, target: string, targetPort: string, kind: "event" | "data" = "event") => ({ id, source, sourcePort, target, targetPort, kind });
const graph = (nodes: DesignGraph['nodes'], edges: DesignGraph['edges'] = []): DesignGraph => ({ schemaVersion: SCHEMA_VERSION, stateScope: "perUser", nodes, edges });
describe("live clock and transactional runtime", () => {
  it("counts down and emits done exactly once", () => {
    const rt = new RuntimeSession(graph([node("timer", "timer", { durationSec: 2 }), node("count", "counter")], [edge("done", "timer", "done", "count", "increment")]), { now: 0 });
    rt.tick({ eventId: "start", nodeId: "timer", port: "start" });
    expect(rt.updateTime(1000).states.timer.remaining).toBe(1);
    expect(rt.updateTime(2000).states.count.value).toBe(1);
    expect(rt.updateTime(3000).states.count.value).toBe(1);
  });
  it("unlocks a timed envelope without a click", () => {
    const rt = new RuntimeSession(graph([node("env", "envelope", { unlockMode: "time", unlockAt: 1000 })]), { now: 0 });
    expect(rt.updateTime(999).states.env.unlocked).toBe(false);
    expect(rt.updateTime(1000).states.env.unlocked).toBe(true);
  });
  it("rolls back the entire event cascade on budget failure", () => {
    const rt = new RuntimeSession(graph([node("btn", "button"), node("a", "condition"), node("b", "condition"), node("0count", "counter")], [edge("1", "btn", "click", "a", "trigger"), edge("2", "a", "then", "b", "trigger"), edge("3", "b", "then", "a", "trigger"), edge("4", "a", "then", "0count", "increment")]), { now: 0, maxNodeOps: 10 });
    const before = rt.getSnapshot();
    const failed = rt.tick({ eventId: "cycle", nodeId: "btn", port: "press" });
    expect(failed.errors.length).toBeGreaterThan(0);
    expect(failed.states).toEqual(before.states);
    expect(failed.revision).toBe(before.revision);
  });
  it("merges partial persisted state with defaults", () => {
    const rt = new RuntimeSession(draftFromTemplate("habit-builder").graph);
    rt.loadState({ cnt: { value: 12 } });
    expect(rt.getSnapshot().states.bar.value).toBe(12);
    expect(rt.getSnapshot().states.btn).toBeDefined();
  });
});
describe("faithful NAND", () => {
  it("matches all uint8 states for four steps and nonzero reset", () => {
    for (const step of [1, 2, 7, 255]) {
      const net = compileGraph(graph([node("btn", "button"), node("cnt", "counter", { bits: 8, step, initial: 9 })], [edge("inc", "btn", "click", "cnt", "increment")])).netlist!;
      for (let state = 0; state < 256; state++) {
        expect(stepCounterNetlist(net, state, true, false)).toBe(Math.min(255, state + step));
        expect(stepCounterNetlist(net, state, true, true)).toBe(9);
        expect(stepCounterNetlist(net, state, false, false)).toBe(state);
      }
    }
  });
  it("honors default width and rejects unsupported semantics", () => {
    const g = graph([node("btn", "button"), node("cnt", "counter", { ...getBlock("counter")!.defaultConfig })], [edge("inc", "btn", "click", "cnt", "increment")]);
    const net = compileGraph(g).netlist!;
    expect(net.nState).toBe(16);
    expect(stepCounterNetlist(net, 65535, true, false)).toBe(65535);
    g.nodes[1].config.overflow = "error";
    expect(compileGraph(g).netlist).toBeNull();
    g.nodes[1].config.overflow = "saturate";
    g.edges[0].targetPort = "decrement";
    expect(compileGraph(g).netlist).toBeNull();
    g.nodes.push(node("unknown", "notSupported"));
    expect(compileGraph(g).netlist).toBeNull();
  });
});
describe("portable works", () => {
  it("roundtrips Chinese, emoji and all built-in designs", () => {
    for (const id of ["daily-checkin", "habit-builder", "dice-letter", "future-letter", "countdown"]) {
      const draft = { ...draftFromTemplate(id), name: "测试作品 🧩" };
      expect(decodeDesign(encodeDesign(draft))).toEqual(draft);
    }
  });
  it("rejects malformed, oversized and invalid graphs", () => {
    expect(() => decodeDesign("invalid!")).toThrow();
    expect(() => decodeDesign("a".repeat(700000))).toThrow();
    const draft = draftFromTemplate("habit-builder"); draft.graph.edges[0].target = "missing";
    expect(() => encodeDesign(draft)).toThrow();
  });
});
