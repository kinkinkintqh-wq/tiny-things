import { compileLetterRule, stepLetterRule, supportedLetterRule, type SequentialCircuit } from "@tinythings/compiler";
import { getBlock, validateGraph } from "@tinythings/block-registry";
import type { DesignGraph } from "@tinythings/schema";
import { createSeededRandom, dayIndexInTimeZone } from './clock';

export interface RuntimeOptions {
  timezone?: string;
  seed?: number;
  now?: number;
  maxNodeOps?: number;
  /** Reference mode is for equivalence verification; normal play uses local NAND/LATCH. */
  letterCircuit?: boolean;
}

export interface TickEvent {
  eventId: string;
  nodeId: string;
  port: string;
  payload?: unknown;
}

export interface RuntimeSnapshot {
  states: Record<string, Record<string, unknown>>;
  outputs: Record<string, Record<string, unknown>>;
  revision: number;
  trace: Array<{ nodeId: string; port: string; eventId: string }>;
  errors: string[];
}

export interface LetterTransition {
  rule: 'sum'|'matches'; target:number; face:number;
  state:number; input:number; expected:number;
}

export class RuntimeSession {
  readonly graph: DesignGraph;
  readonly timezone: string;
  private clockMs: number;
  private letterCircuits = new Map<string, SequentialCircuit>();
  private random: ReturnType<typeof createSeededRandom>;
  private states: Record<string, Record<string, unknown>> = {};
  private outputs: Record<string, Record<string, unknown>> = {};
  private revision = 0;
  private seenEvents = new Set<string>();
  private maxNodeOps: number;
  private trace: RuntimeSnapshot["trace"] = [];
  private letterTransitions:LetterTransition[]=[];
  private verifying=false;

  /** Execute speculatively; publish state and RNG only after the external rule check succeeds. */
  async tickVerified(event:TickEvent,verify:(steps:LetterTransition[])=>Promise<void>):Promise<RuntimeSnapshot>{
    if(this.verifying)return {...this.getSnapshot(),errors:['正在核对上一步，请稍候']};
    this.verifying=true;
    try{
      const trial=new RuntimeSession(this.graph,{timezone:this.timezone,now:this.clockMs,maxNodeOps:this.maxNodeOps});
      trial.states=structuredClone(this.states);trial.outputs=structuredClone(this.outputs);
      trial.revision=this.revision;trial.seenEvents=new Set(this.seenEvents);trial.random.setState(this.random.getState());
      const snap=trial.tick(event);if(snap.errors.length)return snap;
      if(trial.letterTransitions.length)await verify(trial.letterTransitions);
      this.states=trial.states;this.outputs=trial.outputs;this.revision=trial.revision;
      this.seenEvents=trial.seenEvents;this.random.setState(trial.random.getState());this.trace=trial.trace;
      return this.getSnapshot();
    }catch(e){return {...this.getSnapshot(),errors:[e instanceof Error?e.message:'电路核对失败，已保留上一步状态']};}
    finally{this.verifying=false;}
  }

  constructor(graph: DesignGraph, opts: RuntimeOptions = {}) {
    const issues = validateGraph(graph);
    if (issues.length) {
      throw new Error(`Invalid graph: ${issues.map((i) => i.message).join("; ")}`);
    }
    this.graph = structuredClone(graph);
    this.timezone = opts.timezone ?? "Asia/Shanghai";
    this.clockMs = opts.now ?? Date.now();
    this.random = createSeededRandom(opts.seed ?? 0xc0ffee);
    this.maxNodeOps = opts.maxNodeOps ?? 1000;
    if (opts.letterCircuit !== false) for (const node of this.graph.nodes) {
      const rule = node.type === "envelope" ? supportedLetterRule(node.config) : null;
      if (rule) this.letterCircuits.set(node.id, compileLetterRule(rule));
    }
    this.resetStates();
    this.outputs = this.computeDataOutputs();
  }

  private resetStates() {
    this.states = {};
    this.outputs = {};
    for (const node of this.graph.nodes) {
      const def = getBlock(node.type);
      if (!def) continue;
      this.states[node.id] = {
        ...structuredClone(def.defaultState),
        ...(node.type === "counter"
          ? { value: Number(node.config.initial ?? 0) }
          : {}),
        ...(node.type === "switch"
          ? { on: Boolean(node.config.initial ?? false) }
          : {}),
        ...(node.type === "randomBox"
          ? {
              remaining: [
                ...((node.config.mode === "dice"
                  ? ["1", "2", "3", "4", "5", "6"]
                  : (node.config.items as string[] | undefined)) ?? []),
              ],
              last: null,
              value: 0,
            }
          : {}),
        ...(node.type === "envelope"
          ? {
              opened: false,
              unlocked: String(node.config.unlockMode ?? "event") === "time"
                ? false
                : false,
              locked: true,
              signalCount: 0,
            }
          : {}),
      };
      this.outputs[node.id] = {};
    }
  }

  setClock(ms: number) {
    this.clockMs = ms;
  }

  advanceClock(ms: number) {
    this.clockMs += ms;
  }

  /** One atomic clock pulse; timers emit through the same queue as user events. */
  updateTime(ms: number): RuntimeSnapshot {
    if(this.verifying)return this.getSnapshot();
    this.setClock(ms);
    const events = this.graph.nodes
      .filter((n) => n.type === "timer" || (n.type === "envelope" && n.config.unlockMode === "time"))
      .map((n) => ({ eventId: `clock:${ms}:${n.id}`, nodeId: n.id, port: "__clock" }));
    return events.length ? this.process(events) : this.getSnapshot();
  }

  getSnapshot(): RuntimeSnapshot {
    return {
      states: structuredClone(this.states),
      outputs: structuredClone(this.outputs),
      revision: this.revision,
      trace: [...this.trace],
      errors: [],
    };
  }

  loadState(states: Record<string, Record<string, unknown>>, revision = 0) {
    if(this.verifying)throw Error('正在核对电路，暂不能替换状态');
    for (const node of this.graph.nodes) {
      if (states[node.id]) this.states[node.id] = { ...this.states[node.id], ...structuredClone(states[node.id]) };
    }
    this.revision = revision;
    this.outputs = this.computeDataOutputs();
  }

  /** Apply one external event as a single tick with deterministic fan-out. */
  tick(event: TickEvent): RuntimeSnapshot {
    if(this.verifying)return {...this.getSnapshot(),errors:['正在核对上一步，请稍候']};
    if (this.seenEvents.has(event.eventId)) {
      return this.getSnapshot();
    }
    const result = this.process([event]);
    if (!result.errors.length) {
      this.seenEvents.add(event.eventId);
      if (this.seenEvents.size > 2048) this.seenEvents.delete(this.seenEvents.values().next().value!);
    }
    return result;
  }

  private process(events: TickEvent[]): RuntimeSnapshot {
    if(this.verifying)return this.getSnapshot();
    this.letterTransitions=[];
    const previous = structuredClone(this.states);
    const previousOutputs = structuredClone(this.outputs);
    const previousRandom = this.random.getState();
    this.trace = [];
    const errors: string[] = [];

    type QItem = {
      nodeId: string;
      port: string;
      payload?: unknown;
      eventId: string;
    };
    const queue: QItem[] = events.map((event) => ({ ...event }));

    let ops = 0;
    while (queue.length) {
      if (ops++ >= this.maxNodeOps) {
        errors.push("本 tick 节点处理超限，已保留上一有效状态");
        break;
      }
      queue.sort((a, b) =>
        a.nodeId === b.nodeId
          ? a.port.localeCompare(b.port)
          : a.nodeId.localeCompare(b.nodeId)
      );
      const item = queue.shift()!;
      const node = this.graph.nodes.find((n) => n.id === item.nodeId);
      if (!node) continue;
      const def = getBlock(node.type);
      if (!def) continue;

      // Downstream event handlers observe upstream changes from this tick.
      const dataSnapshot = this.computeDataOutputs();

      const inputs: Record<string, unknown> = {};
      for (const edge of this.graph.edges) {
        if (edge.target !== node.id || edge.kind === "event") continue;
        const srcOut = dataSnapshot[edge.source]?.[edge.sourcePort];
        inputs[edge.targetPort] = srcOut;
      }

      const context = {
        clock: () => this.clockMs,
        random: this.random,
        timezone: this.timezone,
        dayIndex: (ts: number) => dayIndexInTimeZone(ts, this.timezone),
      };

      try {
        const result = def.reduce(
          this.states[node.id] ?? {},
          { port: item.port, payload: item.payload },
          node.config,
          context,
          inputs
        );
        const circuit = this.letterCircuits.get(node.id);
        if (circuit && (item.port === "signal" || item.port === "unlock")) {
          const previous = this.states[node.id] ?? {};
          const payload = item.payload == null ? "" : String(item.payload);
          const rule = supportedLetterRule(node.config)!;
          const value = Number(payload);
          const face = rule.rule === "matches"
            ? (payload === String(rule.face) ? rule.face : 0)
            : (Number.isInteger(value) && value >= 1 && value <= 6 ? value : 0);
          const next = stepLetterRule(circuit, Number(previous.signalCount ?? 0), Boolean(previous.unlocked), item.port === "signal", face, item.port === "unlock");
          if (next.progress !== result.nextState.signalCount || next.unlocked !== result.nextState.unlocked) throw new Error("情书电路与参考规则不一致，已暂停本次操作");
          this.letterTransitions.push({rule:rule.rule,target:rule.target,face:rule.face,state:Number(previous.signalCount??0)|(Boolean(previous.unlocked)?128:0),input:(item.port==='signal'?1:0)|(face<<1)|(item.port==='unlock'?16:0),expected:next.progress|(next.unlocked?128:0)});
          result.nextState.signalCount = next.progress;
          result.nextState.unlocked = next.unlocked;
          result.nextState.locked = !next.unlocked;
        }
        this.states[node.id] = result.nextState;
        this.trace.push({
          nodeId: node.id,
          port: item.port,
          eventId: item.eventId,
        });

        // Fan-out emitted events along event edges, stable by edgeId
        const eventEdges = this.graph.edges
          .filter((e) => e.source === node.id && e.kind === "event")
          .sort((a, b) => a.id.localeCompare(b.id));
        for (const emitted of result.emittedEvents) {
          for (const edge of eventEdges) {
            if (edge.sourcePort !== emitted.port) continue;
            queue.push({
              nodeId: edge.target,
              port: edge.targetPort,
              payload: emitted.payload,
              eventId: `${item.eventId}:${edge.id}`,
            });
          }
        }
      } catch (err) {
        errors.push(
          `${node.id}: ${err instanceof Error ? err.message : String(err)}`
        );
        break;
      }
    }

    if (errors.length) {
      this.states = previous;
      this.outputs = previousOutputs;
      this.random.setState(previousRandom);
      const failed = this.getSnapshot();
      failed.errors = errors;
      return failed;
    }
    this.outputs = this.computeDataOutputs();
    if (JSON.stringify(previous) !== JSON.stringify(this.states)) this.revision += 1;
    const snap = this.getSnapshot();
    snap.errors = errors;
    return snap;
  }

  private computeDataOutputs(): Record<string, Record<string, unknown>> {
    const out: Record<string, Record<string, unknown>> = {};
    // Topo-ish: multiple passes for data edges
    for (let pass = 0; pass < this.graph.nodes.length + 1; pass++) {
      for (const node of [...this.graph.nodes].sort((a, b) =>
        a.id.localeCompare(b.id)
      )) {
        const def = getBlock(node.type);
        if (!def) continue;
        const inputs: Record<string, unknown> = {};
        for (const edge of this.graph.edges) {
          if (edge.target !== node.id || edge.kind === "event") continue;
          inputs[edge.targetPort] = out[edge.source]?.[edge.sourcePort];
        }
        const state = this.states[node.id] ?? {};
        const local: Record<string, unknown> = { ...state };
        // Map common fields onto output ports
        for (const p of def.outputPorts) {
          if (p.kind !== "data") continue;
          if (p.id in state) local[p.id] = state[p.id];
          else if (p.id === "value" && "value" in state) local.value = state.value;
          else if (p.id === "value" && "on" in state) local.value = state.on;
          else if (p.id === "content" && "content" in state)
            local.content = state.content;
          else if (p.id === "text" && "last" in state) local.text = state.last;
          else if (p.id === "streak") local.streak = state.streak ?? 0;
          else if (p.id === "total") local.total = state.total ?? 0;
          else if (p.id === "ratio") local.ratio = state.ratio ?? 0;
          else if (p.id === "done") local.done = state.done ?? false;
          else if (p.id === "remaining") local.remaining = state.remaining ?? 0;
          else if (p.id === "locked") local.locked = state.locked ?? true;
          else if (p.id === "body") local.body = state.body ?? "";
          else if (p.id === "items")
            local.items = JSON.stringify(state.items ?? node.config.items ?? []);
          else if (p.id === "hash") local.hash = node.config.manifestHash ?? "";
          else if (p.id === "result") local.result = state.result ?? false;
        }
        // Re-run host reduce with null event for pure data blocks like progress
        if (node.type === "progress" || node.type === "condition" || node.type === "text") {
          const context = {
            clock: () => this.clockMs,
            random: this.random,
            timezone: this.timezone,
            dayIndex: (ts: number) => dayIndexInTimeZone(ts, this.timezone),
          };
          const result = def.reduce(state, null, node.config, context, inputs);
          this.states[node.id] = { ...state, ...result.nextState };
          for (const p of def.outputPorts) {
            if (p.kind === "data" && p.id in result.nextState) {
              local[p.id] = result.nextState[p.id];
            }
          }
        }
        out[node.id] = local;
      }
    }
    return out;
  }
}
