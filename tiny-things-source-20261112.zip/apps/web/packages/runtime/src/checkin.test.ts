import { draftFromTemplate } from "@tinythings/block-registry";
import { describe, expect, it } from "vitest";
import { dayIndexInTimeZone } from './clock';
import { RuntimeSession } from './session';

describe("dayIndexInTimeZone", () => {
  it("keeps same civil day across UTC midnight for Asia/Shanghai", () => {
    // 2026-11-07 00:30 CST = 2026-11-06 16:30 UTC
    const a = Date.parse("2026-11-06T16:30:00.000Z");
    const b = Date.parse("2026-11-06T20:00:00.000Z");
    expect(dayIndexInTimeZone(a, "Asia/Shanghai")).toBe(
      dayIndexInTimeZone(b, "Asia/Shanghai")
    );
  });

  it("advances on Asia/Shanghai midnight", () => {
    const before = Date.parse("2026-11-06T15:59:00.000Z"); // 23:59 CST
    const after = Date.parse("2026-11-06T16:01:00.000Z"); // 00:01 CST next day
    expect(dayIndexInTimeZone(after, "Asia/Shanghai")).toBe(
      dayIndexInTimeZone(before, "Asia/Shanghai") + 1
    );
  });
});

describe("daily check-in template", () => {
  it("rejects same-day double check-in and grows streak across days", () => {
    const draft = draftFromTemplate("daily-checkin");
    const session = new RuntimeSession(draft.graph, {
      timezone: "Asia/Shanghai",
      now: Date.parse("2026-11-07T02:00:00.000Z"),
      seed: 1,
    });

    const first = session.tick({
      eventId: "e1",
      nodeId: "btn",
      port: "press",
    });
    expect(first.states.streak?.streak).toBe(1);

    const second = session.tick({
      eventId: "e2",
      nodeId: "btn",
      port: "press",
    });
    expect(second.states.streak?.streak).toBe(1);
    expect(second.states.streak?.total).toBe(1);

    session.setClock(Date.parse("2026-11-08T02:00:00.000Z"));
    const third = session.tick({
      eventId: "e3",
      nodeId: "btn",
      port: "press",
    });
    expect(third.states.streak?.streak).toBe(2);
    expect(third.states.streak?.total).toBe(2);

    // break streak
    session.setClock(Date.parse("2026-11-10T02:00:00.000Z"));
    const fourth = session.tick({
      eventId: "e4",
      nodeId: "btn",
      port: "press",
    });
    expect(fourth.states.streak?.streak).toBe(1);
    expect(fourth.states.streak?.total).toBe(3);
  });

  it("dedupes eventId", () => {
    const draft = draftFromTemplate("habit-builder");
    const session = new RuntimeSession(draft.graph, { seed: 2 });
    session.tick({ eventId: "same", nodeId: "btn", port: "press" });
    session.tick({ eventId: "same", nodeId: "btn", port: "press" });
    expect(session.getSnapshot().states.cnt?.value).toBe(1);
  });
});
