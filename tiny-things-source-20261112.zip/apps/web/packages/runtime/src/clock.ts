/** Day index in a fixed IANA timezone without relying on ms/86400000 alone. */
export function dayIndexInTimeZone(ts: number, timeZone: string): number {
  const fmt = new Intl.DateTimeFormat("en-CA", {
    timeZone,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  });
  const parts = fmt.formatToParts(new Date(ts));
  const y = Number(parts.find((p) => p.type === "year")?.value);
  const m = Number(parts.find((p) => p.type === "month")?.value);
  const d = Number(parts.find((p) => p.type === "day")?.value);
  // Civil day number from a proleptic Gregorian epoch (UTC noon of that Y-M-D)
  const utc = Date.UTC(y, m - 1, d, 12, 0, 0);
  return Math.floor(utc / 86_400_000);
}

export function createSeededRandom(seed: number) {
  let s = seed >>> 0 || 1;
  const next = () => {
    // xorshift32
    s ^= s << 13;
    s ^= s >>> 17;
    s ^= s << 5;
    return (s >>> 0) / 0x100000000;
  };
  return Object.assign(next, { getState: () => s, setState: (value: number) => { s = value; } });
}
