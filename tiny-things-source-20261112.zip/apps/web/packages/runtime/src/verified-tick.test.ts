import {describe,it,expect} from 'vitest';
import {draftFromTemplate} from '@tinythings/block-registry';
import {RuntimeSession} from './session';
describe('speculative letter runtime (synthetic verifier, no chain claims)',()=>{
 it('does not publish dice, progress or RNG when verification fails, and allows the same event to retry',async()=>{
  const graph=draftFromTemplate('love-letter').graph;
  const rt=new RuntimeSession(graph,{seed:73,now:100});
  const control=new RuntimeSession(graph,{seed:73,now:100});
  const button=graph.nodes.find(n=>n.type==='button')!;
  const event={eventId:'one',nodeId:button.id,port:'click'};
  const before=rt.getSnapshot();
  const failed=await rt.tickVerified(event,async steps=>{expect(steps).toHaveLength(1);throw Error('synthetic RPC unavailable');});
  expect(failed.errors).toContain('synthetic RPC unavailable');expect(rt.getSnapshot()).toEqual(before);
  const retried=await rt.tickVerified(event,async()=>{});
  expect(retried).toEqual(control.tick(event));
 });
 it('blocks overlapping ticks while verification is pending',async()=>{
  const graph=draftFromTemplate('love-letter').graph;const rt=new RuntimeSession(graph);
  const button=graph.nodes.find(n=>n.type==='button')!;let finish!:()=>void;
  const waiting=new Promise<void>(r=>{finish=r;});
  const pending=rt.tickVerified({eventId:'a',nodeId:button.id,port:'click'},()=>waiting);
  const before=rt.getSnapshot();
  expect(rt.tick({eventId:'b',nodeId:button.id,port:'click'}).errors).toHaveLength(1);
  rt.updateTime(200);expect(rt.getSnapshot()).toEqual(before);
  finish();expect((await pending).errors).toEqual([]);
 });
});
