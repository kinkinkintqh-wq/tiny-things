import { afterEach, describe, expect, it, vi } from "vitest";
import { FACTORY, readCircuit, SELECTOR } from "../../../src/lib/circuit-reader";
// Synthetic RPC responses; never written to real chain evidence.
const processor = "0x839bdd6fa7a66416a609a735e11de5411b98574e";
const word = (n: number) => n.toString(16).padStart(64, "0");
const dynamic = (hex: string) => `0x${word(32)}${word(hex.length / 2)}${hex.padEnd(Math.ceil(hex.length / 64) * 64, "0")}`;
const netlist = "00000002000003000000020000040000000300000400000005000006";
function mockRpc({ wrongChain = false, mismatch = false } = {}) {
  const blocks: string[] = [];
  vi.stubGlobal("fetch", vi.fn(async (_url, init) => {
    const { method, params } = JSON.parse(init.body);
    let result: unknown;
    if (method === "eth_chainId") result = wrongChain ? "0x1" : "0xc4";
    else if (method === "eth_getBlockByNumber") result = { number: "0x10", hash: "0xsynthetic" };
    else if (method === "eth_call") {
      blocks.push(params[1]);
      const data: string = params[0].data;
      switch (data.slice(0, 10)) {
        case SELECTOR.cpus: result = "0x" + processor.slice(2).padStart(64, "0"); break;
        case SELECTOR.isCPU: result = "0x" + word(1); break;
        case SELECTOR.factory: result = "0x" + FACTORY.slice(2).padStart(64, "0"); break;
        case SELECTOR.info: result = "0x" + [2, 1, 0, 4].map(word).join(""); break;
        case SELECTOR.fee: result = "0x" + word(0); break;
        case SELECTOR.netlist: result = dynamic(netlist); break;
        case SELECTOR.eval: { const byte = parseInt(data.slice(202, 204), 16); result = dynamic(mismatch ? "01" : (byte === 1 || byte === 2) ? "01" : "00"); break; }
        default: throw new Error("Unexpected synthetic call");
      }
    } else throw new Error("Unexpected synthetic method");
    return new Response(JSON.stringify({ jsonrpc: "2.0", id: 1, result }), { headers: { "content-type": "application/json" } });
  }));
  return blocks;
}
afterEach(() => vi.unstubAllGlobals());
describe("circuit inspection fail-closed boundary (synthetic RPC)", () => {
  it("pins every contract call to one block and compares every input", async () => {
    const blocks = mockRpc();
    const result = await readCircuit("", "1");
    expect(result.verified).toBe(true);
    expect(result.vectors).toHaveLength(4);
    expect(new Set(blocks)).toEqual(new Set(["0x10"]));
  });
  it("never labels mismatched chain output verified", async () => {
    mockRpc({ mismatch: true });
    expect((await readCircuit("", "1")).verified).toBe(false);
  });
  it("rejects a wrong chain and malformed requests", async () => {
    mockRpc({ wrongChain: true });
    await expect(readCircuit("", "1")).rejects.toThrow("网络不符");
    await expect(readCircuit("bad-address", "1")).rejects.toThrow("地址");
    await expect(readCircuit("", "0")).rejects.toThrow("正整数");
  });
});
