import { describe, expect, it } from "vitest";
import { draftFromTemplate } from "@tinythings/block-registry";
import { RuntimeSession } from "./session";

describe("dice-letter template", () => {
  it("needs three sixes before envelope opens", () => {
    const graph = draftFromTemplate("dice-letter").graph;
    // Force rolls: monkey by using many seeds until we get behavior path via payload injection
    const session = new RuntimeSession(graph, { seed: 1, timezone: "Asia/Shanghai" });

    // Directly signal three matching payloads without relying on RNG
    session.tick({ eventId: "s1", nodeId: "env", port: "signal", payload: "6" });
    session.tick({ eventId: "s2", nodeId: "env", port: "signal", payload: "6" });
    let snap = session.tick({
      eventId: "s3",
      nodeId: "env",
      port: "signal",
      payload: "6",
    });
    expect(snap.states.env?.unlocked).toBe(true);
    expect(snap.states.env?.signalCount).toBe(3);

    snap = session.tick({ eventId: "open1", nodeId: "env", port: "open" });
    expect(snap.states.env?.opened).toBe(true);
    expect(String(snap.states.env?.body ?? "")).toContain("三颗六点");
  });

  it("ignores non-matching signals", () => {
    const graph = draftFromTemplate("dice-letter").graph;
    const session = new RuntimeSession(graph, { seed: 2 });
    session.tick({ eventId: "a", nodeId: "env", port: "signal", payload: "1" });
    session.tick({ eventId: "b", nodeId: "env", port: "signal", payload: "2" });
    const snap = session.tick({
      eventId: "c",
      nodeId: "env",
      port: "signal",
      payload: "3",
    });
    expect(snap.states.env?.signalCount).toBe(0);
    expect(snap.states.env?.unlocked).toBe(false);
  });
});
