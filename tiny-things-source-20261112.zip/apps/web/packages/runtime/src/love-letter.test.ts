import { describe, expect, it } from "vitest";
import { createDraft } from "@tinythings/schema";
import { draftFromTemplate } from "@tinythings/block-registry";
import { RuntimeSession } from "./session";
import { configureLoveLetter, DEFAULT_LOVE_LETTER } from "../../../src/lib/love-letter";
import { encodeDesign, decodeDesign } from "../../../src/lib/portable";

describe("letter surprise flow", () => {
  it("only reveals the letter after enough dice points and a separate open event", () => {
    const rt = new RuntimeSession(draftFromTemplate("love-letter").graph);
    expect(rt.getSnapshot().states.env.body).toBeUndefined();
    let snap = rt.tick({eventId:"early", nodeId:"read", port:"press"});
    expect(snap.states.env.opened).toBe(false);
    expect(snap.states.env.body).toBe("");
    for (const [i,points] of [4,6,2].entries()) snap = rt.tick({eventId:`roll${i}`,nodeId:"env",port:"signal",payload:String(points)});
    expect(snap.states.env.unlocked).toBe(true);
    expect(snap.states.env.signalCount).toBe(12);
    expect(snap.states.env.opened).toBe(false);
    expect(snap.states.env.body).toBe("");
    snap = rt.tick({eventId:"read",nodeId:"read",port:"press"});
    expect(snap.states.env.opened).toBe(true);
    expect(snap.states.env.body).toContain("小概率事件");
  });
  it("ignores invalid dice values and stops progress at the target", () => {
    const rt = new RuntimeSession(draftFromTemplate("love-letter").graph);
    for (const [i,payload] of ["bad","0","-2","7","1.5"].entries()) rt.tick({eventId:`bad${i}`,nodeId:"env",port:"signal",payload});
    expect(rt.getSnapshot().states.env.signalCount).toBe(0);
    for (let i=0;i<5;i++) rt.tick({eventId:`ok${i}`,nodeId:"env",port:"signal",payload:"6"});
    expect(rt.getSnapshot().states.env.signalCount).toBe(12);
  });
  it("uses exact-match rules independently of sum mode", () => {
    const draft=configureLoveLetter(createDraft(),{...DEFAULT_LOVE_LETTER,rule:"matches",target:2,match:"5"});
    const rt=new RuntimeSession(draft.graph);
    for (const [i,payload] of ["6","5","4"].entries()) rt.tick({eventId:`s${i}`,nodeId:"env",port:"signal",payload});
    expect(rt.getSnapshot().states.env.unlocked).toBe(false);
    expect(rt.getSnapshot().states.env.signalCount).toBe(1);
    expect(rt.tick({eventId:"final",nodeId:"env",port:"signal",payload:"5"}).states.env.unlocked).toBe(true);
  });
  it("keeps authored fields, music and wiring when sharing, without mutating the original", () => {
    const original=draftFromTemplate("love-letter");
    const before=structuredClone(original);
    original.graph.nodes.push({id:"extra",type:"text",version:"1.0.0",config:{content:"额外的小零件"},position:{x:0,y:0}});
    const result=configureLoveLetter(original,{...DEFAULT_LOVE_LETTER,recipient:"小鹿",sender:"小熊",body:"演示信件 ♡",music:"moon"});
    expect(original.graph.nodes.find((n)=>n.id==="env")?.config).toEqual(before.graph.nodes.find((n)=>n.id==="env")?.config);
    expect(result.graph.nodes.some((n)=>n.id==="extra")).toBe(true);
    expect(result.graph.edges).toEqual(original.graph.edges);
    const shared=decodeDesign(encodeDesign(result));
    expect(shared.theme.music).toBe("moon");
    expect(shared.graph.nodes.find((n)=>n.id==="env")?.config.recipient).toBe("小鹿");
  });
  it("connects loose dice and envelope components instead of producing an unplayable gift", () => {
    const source=draftFromTemplate("love-letter");
    source.graph.nodes=source.graph.nodes.filter((n)=>n.type!=="button");
    source.graph.edges=[];
    const result=configureLoveLetter(source,{...DEFAULT_LOVE_LETTER,target:1});
    expect(result.graph.edges).toHaveLength(3);
    const rt=new RuntimeSession(result.graph,{seed:1});
    const roll=result.graph.nodes.find((n)=>n.type==="button" && n.config.action==="draw")!;
    expect(rt.tick({eventId:"roll",nodeId:roll.id,port:"press"}).states.env.unlocked).toBe(true);
  });
  it("rejects empty letters and invalid targets", () => {
    expect(()=>configureLoveLetter(createDraft(),{...DEFAULT_LOVE_LETTER,body:"   "})).toThrow();
    expect(()=>configureLoveLetter(createDraft(),{...DEFAULT_LOVE_LETTER,target:0})).toThrow();
    expect(()=>configureLoveLetter(createDraft(),{...DEFAULT_LOVE_LETTER,rule:"matches",target:7})).toThrow();
  });
});
