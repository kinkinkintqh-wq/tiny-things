export const tokens = {
  bg: "#F3EEFB",
  panel: "#FFFCFF",
  primary: "#9274DD",
  ink: "#302740",
  muted: "#71677F",
  border: "#E1D8EE",
  pink: "#F1B0C9",
  blue: "#B8D4F4",
  mint: "#CBE6CF",
  cream: "#F5E6B8",
} as const;
