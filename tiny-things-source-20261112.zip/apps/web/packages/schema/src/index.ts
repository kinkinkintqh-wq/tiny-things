import { z } from "zod";

export const SCHEMA_VERSION = "tinythings/1" as const;

export const ValueTypeSchema = z.enum([
  "bool",
  "uint8",
  "uint16",
  "uint32",
  "string",
  "timestamp",
  "event",
]);
export type ValueType = z.infer<typeof ValueTypeSchema>;

export const PortKindSchema = z.enum(["event", "data", "state"]);
export type PortKind = z.infer<typeof PortKindSchema>;

export const PortDefSchema = z.object({
  id: z.string().min(1),
  label: z.string(),
  direction: z.enum(["in", "out"]),
  kind: PortKindSchema,
  valueType: ValueTypeSchema,
  required: z.boolean().default(false),
  cardinality: z.enum(["one", "many"]).default("one"),
});
export type PortDef = z.infer<typeof PortDefSchema>;

export const PositionSchema = z.object({
  x: z.number(),
  y: z.number(),
});

export const GraphNodeSchema = z.object({
  id: z.string().min(1),
  type: z.string().min(1),
  version: z.string().default("1.0.0"),
  config: z.record(z.unknown()).default({}),
  position: PositionSchema,
});
export type GraphNode = z.infer<typeof GraphNodeSchema>;

export const GraphEdgeSchema = z.object({
  id: z.string().min(1),
  source: z.string().min(1),
  sourcePort: z.string().min(1),
  target: z.string().min(1),
  targetPort: z.string().min(1),
  kind: PortKindSchema.default("event"),
});
export type GraphEdge = z.infer<typeof GraphEdgeSchema>;

export const DesignGraphSchema = z.object({
  schemaVersion: z.literal(SCHEMA_VERSION).default(SCHEMA_VERSION),
  nodes: z.array(GraphNodeSchema),
  edges: z.array(GraphEdgeSchema),
  stateScope: z.enum(["perUser", "perDevice", "shared"]).default("perUser"),
});
export type DesignGraph = z.infer<typeof DesignGraphSchema>;

export const ViewportSchema = z.object({
  x: z.number().default(0),
  y: z.number().default(0),
  zoom: z.number().default(1),
});

export const LayoutSchema = z.object({
  viewport: ViewportSchema.default({ x: 0, y: 0, zoom: 1 }),
});

export const ThemeSchema = z.object({
  accent: z.string().default("#9274DD"),
  surface: z.string().default("#FFFCFF"),
  music: z.enum(["musicbox", "picnic", "moon", "none"]).optional(),
});

export const DraftPayloadSchema = z.object({
  schemaVersion: z.literal(SCHEMA_VERSION).default(SCHEMA_VERSION),
  name: z.string().min(1).max(40),
  graph: DesignGraphSchema,
  layout: LayoutSchema.default({ viewport: { x: 0, y: 0, zoom: 1 } }),
  theme: ThemeSchema.default({}),
  revision: z.number().int().nonnegative().default(0),
});
export type DraftPayload = z.infer<typeof DraftPayloadSchema>;

export const VisibilitySchema = z.enum(["public", "unlisted", "private"]);
export type Visibility = z.infer<typeof VisibilitySchema>;

export const CategorySchema = z.enum([
  "all",
  "life",
  "study",
  "mood",
  "play",
]);
export type Category = z.infer<typeof CategorySchema>;

export const ManifestSchema = z.object({
  schemaVersion: z.literal(SCHEMA_VERSION),
  graph: DesignGraphSchema,
  layout: LayoutSchema,
  theme: ThemeSchema,
  blockVersions: z.record(z.string()),
  assets: z.array(z.string()).default([]),
  license: z.string().default("remixable"),
  parentReleaseId: z.string().nullable().default(null),
  category: CategorySchema.default("life"),
  description: z.string().max(500).default(""),
  coverUrl: z.string().nullable().default(null),
});
export type Manifest = z.infer<typeof ManifestSchema>;

export const ApiErrorSchema = z.object({
  code: z.string(),
  message: z.string(),
  fieldPath: z.string().optional(),
  nodeId: z.string().optional(),
  requestId: z.string(),
  retryable: z.boolean().default(false),
});
export type ApiError = z.infer<typeof ApiErrorSchema>;

export const CompileSupportSchema = z.enum([
  "combinational",
  "transition",
  "hostOnly",
  "unsupported",
]);
export type CompileSupport = z.infer<typeof CompileSupportSchema>;

export function emptyGraph(): DesignGraph {
  return {
    schemaVersion: SCHEMA_VERSION,
    nodes: [],
    edges: [],
    stateScope: "perUser",
  };
}

export function createDraft(name = "未命名小东西"): DraftPayload {
  return {
    schemaVersion: SCHEMA_VERSION,
    name,
    graph: emptyGraph(),
    layout: { viewport: { x: 0, y: 0, zoom: 1 } },
    theme: { accent: "#9274DD", surface: "#FFFCFF" },
    revision: 0,
  };
}
