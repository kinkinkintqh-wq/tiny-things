/** NAND/LATCH subset. REF intentionally unsupported. LATCH samples after evaluation.
 * Wire reference: NetLayerLabs/Cerebr/TAPEOUT.md §4 (historical fork evidence).
 * Local validity is not proof that the current X Layer contract accepts a circuit.
 */
export type CircuitElement = { op: "nand"; a: number; b: number } | { op: "latch"; d: number };
export interface SequentialCircuit { nIn: number; nOut: number; elements: CircuitElement[] }
export function validateSequential(c: SequentialCircuit) {
  if (!Number.isInteger(c.nIn) || c.nIn < 0 || c.nIn > 256 || !Number.isInteger(c.nOut) || c.nOut < 1 || c.nOut > c.elements.length || c.elements.length > 10000) throw new Error("Invalid circuit dimensions");
  const total = 2 + c.nIn + c.elements.length;
  const ref = (v: number, limit: number) => { if (!Number.isInteger(v) || v < 0 || v >= limit) throw new Error("Invalid circuit reference"); };
  c.elements.forEach((e, i) => { if (e.op === "latch") ref(e.d, total); else if (e.op === "nand") { ref(e.a, 2 + c.nIn + i); ref(e.b, 2 + c.nIn + i); } else throw new Error("Unsupported opcode"); });
}
export function encodeSequential(c: SequentialCircuit): Uint8Array {
  validateSequential(c);
  const out: number[] = [];
  const u24 = (v: number) => out.push(v >>> 16 & 255, v >>> 8 & 255, v & 255);
  for (const e of c.elements) { out.push(e.op === "nand" ? 0 : 1); if (e.op === "nand") { u24(e.a); u24(e.b); } else u24(e.d); }
  return Uint8Array.from(out);
}
export function decodeSequential(bytes: Uint8Array, nIn: number, nOut: number): SequentialCircuit {
  const elements: CircuitElement[] = [];
  let i = 0;
  const u24 = () => { if (i + 3 > bytes.length) throw new Error("Truncated operand"); return bytes[i++]! * 65536 + bytes[i++]! * 256 + bytes[i++]!; };
  while (i < bytes.length) { const op = bytes[i++]; if (op === 0) elements.push({ op: "nand", a: u24(), b: u24() }); else if (op === 1) elements.push({ op: "latch", d: u24() }); else throw new Error("Unsupported opcode"); }
  const c = { nIn, nOut, elements }; validateSequential(c); return c;
}
export function stepSequential(c: SequentialCircuit, state: boolean[], inputs: boolean[]) {
  validateSequential(c);
  const nState = c.elements.filter(e => e.op === "latch").length;
  if ((state.length !== 0 && state.length !== nState) || inputs.length !== c.nIn) throw new Error("Circuit bit width mismatch");
  const values = [false, true, ...inputs];
  let s = 0;
  for (const e of c.elements) values.push(e.op === "latch" ? (state[s++] ?? false) : !(values[e.a] && values[e.b]));
  return { state: c.elements.flatMap(e => e.op === "latch" ? [values[e.d]!] : []), outputs: values.slice(-c.nOut) };
}
