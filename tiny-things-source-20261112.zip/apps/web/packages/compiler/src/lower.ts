import { getBlock, validateGraph } from "@tinythings/block-registry";
import type { DesignGraph } from "@tinythings/schema";
import type { CompileDiagnostic, TypedIR } from './ir';
import { encodeNetlist, evalNand, NandBuilder, type NandNetlist } from './nand';

export interface CompileResult {
  ir: TypedIR;
  netlist: NandNetlist | null;
  report: { gateCount: number; depth: number; byteLength: number; compiledNodes: string[]; hostOnlyNodes: string[]; unsupportedNodes: string[] };
}

/** Supported boundary: one saturating uint8/uint16 counter and direct button inputs.
 * Host nodes may consume its outputs, but cannot drive circuit inputs. This is a
 * local NAND artifact, not a verified TapeOut deployment or wire-format claim.
 */
export function compileGraph(graph: DesignGraph): CompileResult {
  const diagnostics: CompileDiagnostic[] = validateGraph(graph).map((issue) => ({ level: "error", message: issue.message, nodeId: issue.nodeId }));
  const hostOnlyNodes = graph.nodes.filter((n) => getBlock(n.type)?.compileSupport === "hostOnly").map((n) => n.id);
  const logic = graph.nodes.filter((n) => !hostOnlyNodes.includes(n.id));
  const counters = logic.filter((n) => n.type === "counter");
  const counter = counters[0];
  let netlist: NandNetlist | null = null;
  const ir: TypedIR = { version: "tiny-ir/1", ops: [], stateLayout: [], inputLayout: [], outputLayout: [], diagnostics, coverage: { logicNodes: logic.length, compiled: 0, hostOnly: hostOnlyNodes.length, unsupported: logic.length } };
  const reject = (message: string, nodeId?: string) => diagnostics.push({ level: "warn", message, nodeId });
  const bits = Number(counter?.config.bits ?? 16);
  const step = Number(counter?.config.step ?? 1);
  const initial = Number(counter?.config.initial ?? 0);
  const max = 2 ** bits - 1;
  if (counters.length !== 1 || logic.some((n) => n.type !== "button" && n.type !== "counter")) {
    reject("当前仅编译单个计数器及直连按钮；条件、开关等仍在网页运行。");
  } else if (![8, 16].includes(bits) || !Number.isInteger(step) || step < 1 || step > max || !Number.isInteger(initial) || initial < 0 || initial > max || (counter.config.overflow ?? "saturate") !== "saturate") {
    reject("计数器需为 8/16 位、正整数步长、有效初始值和饱和模式。", counter.id);
  } else {
    const drivers = graph.edges.filter((e) => e.target === counter.id);
    const supportedDriver = (e: DesignGraph['edges'][number]) => e.kind === "event" && e.sourcePort === "click" && ["increment", "reset"].includes(e.targetPort) && graph.nodes.find((n) => n.id === e.source)?.type === "button";
    const buttonIds = logic.filter((n) => n.type === "button").map((n) => n.id);
    const buttonEdges = graph.edges.filter((e) => buttonIds.includes(e.source));
    const valid = drivers.some((e) => e.targetPort === "increment") && drivers.every(supportedDriver)
      && buttonIds.every((id) => buttonEdges.filter((e) => e.source === id).length === 1)
      && buttonEdges.every((e) => e.target === counter.id && supportedDriver(e));
    if (!valid) reject("仅支持按钮直连 +1 / 重置；不支持减法、宿主输入、重复扇出或未连接按钮。");
    else if (!diagnostics.some((d) => d.level === "error")) {
      const b = new NandBuilder(2 + bits);
      const state = Array.from({ length: bits }, (_, i) => b.input(2 + i));
      const constant = (value: number) => state.map((_, i) => (value >>> i) & 1 ? b.const1() : b.const0());
      const sum = b.addBits(state, constant(step));
      const saturated = state.map((_, i) => b.mux(sum.cout, b.const1(), sum.sum[i]!));
      const incremented = state.map((bit, i) => b.mux(b.input(0), saturated[i]!, bit));
      const resetValue = constant(initial);
      const next = state.map((_, i) => b.mux(b.input(1), resetValue[i]!, incremented[i]!));
      netlist = b.build(next, bits, next);
      ir.stateLayout = [{ name: `${counter.id}.value`, bits, offset: 0, initial }];
      ir.inputLayout = [{ name: "increment", bits: 1, offset: 0 }, { name: "reset", bits: 1, offset: 1 }];
      ir.outputLayout = [{ name: `${counter.id}.value`, bits, offset: 0 }];
      ir.ops = [
        { op: "input", id: "inc", ty: { kind: "bool" }, name: "increment" },
        { op: "input", id: "reset", ty: { kind: "bool" }, name: "reset" },
        { op: "stateRead", id: "state", ty: { kind: "uint", bits }, name: "value", nodeId: counter.id },
        { op: "const", id: "step", ty: { kind: "uint", bits }, value: step },
        { op: "const", id: "initial", ty: { kind: "uint", bits }, value: initial },
        { op: "add", id: "sum", ty: { kind: "uint", bits }, a: "state", b: "step", overflow: "saturate" },
        { op: "mux", id: "incNext", ty: { kind: "uint", bits }, sel: "inc", t: "sum", f: "state" },
        { op: "mux", id: "next", ty: { kind: "uint", bits }, sel: "reset", t: "initial", f: "incNext" },
        { op: "stateWrite", id: "write", ty: { kind: "uint", bits }, name: "value", value: "next", nodeId: counter.id },
        { op: "output", id: "out", ty: { kind: "uint", bits }, name: "value", value: "next" },
      ];
      ir.coverage.compiled = logic.length;
      ir.coverage.unsupported = 0;
      diagnostics.push({ level: "info", message: `本地 NAND：${bits} 位，每次 +${step}，重置为 ${initial}；宿主显示不进入电路。` });
    }
  }
  const compiledNodes = netlist ? logic.map((n) => n.id) : [];
  const depths = new Map<number, number>();
  let depth = 0;
  for (const gate of netlist?.gates ?? []) { const d = Math.max(depths.get(gate.a) ?? 0, depths.get(gate.b) ?? 0) + 1; depths.set(gate.out, d); depth = Math.max(depth, d); }
  return { ir, netlist, report: { gateCount: netlist?.gates.length ?? 0, depth, byteLength: netlist ? encodeNetlist(netlist).length : 0, compiledNodes, hostOnlyNodes, unsupportedNodes: logic.filter((n) => !compiledNodes.includes(n.id)).map((n) => n.id) } };
}

export function stepCounterNetlist(net: NandNetlist, state: number, inc: boolean, reset: boolean): number {
  const inputs = [inc, reset, ...Array.from({ length: net.nState }, (_, i) => Boolean((state >>> i) & 1))];
  return evalNand(net, inputs).reduce((value, bit, i) => value + (bit ? 2 ** i : 0), 0);
}
