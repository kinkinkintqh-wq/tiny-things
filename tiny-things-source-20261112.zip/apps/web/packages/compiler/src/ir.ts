export type IrType = { kind: "bool" } | { kind: "uint"; bits: number };

export type IrOp =
  | { op: "const"; id: string; ty: IrType; value: number | boolean; nodeId?: string }
  | { op: "input"; id: string; ty: IrType; name: string; nodeId?: string }
  | { op: "stateRead"; id: string; ty: IrType; name: string; nodeId?: string }
  | { op: "add"; id: string; ty: IrType; a: string; b: string; overflow: "wrap" | "saturate" | "error"; nodeId?: string }
  | { op: "sub"; id: string; ty: IrType; a: string; b: string; overflow: "wrap" | "saturate" | "error"; nodeId?: string }
  | { op: "eq"; id: string; ty: IrType; a: string; b: string; nodeId?: string }
  | { op: "lt"; id: string; ty: IrType; a: string; b: string; nodeId?: string }
  | { op: "and"; id: string; ty: IrType; a: string; b: string; nodeId?: string }
  | { op: "or"; id: string; ty: IrType; a: string; b: string; nodeId?: string }
  | { op: "not"; id: string; ty: IrType; a: string; nodeId?: string }
  | { op: "mux"; id: string; ty: IrType; sel: string; t: string; f: string; nodeId?: string }
  | { op: "stateWrite"; id: string; ty: IrType; name: string; value: string; nodeId?: string }
  | { op: "output"; id: string; ty: IrType; name: string; value: string; nodeId?: string };

export interface TypedIR {
  version: "tiny-ir/1";
  ops: IrOp[];
  stateLayout: Array<{ name: string; bits: number; offset: number; initial: number }>;
  inputLayout: Array<{ name: string; bits: number; offset: number }>;
  outputLayout: Array<{ name: string; bits: number; offset: number }>;
  diagnostics: CompileDiagnostic[];
  coverage: { logicNodes: number; compiled: number; hostOnly: number; unsupported: number };
}

export interface CompileDiagnostic {
  level: "error" | "warn" | "info";
  message: string;
  nodeId?: string;
  fieldPath?: string;
}
