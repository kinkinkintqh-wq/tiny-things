import { describe, expect, it } from "vitest";
import { assertLocalForkEndpoint, assertLocalForkIdentity } from "../../../../../packages/tapeout-adapter/src/fork-safety";

describe("simulation write boundary", () => {
  it("allows only the fixed local endpoint", () => {
    expect(() => assertLocalForkEndpoint("http://127.0.0.1:18546")).not.toThrow();
    for (const url of ["https://rpc.xlayer.tech", "https://xlayerrpc.okx.com", "http://127.0.0.1:8545", "http://127.0.0.1:18546@evil.example", "http://localhost:18546"]) expect(() => assertLocalForkEndpoint(url)).toThrow();
  });
  it("requires both Anvil identity and a distinct simulation chain", () => {
    expect(() => assertLocalForkIdentity(31337, "anvil/v1.7.1")).not.toThrow();
    for (const [chain, version] of [[196, "anvil/v1.7.1"], [31337, "geth/v1"], [196, "geth/v1"]] as const) expect(() => assertLocalForkIdentity(chain, version)).toThrow();
  });
});
