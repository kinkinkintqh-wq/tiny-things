import { describe, expect, it } from "vitest";
import { compileLetterRule, stepLetterRule, supportedLetterRule } from "./letter";
import { decodeSequential, encodeSequential, stepSequential } from "./sequential";
import { draftFromTemplate } from "@tinythings/block-registry";
import { RuntimeSession } from "@tinythings/runtime";

describe("NAND/LATCH letter circuits (local, not chain acceptance)", () => {
  it("round-trips bytecode and exhausts all valid states and encoded dice inputs", () => {
    for (const rule of ["sum", "matches"] as const) for (const target of [1, 3, 12, 99]) for (const face of rule === "sum" ? [6] : [1, 2, 3, 4, 5, 6]) {
      const c = compileLetterRule({ rule, target, face });
      const decoded = decodeSequential(encodeSequential(c), c.nIn, c.nOut);
      expect(decoded).toEqual(c);
      for (let progress = 0; progress <= target; progress++) for (const unlocked of [false, true]) for (let dice = 0; dice <= 7; dice++) for (const signal of [false, true]) {
        const add = signal && !unlocked ? rule === "sum" ? (dice >= 1 && dice <= 6 ? dice : 0) : Number(dice === face) : 0;
        const expected = Math.min(target, progress + add);
        const result = stepLetterRule(decoded, progress, unlocked, signal, dice);
        expect(result.progress).toBe(expected);
        expect(result.unlocked).toBe(unlocked || (signal && expected >= target));
        expect(result.outputs.slice(0, 7).reduce((n, v, i) => n + (v ? 2 ** i : 0), 0)).toBe(result.progress);
        expect(result.outputs[7]).toBe(result.unlocked);
      }
    }
  });
  it("samples forward LATCH feedback after outputs, with zero initial state", () => {
    const c = { nIn: 0, nOut: 1, elements: [{ op: "latch" as const, d: 3 }, { op: "nand" as const, a: 2, b: 2 }] };
    expect(stepSequential(c, [], [])).toEqual({ state: [true], outputs: [true] });
    expect(stepSequential(c, [true], [])).toEqual({ state: [false], outputs: [false] });
    expect(() => decodeSequential(new Uint8Array([1, 0]), 0, 1)).toThrow();
    expect(() => decodeSequential(new Uint8Array([0, 0, 0, 2, 0, 0, 0]), 0, 1)).toThrow();
    expect(() => decodeSequential(new Uint8Array([1, 0, 0, 9]), 0, 1)).toThrow();
    expect(() => decodeSequential(new Uint8Array([2]), 0, 1)).toThrow();
  });
  it("runs real graph events identically to the reference, including restore, invalid payload and manual unlock", () => {
    for (const template of ["love-letter", "dice-letter"]) {
      const graph = draftFromTemplate(template).graph;
      const circuit = new RuntimeSession(graph, { seed: 73 });
      const reference = new RuntimeSession(graph, { seed: 73, letterCircuit: false });
      for (let roll = 0; roll < 20; roll++) {
        const e = { eventId: `roll-${roll}`, nodeId: "roll", port: "click" };
        expect(circuit.tick(e)).toEqual(reference.tick(e));
        expect(circuit.tick(e)).toEqual(reference.tick(e));
      }
      const payloads = ["06", "6.0", null, "NaN", -1, 7, "6", "2", "3", "6", "6"];
      let id = 0;
      for (const payload of payloads) {
        const e = { eventId: String(id++), nodeId: "env", port: "signal", payload };
        expect(circuit.tick(e)).toEqual(reference.tick(e));
      }
      for (const port of ["unlock", "open", "signal", "open"]) {
        const e = { eventId: String(id++), nodeId: "env", port, payload: "6" };
        expect(circuit.tick(e)).toEqual(reference.tick(e));
      }
      const snap = circuit.getSnapshot();
      circuit.loadState(snap.states); reference.loadState(snap.states);
      expect(circuit.tick({ eventId: "after-restore", nodeId: "env", port: "signal", payload: "6" })).toEqual(reference.tick({ eventId: "after-restore", nodeId: "env", port: "signal", payload: "6" }));
    }
  });
  it("rejects unsupported configurations rather than claiming coverage", () => {
    for (const config of [{ unlockMode: "time" }, { unlockMode: "signals", needSignals: 2.5 }, { unlockMode: "signals", matchPayload: "cat" }, { unlockMode: "signals", signalRule: "other" }]) expect(supportedLetterRule(config)).toBeNull();
    expect(() => compileLetterRule({ rule: "sum", target: 100, face: 6 })).toThrow();
  });
});

describe("legacy multi-output NAND serialization", () => {
  it("keeps every output contiguous at the tail in the original order", async () => {
    const { NandBuilder, encodeNetlist, decodeNetlist, evalNand } = await import("./nand");
    const b = new NandBuilder(2);
    const net = b.build([b.input(0), b.input(1), b.xor(b.input(0), b.input(1))]);
    const restored = decodeNetlist(encodeNetlist(net), 2, 3);
    for (const x of [false, true]) for (const y of [false, true]) expect(evalNand(restored, [x, y])).toEqual([x, y, x !== y]);
  });
});
