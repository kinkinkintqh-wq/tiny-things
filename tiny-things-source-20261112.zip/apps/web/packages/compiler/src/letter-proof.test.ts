import {describe,it,expect} from 'vitest';
import {verifyLetterCircuit} from '../../../../../packages/tapeout-adapter/src/letter-proof';
import sum from '../../../../../verification/letter-circuits/sum.json';
import matches from '../../../../../verification/letter-circuits/matches.json';
import {demoLink,localPreview} from '../../../src/lib/share-link';
const factory='0x1f09daefa827f02cbb40967cc91b259763760761';
function synthetic(rule:'sum'|'matches',change:{output?:boolean;netlist?:boolean;chain?:boolean;reorg?:boolean}={}){
 const a=rule==='sum'?sum:matches;const blocks:bigint[]=[];
 const client={
  getChainId:async()=>change.chain?1:196,
  getBlock:async(args?:unknown)=>({number:100n,hash:change.reorg&&args?'0xdifferent':'0xsynthetic'}),
  readContract:async({functionName,args,blockNumber}:{functionName:string;args:unknown[];blockNumber:bigint})=>{
   blocks.push(blockNumber);
   if(functionName==='isCPU')return true;
   if(functionName==='factory')return factory;
   if(functionName==='circuitInfo')return [5,8,8,a.nandCount+8];
   if(functionName==='netlist')return change.netlist?'0x00':a.encodedHex;
   if(functionName==='step'){
    const state=args[1]==='0x'?0:parseInt(String(args[1]).slice(2),16), input=parseInt(String(args[2]).slice(2),16);
    let progress=state&127,unlocked=Boolean(state&128);const signal=Boolean(input&1),face=(input>>1)&7;
    if(signal&&!unlocked){if(rule==='sum'&&face>=1&&face<=6)progress=Math.min(a.rule.target,progress+face);if(rule==='matches'&&face===a.rule.face)progress=Math.min(a.rule.target,progress+1);if(progress>=a.rule.target)unlocked=true;}
    if(input&16)unlocked=true;
    const next='0x'+(progress|(unlocked?128:0)).toString(16).padStart(2,'0');return [next,change.output?'0xff':next];
   }
   throw Error('Unexpected synthetic call');
  }
 } as unknown as Parameters<typeof verifyLetterCircuit>[0];
 return {client,blocks};
}
describe('deployed letter proof, explicitly synthetic RPC',()=>{
 it('pins all calls and compares both rules with an independent numeric model',async()=>{
  for(const rule of ['sum','matches'] as const){const {client,blocks}=synthetic(rule);const r=await verifyLetterCircuit(client,'999',rule);expect(r.verified).toBe(true);expect(r.vectors).toHaveLength(44);expect(new Set(blocks)).toEqual(new Set([100n]));expect(r.circuitId).toBe('999');}
 });
 it('rejects bytecode, output, chain and canonical block changes',async()=>{
  for(const change of [{netlist:true},{output:true},{chain:true},{reorg:true}])await expect(verifyLetterCircuit(synthetic('sum',change).client,'999','sum')).rejects.toThrow();
 });
 it('rejects missing IDs and unsupported rules before RPC',async()=>{
  const {client}=synthetic('sum');for(const id of ['', '0','fake','-1'])await expect(verifyLetterCircuit(client,id,'sum')).rejects.toThrow();await expect(verifyLetterCircuit(client,'999','other')).rejects.toThrow();
 });
});
describe('public demo sharing',()=>{
 it('creates a selected same-origin demo URL and never embeds credentials',()=>{
  expect(demoLink('https://example.com','daily-checkin')).toBe('https://example.com/demo?thing=daily-checkin');
  expect(demoLink('https://user:password@example.com/a#b','love-letter')).not.toContain('password');
  expect(()=>demoLink('javascript:alert(1)','love-letter')).toThrow();expect(()=>demoLink('https://example.com','unknown')).toThrow();
 });
 it('distinguishes local and private-network previews from public links',()=>{
  for(const u of ['http://127.0.0.1:3846','http://localhost:3846','http://192.168.1.2','http://10.0.0.1','http://172.16.0.1','http://[::1]:3846'])expect(localPreview(u)).toBe(true);
  expect(localPreview('https://example.com/demo')).toBe(false);
 });
});
