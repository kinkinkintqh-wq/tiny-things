import { SCHEMA_VERSION } from "@tinythings/schema";
import { describe, expect, it } from "vitest";
import { compileGraph, stepCounterNetlist } from './lower';
import {
  buildXorNetlist,
  decodeNetlist,
  encodeNetlist,
  evalNand,
  packBits,
  unpackBits,
} from './nand';

describe("XOR NAND mapping", () => {
  it("matches 00/01/10/11 -> 0/1/1/0", () => {
    const net = buildXorNetlist();
    const vectors: Array<[boolean, boolean, boolean]> = [
      [false, false, false],
      [false, true, true],
      [true, false, true],
      [true, true, false],
    ];
    for (const [a, b, y] of vectors) {
      expect(evalNand(net, [a, b])[0]).toBe(y);
    }
  });

  it("encode→decode→encode is stable and evaluates equal", () => {
    const net = buildXorNetlist();
    const bytes = encodeNetlist(net);
    expect(bytes.length % 7).toBe(0);
    const decoded = decodeNetlist(bytes, 2, 1);
    const bytes2 = encodeNetlist(decoded);
    expect(Buffer.from(bytes2).equals(Buffer.from(encodeNetlist(decoded)))).toBe(
      true
    );
    for (const a of [false, true]) {
      for (const b of [false, true]) {
        expect(evalNand(decoded, [a, b])).toEqual(evalNand(net, [a, b]));
      }
    }
  });
});

describe("uint8 saturating counter C1", () => {
  it("covers 256 states × {nop,inc,reset,inc+reset}", () => {
    const graph = {
      schemaVersion: SCHEMA_VERSION,
      stateScope: "perUser" as const,
      nodes: [
        {
          id: "b1",
          type: "button",
          version: "1.0.0",
          config: {},
          position: { x: 0, y: 0 },
        },
        {
          id: "c1",
          type: "counter",
          version: "1.0.0",
          config: { bits: 8, overflow: "saturate" },
          position: { x: 100, y: 0 },
        },
      ],
      edges: [
        {
          id: "e1",
          source: "b1",
          sourcePort: "click",
          target: "c1",
          targetPort: "increment",
          kind: "event" as const,
        },
      ],
    };
    const { netlist } = compileGraph(graph);
    expect(netlist).not.toBeNull();
    const net = netlist!;

    for (let s = 0; s < 256; s++) {
      // nop
      expect(stepCounterNetlist(net, s, false, false)).toBe(s);
      // inc saturate
      expect(stepCounterNetlist(net, s, true, false)).toBe(Math.min(255, s + 1));
      // reset priority
      expect(stepCounterNetlist(net, s, false, true)).toBe(0);
      expect(stepCounterNetlist(net, s, true, true)).toBe(0);
    }
  });
});

describe("bit pack", () => {
  it("LSB-first roundtrip", () => {
    const bits = [true, false, true, true, false, false, false, true];
    expect(unpackBits(packBits(bits), 8)).toEqual(bits);
  });
});
