import { describe,it,expect,vi } from 'vitest';
import { validateLaunchInput, remainingBudget, matchApprovedTransaction, STEPS } from '../../../../../packages/tapeout-adapter/src/letter-launch';
import { assertWallet, connectAccounts, parseJournal, okb, walletMessage, walletRead } from '../../../src/lib/launch-wallet';
const account='0x1111111111111111111111111111111111111111';
const hash='0x'+'ab'.repeat(32);
describe('wallet launch boundaries (synthetic data)',()=>{
 it('reuses authorized accounts and does not open another connection request',async()=>{
  const request=vi.fn(async()=>[account]);
  expect(await connectAccounts({request})).toEqual([account]);
  expect(request.mock.calls).toEqual([[{method:'eth_accounts'}]]);
 });
 it('reports plain provider errors and bounds a stalled connection without retrying',async()=>{
  expect(walletMessage({code:-32002,message:'pending'})).toContain('待处理请求');
  expect(walletMessage({code:4001})).toContain('取消');
  expect(walletMessage({message:'provider failed'})).toBe('provider failed');
  vi.useFakeTimers();
  try{
   const request=vi.fn(()=>new Promise<never>(()=>{}));
   const result=expect(walletRead(request,100)).rejects.toThrow('没有发送交易');
   await vi.advanceTimersByTimeAsync(100);await result;
   expect(request).toHaveBeenCalledTimes(1);
  }finally{vi.useRealTimers();}
 });
 it('rejects malformed/repeated history, invalid steps and the fork-only synthetic wallet',()=>{
  expect(()=>validateLaunchInput(account,0,[])).not.toThrow();
  for(const [a,s,h] of [[account,1,[]],[account,2,[hash,hash]],[account,-1,[]],['0x0000000000000000000000000000000000031337',0,[]],['0x0000000000000000000000000000000000000000',0,[]]] as const)expect(()=>validateLaunchInput(a,s,[...h])).toThrow();
 });
 it('counts previous actual costs and all remaining worst-case gas against the approved cap',()=>{
  expect(remainingBudget(0,0n,40000000n).maximumTotal).toBe(4067074080000000n);
  expect(()=>remainingBudget(0,0n,40000001n)).toThrow();
  expect(()=>remainingBudget(3,4200000000000000n,20000000n)).toThrow();
  expect(remainingBudget(4,4000000000000000n,20000000n).maximumTotal).toBe(4000000000000000n);
 });
 it('accepts only exact approved calldata, sender, destination, amount and chain',()=>{
  const t=STEPS[0];const tx={from:account,to:t.to,input:t.data,value:BigInt(t.value),chainId:196};
  expect(()=>matchApprovedTransaction(tx,account,0)).not.toThrow();
  for(const patch of [{from:'0x2222222222222222222222222222222222222222'},{to:account},{input:'0x'},{value:0n},{chainId:1}])expect(()=>matchApprovedTransaction({...tx,...patch},account,0)).toThrow();
 });
 it('requires matching wallet account AND network just before signing',async()=>{
  const p=(chain:string,accounts:string[])=>({request:async({method}:{method:string})=>method==='eth_chainId'?chain:accounts});
  await expect(assertWallet(p('0xc4',[account]),account)).resolves.toBeUndefined();
  await expect(assertWallet(p('0x1',[account]),account)).rejects.toThrow();
  await expect(assertWallet(p('0xc4',[]),account)).rejects.toThrow();
 });
 it('restores pending and uncertain intent, rejects corrupt progress, and formats fees without floating point',()=>{
  const j={account,confirmed:0,hashes:[hash],uncertain:false};expect(parseJournal(JSON.stringify(j))).toEqual(j);
  expect(parseJournal(JSON.stringify({...j,hashes:[],uncertain:true}))?.uncertain).toBe(true);
  for(const patch of [{confirmed:2},{hashes:[hash,hash]},{account:'wrong'},{confirmed:5},{uncertain:'false'}])expect(parseJournal(JSON.stringify({...j,...patch}))).toBeNull();
  expect(okb('4200000000000000')).toBe('0.0042');expect(okb('1')).toBe('0.000000000000000001');
 });
});

import { readFileSync } from 'node:fs';
import { inspectLaunch } from '../../../../../packages/tapeout-adapter/src/letter-launch';
import launchPlan from '../../../../../verification/tapeout-preflight/unsigned-plan.json';
function syntheticClient(overrides:Record<string,unknown>={}){
 const entries=launchPlan.target.code;
 const hash='0x'+'cd'.repeat(32);
 const defaults={
  getChainId:async()=>196,
  getBlock:async()=>({number:100n,hash}),
  getCode:async({address}:{address:string})=>readFileSync(new URL(`../../../../../verification/tapeout-preflight/${address}.hex`,import.meta.url),'utf8').trim(),
  getStorageAt:async({address,slot}:{address:string;slot:string})=>{const e=entries.find(e=>e.address.toLowerCase()===address.toLowerCase())!;return '0x'+(slot.startsWith('0xa3f0')?e.beacon:e.implementation).slice(2).padStart(64,'0');},
  readContract:async({functionName,address}:{functionName:string;address:string})=>{
   if(functionName==='implementation')return entries.find(e=>e.beacon.toLowerCase()===address.toLowerCase())!.implementation;
   if(functionName==='isCPU')return true;
   if(functionName==='factory')return launchPlan.target.factory;
   if(functionName==='transistors')return launchPlan.target.transistors;
   return ({TAPEOUT_FEE:1300000000000000n,protocolFee:660000000000000n,mintPrice:0n,minted:100n,supplyCap:1000000n} as Record<string,unknown>)[functionName];
  },
  getGasPrice:async()=>20000001n,getBalance:async()=>1000000000000000000n,
  call:async()=>({data:'0x'}),estimateGas:async()=>85000n,
 };
 return {...defaults,...overrides} as unknown as Parameters<typeof inspectLaunch>[0];
}
describe('live preflight with explicitly synthetic RPC responses',()=>{
 it('produces only the next approved request after code, fee and budget checks',async()=>{
  const q=await inspectLaunch(syntheticClient(),account,0,[]);
  expect(q.transaction?.data).toBe(STEPS[0].data);expect(q.transaction?.from).toBe(account);expect(q.transaction?.chainId).toBe('0xc4');
  expect(q.maximumTotalWei).toBe('3993537043676852');
 });
 it('fails closed on network, code, balance and gas-limit changes',async()=>{
  for(const client of [syntheticClient({getChainId:async()=>1}),syntheticClient({getCode:async()=>'0x00'}),syntheticClient({getBalance:async()=>0n}),syntheticClient({estimateGas:async()=>1000000n})])await expect(inspectLaunch(client,account,0,[])).rejects.toThrow();
 });
 it('fails closed when live protocol fees or registration change',async()=>{
  const base=syntheticClient();
  for(const changed of ['TAPEOUT_FEE','isCPU']){
   const client=syntheticClient({readContract:async(args:Parameters<typeof base.readContract>[0])=>args.functionName===changed?(changed==='isCPU'?false:1n):base.readContract(args)});
   await expect(inspectLaunch(client,account,0,[])).rejects.toThrow();
  }
 });
});
