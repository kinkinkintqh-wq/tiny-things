import { NandBuilder } from "./nand";
import { encodeSequential, stepSequential, type CircuitElement, type SequentialCircuit } from "./sequential";

export interface LetterRule { rule: "sum" | "matches"; target: number; face: number }
export function supportedLetterRule(config: Record<string, unknown>): LetterRule | null {
  const target = Number(config.needSignals ?? 3);
  const match = String(config.matchPayload ?? "").trim();
  if (config.unlockMode !== "signals" || !Number.isInteger(target) || target < 1 || target > 99 || (config.signalRule !== undefined && config.signalRule !== "sum" && config.signalRule !== "matches") || (config.signalRule !== "sum" && !/^[1-6]$/.test(match))) return null;
  return { rule: config.signalRule === "sum" ? "sum" : "matches", target, face: Number(match) || 6 };
}
const bits = (n: number, width: number) => Array.from({ length: width }, (_, i) => Boolean(n & (1 << i)));
const number = (bs: boolean[]) => bs.reduce((n, v, i) => n + (v ? 2 ** i : 0), 0);
/** Inputs: signal enable, face[0..2], force unlock. State: progress[0..6], unlocked.
 * Outputs expose NEXT progress/unlocked, not old latch values. Letter content is host-only.
 */
export function compileLetterRule(rule: LetterRule): SequentialCircuit {
  if (!Number.isInteger(rule.target) || rule.target < 1 || rule.target > 99 || !Number.isInteger(rule.face) || rule.face < 1 || rule.face > 6 || !["sum", "matches"].includes(rule.rule)) throw new Error("Unsupported letter rule");
  const nIn = 5, nState = 8;
  const b = new NandBuilder(nIn + nState);
  const constant = (n: number, width: number) => bits(n, width).map(v => v ? 1 : 0);
  const eq = (xs: number[], n: number) => xs.reduce((s, x, i) => b.and(s, n & (1 << i) ? x : b.not(x)), 1);
  const ge = (xs: number[], n: number) => {
    let equal = 1, greater = 0;
    for (let i = xs.length - 1; i >= 0; i--) { const bit = Boolean(n & (1 << i)); if (!bit) greater = b.or(greater, b.and(equal, xs[i]!)); equal = b.and(equal, bit ? xs[i]! : b.not(xs[i]!)); }
    return b.or(greater, equal);
  };
  const face = [b.input(1), b.input(2), b.input(3)];
  const progress = Array.from({ length: 7 }, (_, i) => b.input(nIn + i));
  const unlocked = b.input(nIn + 7);
  const valid = b.not(b.or(eq(face, 0), eq(face, 7)));
  const enabled = b.and(b.and(b.input(0), b.not(unlocked)), rule.rule === "sum" ? valid : eq(face, rule.face));
  const addend = rule.rule === "sum" ? [...face, 0, 0, 0, 0] : constant(1, 7);
  const { sum, cout } = b.addBits(progress, addend);
  const reached = b.or(cout, ge(sum, rule.target));
  const capped = sum.map((v, i) => b.mux(reached, constant(rule.target, 7)[i]!, v));
  const next = progress.map((v, i) => b.mux(enabled, capped[i]!, v));
  next.push(b.or(b.or(unlocked, b.input(4)), b.and(b.input(0), ge(next, rule.target))));
  // Reserve virtual state inputs as LATCH elements; indices match the builder.
  const elements: CircuitElement[] = next.map(d => ({ op: "latch", d }));
  elements.push(...b.gates.map(g => ({ op: "nand" as const, a: g.a, b: g.b })));
  // All inversions first, then all buffers: the final eight signals MUST be outputs.
  const inverted = next.map(v => { const out = 2 + nIn + elements.length; elements.push({ op: "nand", a: v, b: v }); return out; });
  inverted.forEach(v => elements.push({ op: "nand", a: v, b: v }));
  const circuit = { nIn, nOut: 8, elements }; encodeSequential(circuit); return circuit;
}
export function stepLetterRule(circuit: SequentialCircuit, progress: number, unlocked: boolean, signal: boolean, face: number, forceUnlock = false) {
  if (!Number.isInteger(progress) || progress < 0 || progress > 127 || !Number.isInteger(face) || face < 0 || face > 7) throw new Error("Invalid letter input");
  const result = stepSequential(circuit, [...bits(progress, 7), unlocked], [signal, ...bits(face, 3), forceUnlock]);
  return { progress: number(result.state.slice(0, 7)), unlocked: result.state[7]!, outputs: result.outputs };
}
