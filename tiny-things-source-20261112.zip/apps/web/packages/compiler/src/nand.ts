/** Pure NAND boolean DAG + TAP-02-ish encoder. */

export interface NandGate {
  /** Output signal index (>= 2 + nIn for computed signals; 0/1 are constants) */
  out: number;
  a: number;
  b: number;
}

export interface NandNetlist {
  nIn: number;
  nOut: number;
  nState: number;
  gates: NandGate[];
  /** Final output signal indices; encoder will ensure they are the last nOut signals. */
  outputs: number[];
  /** Optional state next-output signal indices (combinational next-state). */
  nextState?: number[];
}

export class NandBuilder {
  readonly nIn: number;
  private nextSig: number;
  readonly gates: NandGate[] = [];

  constructor(nIn: number) {
    this.nIn = nIn;
    this.nextSig = 2 + nIn; // 0=const0, 1=const1, 2..= inputs
  }

  const0() {
    return 0;
  }
  const1() {
    return 1;
  }
  input(i: number) {
    if (i < 0 || i >= this.nIn) throw new Error(`input ${i} out of range`);
    return 2 + i;
  }

  nand(a: number, b: number): number {
    const out = this.nextSig++;
    this.gates.push({ out, a, b });
    return out;
  }

  not(a: number) {
    return this.nand(a, a);
  }
  and(a: number, b: number) {
    return this.not(this.nand(a, b));
  }
  or(a: number, b: number) {
    return this.nand(this.not(a), this.not(b));
  }
  xor(a: number, b: number) {
    const t = this.nand(a, b);
    const u = this.nand(a, t);
    const v = this.nand(b, t);
    return this.nand(u, v);
  }
  mux(sel: number, t: number, f: number) {
    // (sel & t) | (!sel & f)
    return this.or(this.and(sel, t), this.and(this.not(sel), f));
  }

  /** Ripple-carry adder bits -> {sum[], cout} */
  addBits(a: number[], b: number[], cin = this.const0()) {
    const sum: number[] = [];
    let carry = cin;
    for (let i = 0; i < a.length; i++) {
      const ai = a[i]!;
      const bi = b[i]!;
      const s = this.xor(this.xor(ai, bi), carry);
      const c1 = this.and(ai, bi);
      const c2 = this.and(this.xor(ai, bi), carry);
      carry = this.or(c1, c2);
      sum.push(s);
    }
    return { sum, cout: carry };
  }

  /** Saturating increment for n-bit value with enable */
  saturatingInc(bits: number[], enable: number) {
    const one = bits.map((_, i) => (i === 0 ? this.const1() : this.const0()));
    const { sum, cout } = this.addBits(bits, one);
    // if enable: if cout then all-ones else sum; else keep bits
    const allOnes = bits.map(() => this.const1());
    const sat = bits.map((_, i) => this.mux(cout, allOnes[i]!, sum[i]!));
    return bits.map((b, i) => this.mux(enable, sat[i]!, b));
  }

  build(outputs: number[], nState = 0, nextState?: number[]): NandNetlist {
    return {
      nIn: this.nIn,
      nOut: outputs.length,
      nState,
      gates: [...this.gates],
      outputs,
      nextState,
    };
  }
}

/** Evaluate combinational NAND netlist. inputs as bit array length nIn. */
export function evalNand(net: NandNetlist, inputs: boolean[]): boolean[] {
  if (inputs.length !== net.nIn) throw new Error("input width mismatch");
  const vals = new Map<number, boolean>();
  vals.set(0, false);
  vals.set(1, true);
  for (let i = 0; i < net.nIn; i++) vals.set(2 + i, inputs[i]!);
  for (const g of net.gates) {
    const a = vals.get(g.a);
    const b = vals.get(g.b);
    if (a === undefined || b === undefined) {
      throw new Error(`forward or missing ref at signal ${g.out}`);
    }
    vals.set(g.out, !(a && b));
  }
  return net.outputs.map((s) => {
    const v = vals.get(s);
    if (v === undefined) throw new Error(`missing output signal ${s}`);
    return v;
  });
}

/**
 * TAP-02 candidate encoding:
 * signal 0/1 constants, inputs from 2; NAND opcode=00, a/b each 3-byte big-endian.
 * Vector packing LSB-first in bytes for I/O bits (separate from gate encoding).
 */
export function encodeNetlist(net: NandNetlist): Uint8Array {
  // Ensure outputs are the last nOut produced signals by appending buffer NANDs if needed.
  const ordered = ensureTailOutputs(net);
  const bytes: number[] = [];
  for (const g of ordered.gates) {
    bytes.push(0x00);
    pushU24(bytes, g.a);
    pushU24(bytes, g.b);
  }
  return Uint8Array.from(bytes);
}

export function decodeNetlist(
  bytes: Uint8Array,
  nIn: number,
  nOut: number,
  nState = 0
): NandNetlist {
  if (bytes.length % 7 !== 0) throw new Error("truncated netlist");
  const gates: NandGate[] = [];
  let next = 2 + nIn;
  for (let i = 0; i < bytes.length; i += 7) {
    const opcode = bytes[i]!;
    if (opcode !== 0x00) throw new Error(`unknown opcode ${opcode}`);
    const a = readU24(bytes, i + 1);
    const b = readU24(bytes, i + 4);
    if (a >= next || b >= next) throw new Error("forward NAND reference");
    gates.push({ out: next, a, b });
    next += 1;
  }
  const outputs: number[] = [];
  for (let i = 0; i < nOut; i++) outputs.push(next - nOut + i);
  return { nIn, nOut, nState, gates, outputs };
}

function ensureTailOutputs(net: NandNetlist): NandNetlist {
  const gates = [...net.gates];
  let nextSig = 2 + net.nIn + gates.length;
  const inverted = net.outputs.map(o => {
    const out = nextSig++;
    gates.push({ out, a: o, b: o });
    return out;
  });
  const outs = inverted.map(t => {
    const out = nextSig++;
    gates.push({ out, a: t, b: t });
    return out;
  });
  return { ...net, gates, outputs: outs, nOut: outs.length };
}

function pushU24(bytes: number[], v: number) {
  bytes.push((v >>> 16) & 0xff, (v >>> 8) & 0xff, v & 0xff);
}
function readU24(bytes: Uint8Array, i: number) {
  return ((bytes[i]! << 16) | (bytes[i + 1]! << 8) | bytes[i + 2]!) >>> 0;
}

export function packBits(bits: boolean[]): Uint8Array {
  const out = new Uint8Array(Math.ceil(bits.length / 8) || 1);
  for (let i = 0; i < bits.length; i++) {
    if (bits[i]) {
      const idx = i >> 3;
      out[idx] = (out[idx] ?? 0) | (1 << (i & 7));
    }
  }
  return out;
}

export function unpackBits(bytes: Uint8Array, n: number): boolean[] {
  const bits: boolean[] = [];
  for (let i = 0; i < n; i++) {
    bits.push(((bytes[i >> 3] ?? 0) >> (i & 7)) & 1 ? true : false);
  }
  return bits;
}

/** Canonical XOR example from the spec. */
export function buildXorNetlist(): NandNetlist {
  const b = new NandBuilder(2);
  const y = b.xor(b.input(0), b.input(1));
  return b.build([y]);
}
