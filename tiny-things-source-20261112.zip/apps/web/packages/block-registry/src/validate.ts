import type { DesignGraph, GraphEdge, ValueType } from "@tinythings/schema";
import { getBlock } from './registry';

export interface ConnectionIssue {
  code: string;
  message: string;
  edgeId?: string;
  nodeId?: string;
}

const WIDEN: Record<string, number> = {
  uint8: 8,
  uint16: 16,
  uint32: 32,
};

export function canConnectTypes(from: ValueType, to: ValueType): boolean {
  if (from === "event" || to === "event") return from === "event" && to === "event";
  if (from === to) return true;
  if (from in WIDEN && to in WIDEN) return (WIDEN[from] ?? 0) <= (WIDEN[to] ?? 0);
  return false;
}

export function validateConnection(
  graph: DesignGraph,
  edge: Omit<GraphEdge, "id"> & { id?: string }
): ConnectionIssue | null {
  const sourceNode = graph.nodes.find((n) => n.id === edge.source);
  const targetNode = graph.nodes.find((n) => n.id === edge.target);
  if (!sourceNode || !targetNode) {
    return { code: "missing_node", message: "连接的节点不存在", edgeId: edge.id };
  }
  if (edge.source === edge.target) {
    return { code: "self_loop", message: "不允许自环，请用状态节点表达反馈", edgeId: edge.id };
  }
  const sDef = getBlock(sourceNode.type);
  const tDef = getBlock(targetNode.type);
  if (!sDef || !tDef) {
    return { code: "unknown_block", message: "未知零件类型", edgeId: edge.id };
  }
  const outPort = sDef.outputPorts.find((p) => p.id === edge.sourcePort);
  const inPort = tDef.inputPorts.find((p) => p.id === edge.targetPort);
  if (!outPort || !inPort) {
    return { code: "missing_port", message: "端口不存在", edgeId: edge.id };
  }
  if (outPort.direction !== "out" || inPort.direction !== "in") {
    return { code: "direction", message: "端口方向不正确", edgeId: edge.id };
  }
  if (outPort.kind !== inPort.kind) {
    return {
      code: "kind_mismatch",
      message: `不能将 ${outPort.kind} 接到 ${inPort.kind}`,
      edgeId: edge.id,
    };
  }
  if (!canConnectTypes(outPort.valueType, inPort.valueType)) {
    return {
      code: "type_mismatch",
      message: `${outPort.valueType} 不能直接接到 ${inPort.valueType}`,
      edgeId: edge.id,
    };
  }
  if (inPort.kind === "data" && inPort.cardinality === "one") {
    const conflict = graph.edges.find(
      (e) =>
        e.id !== edge.id &&
        e.target === edge.target &&
        e.targetPort === edge.targetPort
    );
    if (conflict) {
      return {
        code: "cardinality",
        message: "该数据输入只允许一条边",
        edgeId: edge.id,
      };
    }
  }
  return null;
}

export function wouldCreateCycle(graph: DesignGraph, edge: GraphEdge): boolean {
  // Only treat data edges as structural deps for cycle detection of combinational loops
  if (edge.kind === "event") return false;
  const adj = new Map<string, string[]>();
  for (const n of graph.nodes) adj.set(n.id, []);
  for (const e of graph.edges) {
    if (e.kind === "event") continue;
    adj.get(e.source)?.push(e.target);
  }
  adj.get(edge.source)?.push(edge.target);

  const visiting = new Set<string>();
  const visited = new Set<string>();
  const dfs = (id: string): boolean => {
    if (visiting.has(id)) return true;
    if (visited.has(id)) return false;
    visiting.add(id);
    for (const next of adj.get(id) ?? []) {
      if (dfs(next)) return true;
    }
    visiting.delete(id);
    visited.add(id);
    return false;
  };
  return dfs(edge.source);
}

export function validateGraph(graph: DesignGraph): ConnectionIssue[] {
  const issues: ConnectionIssue[] = [];
  for (const node of graph.nodes) {
    if (!getBlock(node.type)) {
      issues.push({
        code: "unknown_block",
        message: `未知零件: ${node.type}`,
        nodeId: node.id,
      });
    }
  }
  for (const edge of graph.edges) {
    const issue = validateConnection(graph, edge);
    if (issue) issues.push(issue);
    else if (wouldCreateCycle(graph, edge)) {
      issues.push({
        code: "cycle",
        message: "拒绝组合环，请通过状态节点表达反馈",
        edgeId: edge.id,
      });
    }
  }
  return issues;
}
