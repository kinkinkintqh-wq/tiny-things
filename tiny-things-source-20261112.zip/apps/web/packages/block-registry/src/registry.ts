import { ALL_BLOCKS } from './blocks';
import type { BlockDefinition } from './types';

const byType = new Map(ALL_BLOCKS.map((b) => [b.type, b]));

export function listBlocks(): BlockDefinition[] {
  return [...ALL_BLOCKS];
}

export function getBlock(type: string): BlockDefinition | undefined {
  return byType.get(type);
}

export function requireBlock(type: string): BlockDefinition {
  const b = byType.get(type);
  if (!b) throw new Error(`Unknown block type: ${type}`);
  return b;
}

export function blockVersions(): Record<string, string> {
  return Object.fromEntries(ALL_BLOCKS.map((b) => [b.type, b.version]));
}
