import { SCHEMA_VERSION, type DesignGraph, type DraftPayload } from "@tinythings/schema";

export interface TemplateMeta {
  id: string;
  name: string;
  description: string;
  category: "life" | "study" | "mood" | "play";
  batch: 1 | 2;
}

export const TEMPLATES: TemplateMeta[] = [
  {
    id: "love-letter", name: "给你的一点小心意", description: "摇一颗小骰子，解锁一封想对 TA 说的话。", category: "mood", batch: 1,
  },
  {
    id: "daily-checkin",
    name: "每日打卡器",
    description: "按 Asia/Shanghai 日期规则记录连续天数，同日不可重复。",
    category: "life",
    batch: 1,
  },
  {
    id: "habit-builder",
    name: "习惯养成器",
    description: "按钮 + 计数 + 进度条，目标默认 30 天。",
    category: "life",
    batch: 1,
  },
  {
    id: "random-task-box",
    name: "随机任务箱",
    description: "任务清单 + 随机模块，拒绝采样抽取。",
    category: "play",
    batch: 1,
  },
  {
    id: "countdown",
    name: "倒计时",
    description: "固定到期点倒计时。",
    category: "study",
    batch: 2,
  },
  {
    id: "future-letter",
    name: "未来信件",
    description: "到了设定日子才能拆开的信封。",
    category: "mood",
    batch: 2,
  },
  {
    id: "dice-letter",
    name: "骰子开信",
    description: "掷出三个 6 才能读到信封里的话。",
    category: "play",
    batch: 1,
  },
  {
    id: "mood-button",
    name: "情绪按钮",
    description: "从预置短句中选择情绪回应。",
    category: "mood",
    batch: 2,
  },
];

export function templateGraph(id: string): DesignGraph {
  switch (id) {
    case "love-letter": {
      const base = templateGraph("dice-letter");
      return { ...base, nodes: base.nodes.map((n) => n.type === "envelope" ? { ...n, config: { ...n.config, signalRule: "sum", needSignals: 12, recipient: "最可爱的你", sender: "", letterTitle: "有你在，日子就闪闪发光", body: "想把今天的小事，都讲给你听。\n\n也想把明天的好天气，和每一个平凡的日子，都留一个位置给你。\n\n如果你看到这里，我想说：\n遇见你，是我最喜欢的小概率事件。♡" } } : n) };
    }
    case "daily-checkin":
      return {
        schemaVersion: SCHEMA_VERSION,
        stateScope: "perUser",
        nodes: [
          {
            id: "btn",
            type: "button",
            version: "1.0.0",
            config: { label: "打卡!", action: "checkIn", targetNodeId: "streak" },
            position: { x: 80, y: 140 },
          },
          {
            id: "gate",
            type: "dateGate",
            version: "1.0.0",
            config: { timezone: "Asia/Shanghai" },
            position: { x: 320, y: 140 },
          },
          {
            id: "streak",
            type: "streakCounter",
            version: "1.0.0",
            config: {},
            position: { x: 560, y: 140 },
          },
        ],
        edges: [
          {
            id: "e1",
            source: "btn",
            sourcePort: "click",
            target: "gate",
            targetPort: "attempt",
            kind: "event",
          },
          {
            id: "e2",
            source: "gate",
            sourcePort: "pass",
            target: "streak",
            targetPort: "checkIn",
            kind: "event",
          },
        ],
      };
    case "habit-builder":
      return {
        schemaVersion: SCHEMA_VERSION,
        stateScope: "perUser",
        nodes: [
          {
            id: "btn",
            type: "button",
            version: "1.0.0",
            config: { label: "完成一次", action: "increment", targetNodeId: "cnt" },
            position: { x: 80, y: 120 },
          },
          {
            id: "cnt",
            type: "counter",
            version: "1.0.0",
            config: { initial: 0, step: 1, bits: 16, overflow: "saturate" },
            position: { x: 340, y: 120 },
          },
          {
            id: "bar",
            type: "progress",
            version: "1.0.0",
            config: { target: 30 },
            position: { x: 600, y: 120 },
          },
        ],
        edges: [
          {
            id: "e1",
            source: "btn",
            sourcePort: "click",
            target: "cnt",
            targetPort: "increment",
            kind: "event",
          },
          {
            id: "e2",
            source: "cnt",
            sourcePort: "value",
            target: "bar",
            targetPort: "value",
            kind: "data",
          },
        ],
      };
    case "random-task-box":
      return {
        schemaVersion: SCHEMA_VERSION,
        stateScope: "perUser",
        nodes: [
          {
            id: "list",
            type: "checklist",
            version: "1.0.0",
            config: {
              items: ["整理桌面", "回复一封邮件", "散步 10 分钟", "喝杯水", "伸个懒腰"],
            },
            position: { x: 60, y: 80 },
          },
          {
            id: "btn",
            type: "button",
            version: "1.0.0",
            config: { label: "抽一个!", action: "draw", targetNodeId: "box" },
            position: { x: 60, y: 240 },
          },
          {
            id: "box",
            type: "randomBox",
            version: "1.0.0",
            config: {
              items: ["整理桌面", "回复一封邮件", "散步 10 分钟", "喝杯水", "伸个懒腰"],
              noRepeat: true,
            },
            position: { x: 360, y: 180 },
          },
          {
            id: "txt",
            type: "text",
            version: "1.0.0",
            config: { content: "今天的小任务会显示在这里" },
            position: { x: 620, y: 180 },
          },
        ],
        edges: [
          {
            id: "e1",
            source: "btn",
            sourcePort: "click",
            target: "box",
            targetPort: "draw",
            kind: "event",
          },
        ],
      };
    case "countdown":
      return {
        schemaVersion: SCHEMA_VERSION,
        stateScope: "perDevice",
        nodes: [
          {
            id: "btn",
            type: "button",
            version: "1.0.0",
            config: { label: "开始", action: "start", targetNodeId: "tmr" },
            position: { x: 100, y: 140 },
          },
          {
            id: "tmr",
            type: "timer",
            version: "1.0.0",
            config: { durationSec: 1500 },
            position: { x: 380, y: 140 },
          },
        ],
        edges: [
          {
            id: "e1",
            source: "btn",
            sourcePort: "click",
            target: "tmr",
            targetPort: "start",
            kind: "event",
          },
        ],
      };
    case "future-letter":
      return {
        schemaVersion: SCHEMA_VERSION,
        stateScope: "perUser",
        nodes: [
          {
            id: "env",
            type: "envelope",
            version: "1.0.0",
            config: {
              unlockMode: "time",
              unlockAt: Date.now() + 30 * 86400000,
              body: "给三十天后的自己：请记得你今天的勇气。",
            },
            position: { x: 200, y: 140 },
          },
          {
            id: "btn",
            type: "button",
            version: "1.0.0",
            config: { label: "打开信件", action: "open", targetNodeId: "env" },
            position: { x: 200, y: 300 },
          },
        ],
        edges: [
          {
            id: "e1",
            source: "btn",
            sourcePort: "click",
            target: "env",
            targetPort: "open",
            kind: "event",
          },
        ],
      };
    case "dice-letter":
      return {
        schemaVersion: SCHEMA_VERSION,
        stateScope: "perUser",
        nodes: [
          {
            id: "roll",
            type: "button",
            version: "1.0.0",
            config: { label: "掷骰子", action: "draw", targetNodeId: "dice" },
            position: { x: 60, y: 100 },
          },
          {
            id: "dice",
            type: "randomBox",
            version: "1.0.0",
            config: {
              mode: "dice",
              items: ["1", "2", "3", "4", "5", "6"],
              noRepeat: false,
            },
            position: { x: 300, y: 100 },
          },
          {
            id: "env",
            type: "envelope",
            version: "1.0.0",
            config: {
              unlockMode: "signals",
              needSignals: 3,
              matchPayload: "6",
              body: "三颗六点亮起时：把这句话念给自己听——你值得被温柔对待。",
            },
            position: { x: 560, y: 80 },
          },
          {
            id: "read",
            type: "button",
            version: "1.0.0",
            config: { label: "读信", action: "open", targetNodeId: "env" },
            position: { x: 560, y: 280 },
          },
        ],
        edges: [
          {
            id: "e1",
            source: "roll",
            sourcePort: "click",
            target: "dice",
            targetPort: "draw",
            kind: "event",
          },
          {
            id: "e2",
            source: "dice",
            sourcePort: "picked",
            target: "env",
            targetPort: "signal",
            kind: "event",
          },
          {
            id: "e3",
            source: "read",
            sourcePort: "click",
            target: "env",
            targetPort: "open",
            kind: "event",
          },
        ],
      };
    case "mood-button":
      return {
        schemaVersion: SCHEMA_VERSION,
        stateScope: "perDevice",
        nodes: [
          {
            id: "btn",
            type: "button",
            version: "1.0.0",
            config: { label: "今天心情", action: "draw", targetNodeId: "box" },
            position: { x: 120, y: 140 },
          },
          {
            id: "box",
            type: "randomBox",
            version: "1.0.0",
            config: {
              items: [
                "深呼吸三次，慢慢来。",
                "给自己倒杯温水。",
                "你已经很努力了。",
                "去看看窗外的光。",
              ],
              noRepeat: false,
            },
            position: { x: 400, y: 140 },
          },
        ],
        edges: [
          {
            id: "e1",
            source: "btn",
            sourcePort: "click",
            target: "box",
            targetPort: "draw",
            kind: "event",
          },
        ],
      };
    default:
      return {
        schemaVersion: SCHEMA_VERSION,
        nodes: [],
        edges: [],
        stateScope: "perUser",
      };
  }
}

export function draftFromTemplate(id: string): DraftPayload {
  const meta = TEMPLATES.find((t) => t.id === id);
  return {
    schemaVersion: SCHEMA_VERSION,
    name: meta?.name ?? "未命名小东西",
    graph: templateGraph(id),
    layout: { viewport: { x: 0, y: 0, zoom: 1 } },
    theme: { accent: "#9274DD", surface: "#FFFCFF", ...(id === "love-letter" ? { music: "musicbox" as const } : {}) },
    revision: 0,
  };
}
