import type { CompileSupport, PortDef, ValueType } from "@tinythings/schema";

export type EffectKind =
  | "save"
  | "notify"
  | "requestRandom"
  | "readClock"
  | "callCircuit";

export interface RuntimeContext {
  clock: () => number;
  random: () => number;
  timezone: string;
  dayIndex: (ts: number) => number;
}

export interface ReduceResult {
  nextState: Record<string, unknown>;
  emittedEvents: Array<{ port: string; payload?: unknown }>;
  effects: Array<{ kind: EffectKind; payload?: unknown }>;
}

export type ReduceFn = (
  state: Record<string, unknown>,
  event: { port: string; payload?: unknown } | null,
  config: Record<string, unknown>,
  context: RuntimeContext,
  inputs: Record<string, unknown>
) => ReduceResult;

export interface BlockDefinition {
  type: string;
  label: string;
  group: "core" | "rule" | "extended" | "template";
  description: string;
  version: string;
  color: string;
  icon: string;
  inputPorts: PortDef[];
  outputPorts: PortDef[];
  defaultConfig: Record<string, unknown>;
  defaultState: Record<string, unknown>;
  compileSupport: CompileSupport;
  compileBits?: { state?: number; in?: number; out?: number };
  reduce: ReduceFn;
}

export function port(
  id: string,
  label: string,
  direction: "in" | "out",
  kind: "event" | "data" | "state",
  valueType: ValueType,
  opts?: Partial<Pick<PortDef, "required" | "cardinality">>
): PortDef {
  return {
    id,
    label,
    direction,
    kind,
    valueType,
    required: opts?.required ?? false,
    cardinality: opts?.cardinality ?? "one",
  };
}
