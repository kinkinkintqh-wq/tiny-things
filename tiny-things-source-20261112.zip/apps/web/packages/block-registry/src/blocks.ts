import type { BlockDefinition } from './types';
import { port } from './types';

function clampUint(value: number, bits: number, overflow: "saturate" | "error") {
  const max = 2 ** bits - 1;
  if (value < 0) {
    if (overflow === "error") throw new Error("underflow");
    return 0;
  }
  if (value > max) {
    if (overflow === "error") throw new Error("overflow");
    return max;
  }
  return value;
}

export const buttonBlock: BlockDefinition = {
  type: "button",
  label: "按钮",
  group: "core",
  description: "点击后发出事件，可驱动计数器、开关或弹出文字。",
  version: "1.0.0",
  color: "#F1B0C9",
  icon: "button",
  inputPorts: [],
  outputPorts: [port("click", "点击", "out", "event", "event")],
  defaultConfig: {
    label: "点我!",
    action: "increment",
    targetNodeId: null as string | null,
  },
  defaultState: {},
  compileSupport: "combinational",
  reduce: (_state, event) => {
    const port = event?.port;
    const fired = port === "press" || port === "click" || port === "tap";
    return {
      nextState: {},
      emittedEvents: fired ? [{ port: "click" }] : [],
      effects: [],
    };
  },
};

export const switchBlock: BlockDefinition = {
  type: "switch",
  label: "开关",
  group: "core",
  description: "布尔开关，可被事件切换。",
  version: "1.0.0",
  color: "#CBE6CF",
  icon: "switch",
  inputPorts: [
    port("toggle", "切换", "in", "event", "event", { cardinality: "many" }),
    port("setTrue", "打开", "in", "event", "event", { cardinality: "many" }),
    port("setFalse", "关闭", "in", "event", "event", { cardinality: "many" }),
  ],
  outputPorts: [
    port("value", "状态", "out", "data", "bool"),
    port("changed", "变化", "out", "event", "event"),
  ],
  defaultConfig: { initial: false },
  defaultState: { on: false },
  compileSupport: "transition",
  compileBits: { state: 1, in: 2, out: 1 },
  reduce: (state, event, config) => {
    let on = Boolean(state.on ?? config.initial ?? false);
    let changed = false;
    if (event?.port === "toggle") {
      on = !on;
      changed = true;
    } else if (event?.port === "setTrue") {
      changed = !on;
      on = true;
    } else if (event?.port === "setFalse") {
      changed = on;
      on = false;
    }
    return {
      nextState: { on },
      emittedEvents: changed ? [{ port: "changed", payload: on }] : [],
      effects: [],
    };
  },
};

export const counterBlock: BlockDefinition = {
  type: "counter",
  label: "计数器",
  group: "core",
  description: "无符号计数，支持饱和或溢出报错。",
  version: "1.0.0",
  color: "#B8D4F4",
  icon: "counter",
  inputPorts: [
    port("increment", "+1", "in", "event", "event", { cardinality: "many" }),
    port("decrement", "-1", "in", "event", "event", { cardinality: "many" }),
    port("reset", "重置", "in", "event", "event", { cardinality: "many" }),
  ],
  outputPorts: [port("value", "数值", "out", "data", "uint16")],
  defaultConfig: {
    initial: 0,
    step: 1,
    bits: 16,
    overflow: "saturate" as "saturate" | "error",
  },
  defaultState: { value: 0 },
  compileSupport: "transition",
  compileBits: { state: 16, in: 2, out: 16 },
  reduce: (state, event, config) => {
    const bits = Number(config.bits ?? 16);
    const step = Number(config.step ?? 1);
    const overflow = (config.overflow as "saturate" | "error") ?? "saturate";
    let value = Number(state.value ?? config.initial ?? 0);
    if (event?.port === "reset") value = Number(config.initial ?? 0);
    else if (event?.port === "increment")
      value = clampUint(value + step, bits, overflow);
    else if (event?.port === "decrement")
      value = clampUint(value - step, bits, overflow);
    return { nextState: { value }, emittedEvents: [], effects: [] };
  },
};

export const textBlock: BlockDefinition = {
  type: "text",
  label: "文本",
  group: "core",
  description: "显示纯文本，支持白名单变量插值。",
  version: "1.0.0",
  color: "#E8E0F5",
  icon: "text",
  inputPorts: [port("show", "显示", "in", "event", "event", { cardinality: "many" })],
  outputPorts: [port("content", "内容", "out", "data", "string")],
  defaultConfig: { content: "你好，小东西", maxLength: 2000 },
  defaultState: { visible: true },
  compileSupport: "hostOnly",
  reduce: (state, event, config) => {
    const content = String(config.content ?? "").slice(0, Number(config.maxLength ?? 2000));
    return {
      nextState: {
        visible: event?.port === "show" ? true : Boolean(state.visible ?? true),
        content,
      },
      emittedEvents: [],
      effects: event?.port === "show" ? [{ kind: "notify", payload: content }] : [],
    };
  },
};

export const conditionBlock: BlockDefinition = {
  type: "condition",
  label: "条件判断",
  group: "rule",
  description: "比较两个同类型操作数，分流 true / false。",
  version: "1.0.0",
  color: "#D4C4F0",
  icon: "condition",
  inputPorts: [
    port("trigger", "触发", "in", "event", "event", { cardinality: "many" }),
    port("left", "左值", "in", "data", "uint16"),
    port("right", "右值", "in", "data", "uint16"),
  ],
  outputPorts: [
    port("then", "为真", "out", "event", "event"),
    port("else", "为假", "out", "event", "event"),
    port("result", "结果", "out", "data", "bool"),
  ],
  defaultConfig: {
    op: "eq" as "eq" | "lt" | "gt" | "lte" | "gte" | "neq",
    rightConst: 0,
  },
  defaultState: { result: false },
  compileSupport: "combinational",
  reduce: (state, event, config, _ctx, inputs) => {
    const left = Number(inputs.left ?? 0);
    const right =
      inputs.right !== undefined && inputs.right !== null
        ? Number(inputs.right)
        : Number(config.rightConst ?? 0);
    const op = String(config.op ?? "eq");
    let result = false;
    switch (op) {
      case "lt":
        result = left < right;
        break;
      case "gt":
        result = left > right;
        break;
      case "lte":
        result = left <= right;
        break;
      case "gte":
        result = left >= right;
        break;
      case "neq":
        result = left !== right;
        break;
      default:
        result = left === right;
    }
    const emitted =
      event?.port === "trigger"
        ? [{ port: result ? "then" : "else", payload: result }]
        : [];
    return { nextState: { result }, emittedEvents: emitted, effects: [] };
  },
};

export const progressBlock: BlockDefinition = {
  type: "progress",
  label: "进度条",
  group: "core",
  description: "按目标值显示百分比，不写回截断值。",
  version: "1.0.0",
  color: "#F5D0A9",
  icon: "progress",
  inputPorts: [port("value", "当前值", "in", "data", "uint16")],
  outputPorts: [
    port("ratio", "比例", "out", "data", "uint16"),
    port("done", "完成", "out", "data", "bool"),
  ],
  defaultConfig: { target: 30 },
  defaultState: { ratio: 0, done: false },
  compileSupport: "hostOnly",
  reduce: (_state, _event, config, _ctx, inputs) => {
    const target = Math.max(1, Math.min(65535, Number(config.target ?? 30)));
    const value = Number(inputs.value ?? 0);
    const ratio = Math.min(100, Math.floor((value / target) * 100));
    const done = value >= target;
    return { nextState: { ratio, done, value, target }, emittedEvents: [], effects: [] };
  },
};

export const timerBlock: BlockDefinition = {
  type: "timer",
  label: "计时器",
  group: "extended",
  description: "倒计时到固定 UTC 到期点；宿主提供时钟。",
  version: "1.0.0",
  color: "#F5E6B8",
  icon: "timer",
  inputPorts: [port("start", "开始", "in", "event", "event", { cardinality: "many" })],
  outputPorts: [
    port("remaining", "剩余秒", "out", "data", "uint32"),
    port("done", "到期", "out", "event", "event"),
  ],
  defaultConfig: { durationSec: 60 },
  defaultState: { deadline: null as number | null, fired: false },
  compileSupport: "hostOnly",
  reduce: (state, event, config, context) => {
    let deadline = state.deadline as number | null;
    let fired = Boolean(state.fired);
    if (event?.port === "start") {
      deadline = context.clock() + Number(config.durationSec ?? 60) * 1000;
      fired = false;
    }
    const remaining =
      deadline == null ? 0 : Math.max(0, Math.ceil((deadline - context.clock()) / 1000));
    const emitted =
      deadline != null && remaining === 0 && !fired ? [{ port: "done" }] : [];
    if (emitted.length) fired = true;
    return {
      nextState: { deadline, fired, remaining },
      emittedEvents: emitted,
      effects: [{ kind: "readClock" }],
    };
  },
};

export const randomBoxBlock: BlockDefinition = {
  type: "randomBox",
  label: "随机盒子",
  group: "extended",
  description: "抽签或骰子：抽出一项并广播结果，可驱动信封/条件。",
  version: "1.0.0",
  color: "#C9B8F0",
  icon: "random",
  inputPorts: [
    port("draw", "抽取", "in", "event", "event", { cardinality: "many" }),
    port("reset", "重置", "in", "event", "event", { cardinality: "many" }),
  ],
  outputPorts: [
    port("picked", "抽中", "out", "event", "event"),
    port("text", "文案", "out", "data", "string"),
    port("value", "数值", "out", "data", "uint16"),
  ],
  defaultConfig: {
    mode: "list" as "list" | "dice",
    items: ["喝杯水", "伸个懒腰", "写三行日记"] as string[],
    noRepeat: true,
  },
  defaultState: {
    remaining: [] as string[],
    last: null as string | null,
    value: 0,
  },
  compileSupport: "hostOnly",
  reduce: (state, event, config, context) => {
    const mode = String(config.mode ?? "list");
    const diceItems = ["1", "2", "3", "4", "5", "6"];
    const items =
      mode === "dice"
        ? diceItems
        : ((config.items as string[] | undefined)?.slice(0, 100) ?? []);
    const noRepeat = mode === "dice" ? false : Boolean(config.noRepeat);
    let remaining =
      (state.remaining as string[] | undefined)?.length
        ? (state.remaining as string[])
        : [...items];
    let last = (state.last as string | null) ?? null;
    let value = Number(state.value ?? 0);
    const emitted: Array<{ port: string; payload?: unknown }> = [];
    if (event?.port === "reset") {
      remaining = [...items];
      last = null;
      value = 0;
    } else if (event?.port === "draw") {
      const pool = noRepeat ? remaining : items;
      if (pool.length === 0) {
        return {
          nextState: { remaining, last, value },
          emittedEvents: [],
          effects: [],
        };
      }
      const max = pool.length;
      const limit = Math.floor(0xffffffff / max) * max;
      let r = 0;
      do {
        r = Math.floor(context.random() * 0x100000000);
      } while (r >= limit);
      const idx = r % max;
      last = pool[idx] ?? null;
      value = Number.parseInt(String(last), 10);
      if (Number.isNaN(value)) value = idx + 1;
      if (noRepeat) remaining = pool.filter((_, i) => i !== idx);
      emitted.push({ port: "picked", payload: last });
    }
    return {
      nextState: { remaining, last, value },
      emittedEvents: emitted,
      effects: event?.port === "draw" ? [{ kind: "requestRandom" }] : [],
    };
  },
};

export const envelopeBlock: BlockDefinition = {
  type: "envelope",
  label: "信封",
  group: "extended",
  description:
    "信件可按时间、事件或「凑齐信号」解锁。例如骰子掷出三个 6 再读信。",
  version: "1.0.0",
  color: "#F5E6B8",
  icon: "envelope",
  inputPorts: [
    port("open", "打开", "in", "event", "event", { cardinality: "many" }),
    port("unlock", "解锁", "in", "event", "event", { cardinality: "many" }),
    port("signal", "信号", "in", "event", "event", { cardinality: "many" }),
  ],
  outputPorts: [
    port("locked", "锁定", "out", "data", "bool"),
    port("body", "正文", "out", "data", "string"),
    port("opened", "已打开", "out", "event", "event"),
  ],
  defaultConfig: {
    unlockMode: "event" as "event" | "time" | "signals",
    unlockAt: 0,
    needSignals: 3,
    matchPayload: "6",
    body: "给未来的自己：你好。",
  },
  defaultState: {
    opened: false,
    unlocked: false,
    locked: true,
    signalCount: 0,
  },
  compileSupport: "hostOnly",
  reduce: (state, event, config, context) => {
    const mode = String(config.unlockMode ?? "event");
    const need = Math.max(1, Math.min(99, Number(config.needSignals ?? 3)));
    const match = String(config.matchPayload ?? "").trim();
    let unlocked = Boolean(state.unlocked);
    let opened = Boolean(state.opened);
    let signalCount = Number(state.signalCount ?? 0);
    const emitted: Array<{ port: string; payload?: unknown }> = [];

    if (mode === "time") {
      const unlockAt = Number(config.unlockAt ?? 0);
      unlocked = unlockAt <= 0 || context.clock() >= unlockAt;
    }

    if (event?.port === "unlock") {
      unlocked = true;
    }

    if (event?.port === "signal" && !unlocked) {
      const payload = event.payload == null ? "" : String(event.payload);
      if (config.signalRule === "sum") {
        const points = Number(payload);
        if (Number.isInteger(points) && points >= 1 && points <= 6) signalCount = Math.min(need, signalCount + points);
      } else if (!match || payload === match) {
        signalCount = Math.min(need, signalCount + 1);
      }
      if (signalCount >= need) unlocked = true;
    }

    if (event?.port === "open") {
      if (unlocked && !opened) {
        opened = true;
        emitted.push({ port: "opened" });
      }
    }

    // Auto-open when unlocked by signal/unlock if already trying
    if (unlocked && event?.port === "signal" && mode === "signals" && signalCount >= need) {
      // stay closed until user opens, unless config autoOpen
      if (config.autoOpen) {
        opened = true;
        emitted.push({ port: "opened" });
      }
    }

    const locked = !unlocked;
    return {
      nextState: {
        opened,
        unlocked,
        locked,
        signalCount,
        need,
        match,
        body: opened && unlocked ? String(config.body ?? "") : "",
      },
      emittedEvents: emitted,
      effects: [],
    };
  },
};

export const dateGateBlock: BlockDefinition = {
  type: "dateGate",
  label: "日期门",
  group: "rule",
  description: "按 IANA 时区日索引门控同日重复。",
  version: "1.0.0",
  color: "#B8D4F4",
  icon: "calendar",
  inputPorts: [port("attempt", "尝试", "in", "event", "event", { cardinality: "many" })],
  outputPorts: [
    port("pass", "通过", "out", "event", "event"),
    port("reject", "拒绝", "out", "event", "event"),
  ],
  defaultConfig: { timezone: "Asia/Shanghai" },
  defaultState: { lastDay: null as number | null },
  compileSupport: "transition",
  compileBits: { state: 32, in: 1, out: 1 },
  reduce: (state, event, _config, context) => {
    if (event?.port !== "attempt") {
      return { nextState: state, emittedEvents: [], effects: [] };
    }
    const today = context.dayIndex(context.clock());
    const lastDay = state.lastDay as number | null;
    if (lastDay === today) {
      return {
        nextState: state,
        emittedEvents: [{ port: "reject", payload: { reason: "same_day" } }],
        effects: [{ kind: "readClock" }],
      };
    }
    return {
      nextState: { lastDay: today },
      emittedEvents: [{ port: "pass", payload: { day: today, prev: lastDay } }],
      effects: [{ kind: "save" }, { kind: "readClock" }],
    };
  },
};

export const streakBlock: BlockDefinition = {
  type: "streakCounter",
  label: "连续天数",
  group: "rule",
  description: "根据日期门通过事件更新连续天数与总次数。",
  version: "1.0.0",
  color: "#F1B0C9",
  icon: "streak",
  inputPorts: [port("checkIn", "打卡", "in", "event", "event", { cardinality: "many" })],
  outputPorts: [
    port("streak", "连续", "out", "data", "uint16"),
    port("total", "总计", "out", "data", "uint16"),
  ],
  defaultConfig: {},
  defaultState: { streak: 0, total: 0, lastDay: null as number | null },
  compileSupport: "transition",
  reduce: (state, event, _config, context) => {
    if (event?.port !== "checkIn") {
      return { nextState: state, emittedEvents: [], effects: [] };
    }
    const today = context.dayIndex(context.clock());
    const lastDay = state.lastDay as number | null;
    let streak = Number(state.streak ?? 0);
    let total = Number(state.total ?? 0);
    if (lastDay === today) {
      return { nextState: state, emittedEvents: [], effects: [] };
    }
    if (lastDay != null && today === lastDay + 1) streak += 1;
    else streak = 1;
    total += 1;
    return {
      nextState: { streak, total, lastDay: today },
      emittedEvents: [],
      effects: [{ kind: "save" }],
    };
  },
};

export const checklistBlock: BlockDefinition = {
  type: "checklist",
  label: "任务清单",
  group: "extended",
  description: "1–100 项任务，供随机盒子使用。",
  version: "1.0.0",
  color: "#CBE6CF",
  icon: "list",
  inputPorts: [],
  outputPorts: [port("items", "列表", "out", "data", "string")],
  defaultConfig: {
    items: ["整理桌面", "回复一封邮件", "散步 10 分钟"],
  },
  defaultState: {},
  compileSupport: "hostOnly",
  reduce: (_s, _e, config) => ({
    nextState: { items: config.items ?? [] },
    emittedEvents: [],
    effects: [],
  }),
};

export const proofCardBlock: BlockDefinition = {
  type: "proofCard",
  label: "证明卡",
  group: "extended",
  description: "展示 manifestHash / 作者地址 / 链与区块时间（非实名证明）。",
  version: "1.0.0",
  color: "#E1D8EE",
  icon: "proof",
  inputPorts: [],
  outputPorts: [port("hash", "哈希", "out", "data", "string")],
  defaultConfig: { manifestHash: "", author: "", chainId: 196 },
  defaultState: {},
  compileSupport: "hostOnly",
  reduce: (_s, _e, config) => ({
    nextState: { ...config },
    emittedEvents: [],
    effects: [],
  }),
};

export const ALL_BLOCKS: BlockDefinition[] = [
  buttonBlock,
  switchBlock,
  counterBlock,
  textBlock,
  conditionBlock,
  progressBlock,
  timerBlock,
  randomBoxBlock,
  envelopeBlock,
  dateGateBlock,
  streakBlock,
  checklistBlock,
  proofCardBlock,
];
