# Tiny Things 主应用

从本目录运行 `npm ci` 和 `npm run dev`，访问 http://127.0.0.1:3846 。

本机制作、保存、预览、导入导出与快照链接不需要数据库。完整启动、验证、分享边界与可选社区服务说明见仓库根目录 README.md；最新进度见 PROJECT-STATUS.md。
