import type { NextConfig } from "next";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.dirname(fileURLToPath(import.meta.url));

const aliases: Record<string, string> = {
  "@tinythings/schema": path.join(root, "packages/schema/src/index.ts"),
  "@tinythings/block-registry": path.join(root, "packages/block-registry/src/index.ts"),
  "@tinythings/runtime": path.join(root, "packages/runtime/src/index.ts"),
  "@tinythings/compiler": path.join(root, "packages/compiler/src/index.ts"),
  "@tinythings/ui": path.join(root, "packages/ui/src/index.ts"),
};

const nextConfig: NextConfig = {
  distDir: process.env.TINYTHINGS_BUILD_DIR || ".next",
  output: "standalone",
  outputFileTracingRoot: path.join(root, "../.."),
  // Hide the Next.js "N" corner badge in local/dev — not part of Tiny Things UI.
  devIndicators: false,
  images: {
    unoptimized: true,
  },
  experimental: {
    externalDir: true,
  },
  turbopack: {
    resolveAlias: {
      "@tinythings/schema": "./packages/schema/src/index.ts",
      "@tinythings/block-registry": "./packages/block-registry/src/index.ts",
      "@tinythings/runtime": "./packages/runtime/src/index.ts",
      "@tinythings/compiler": "./packages/compiler/src/index.ts",
      "@tinythings/ui": "./packages/ui/src/index.ts",
    },
  },
  serverExternalPackages: ["postgres"],
  webpack: (config) => {
    config.resolve.alias = {
      ...config.resolve.alias,
      ...aliases,
    };
    return config;
  },
};

export default nextConfig;
