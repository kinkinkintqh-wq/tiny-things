"""Package a relocatable Next standalone runtime. No keys, env files, or Mac binaries."""
from pathlib import Path
import hashlib,json,shutil,tarfile
ROOT=Path(__file__).resolve().parents[1]
BUILD=ROOT/'apps/web/.next-tokyo'
DEST=ROOT/'outputs/tiny-things-runtime-20261112'
if DEST.exists():
    raise SystemExit('Release folder already exists; choose a new version instead of overwriting it')
shutil.copytree(BUILD/'standalone',DEST,symlinks=True,ignore=shutil.ignore_patterns('.env*','*.pem','*.key','.DS_Store'))
APP=DEST/'apps/web'
shutil.copytree(ROOT/'apps/web/public',APP/'public')
shutil.copytree(BUILD/'static',APP/'.next-tokyo/static')
# images.unoptimized is true. Next returns 404 before calling Sharp on /_next/image.
# Drop optional Mac-only Sharp artifacts; production uses the original static images.
for d in (APP/'node_modules/@img').glob('*darwin*'):
    if d.is_dir():shutil.rmtree(d)
for p in DEST.rglob('*'):
    if p.is_symlink() and not p.resolve().is_relative_to(DEST.resolve()):
        raise SystemExit('Release has an external symlink: '+str(p.relative_to(DEST)))
    if p.is_file() and p.suffix in {'.node','.dylib','.pem','.key'}:
        raise SystemExit('Release has an unexpected native or private file: '+str(p.relative_to(DEST)))
manifest={str(p.relative_to(DEST)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(DEST.rglob('*')) if p.is_file()}
(DEST/'RUNTIME-SHA256.json').write_text(json.dumps(manifest,indent=2)+'\n')
(DEST/'RELEASE.json').write_text(json.dumps({'version':'20261112','buildId':(BUILD/'BUILD_ID').read_text().strip(),'entry':'apps/web/server.js','requires':'Existing compatible Linux Node.js runtime; server architecture/runtime verification pending','images':'Original static assets; runtime optimization disabled','chainStatus':'No own circuits deployed by this release yet'},indent=2)+'\n')
archive=DEST.with_suffix('.tar.gz')
with tarfile.open(archive,'w:gz') as t:t.add(DEST,arcname=DEST.name)
print(json.dumps({'files':len(manifest),'archive':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}))
