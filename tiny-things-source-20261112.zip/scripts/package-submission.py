# -*- coding: utf-8 -*-
"""Build a source handoff from an explicit allowlist; no deployment credentials/history."""
from pathlib import Path
import hashlib,json,re,zipfile
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'outputs/submission-20261112'
OUT.mkdir(parents=True,exist_ok=True)
skip={'node_modules','outputs','work','.git','.codex','.agents','__pycache__'}
files=[]
for folder in ['apps','packages','services']:
 for p in (ROOT/folder).rglob('*'):
  rel=p.relative_to(ROOT)
  if not p.is_file() or p.is_symlink() or any(s in skip or s.startswith('.next') for s in rel.parts):continue
  if p.name.startswith('.env') and p.name not in {'.env.example','.env.sample'}:continue
  if p.suffix in {'.tsbuildinfo','.key','.pem','.log'} or p.name=='.DS_Store':continue
  files.append(p)
for name in ['README.md','package.json','pnpm-workspace.yaml','tsconfig.base.json','DEPLOYMENT.md']:
 files.append(ROOT/name)
files+=list((ROOT/'submission').glob('*.md'))
files+=list((ROOT/'scripts').glob('*.py'))
files+=list((ROOT/'verification/letter-circuits').glob('*'))
files+=list((ROOT/'verification/tapeout-preflight').glob('*.hex'))
files+=[ROOT/'verification/tapeout-preflight/unsigned-plan.json',ROOT/'verification/tapeout-preflight/unsigned-plan.sha256']
files.append(ROOT/'outputs/tiny-things-logo-256.png')
files=sorted(set(p for p in files if p.is_file()))
suspect=[]
for p in files:
 if p.suffix in {'.ts','.tsx','.js','.mjs','.json','.md','.yaml','.yml','.example','.sample'}:
  txt=p.read_text(errors='replace')
  if re.search(r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}',txt):suspect.append(str(p.relative_to(ROOT)))
if suspect:raise SystemExit('Review required before publishing: '+', '.join(suspect))
manifest={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
archive=OUT/'tiny-things-source-20261112.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,p.relative_to(ROOT))
 z.writestr('SOURCE-SHA256.json',json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
summary={'archive':archive.name,'files':len(files),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'note':'Allowlist package; code scan is not an exhaustive security audit. Formal tapeout and public runtime verification pending.'}
(OUT/'SOURCE-PACKAGE.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False))
