import type { MiddlewareHandler } from "hono";
import { getCookie, setCookie } from "hono/cookie";
import { nanoid } from "nanoid";
import { db } from "../db/client.js";
import { users } from "../db/schema.js";
import { eq } from "drizzle-orm";

export type AppVars = {
  requestId: string;
  userId: string;
  displayName: string;
};

export const withRequestId: MiddlewareHandler = async (c, next) => {
  const id = c.req.header("x-request-id") ?? nanoid(12);
  c.set("requestId", id);
  c.header("x-request-id", id);
  await next();
};

/** Dev-friendly session: cookie user id, auto-create guest-capable account. */
export const withSession: MiddlewareHandler = async (c, next) => {
  let userId = getCookie(c, "tt_uid");
  if (!userId) {
    userId = `u_${nanoid(10)}`;
    const displayName = `创作者${userId.slice(-4)}`;
    await db.insert(users).values({ id: userId, displayName }).onConflictDoNothing();
    setCookie(c, "tt_uid", userId, {
      path: "/",
      httpOnly: true,
      sameSite: "Lax",
      secure: process.env.COOKIE_SECURE === "true",
      maxAge: 60 * 60 * 24 * 365,
    });
    c.set("userId", userId);
    c.set("displayName", displayName);
  } else {
    const existing = await db.select().from(users).where(eq(users.id, userId)).limit(1);
    if (!existing[0]) {
      const displayName = `创作者${userId.slice(-4)}`;
      await db.insert(users).values({ id: userId, displayName });
      c.set("displayName", displayName);
    } else {
      c.set("displayName", existing[0].displayName);
    }
    c.set("userId", userId);
  }
  await next();
};
