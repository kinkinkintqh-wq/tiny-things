import { compileGraph, encodeNetlist } from "@tinythings/compiler";
import type { DesignGraph } from "@tinythings/schema";
import {
  estimateTapeoutCost,
  probeChain,
  tryCircuitInfo,
  TAPEOUT_CANDIDATES,
} from "@tinythings/tapeout-adapter";
import { eq } from "drizzle-orm";
import { Hono } from "hono";
import { nanoid } from "nanoid";
import { db } from "../db/client.js";
import { anchors, compilations, releases } from "../db/schema.js";
import { apiError } from "../lib/errors.js";
import { manifestHash } from "../lib/hash.js";

export const compileRoutes = new Hono();

compileRoutes.post("/compilations", async (c) => {
  const body = await c.req.json();
  const graph = body.graph as DesignGraph | undefined;
  if (!graph?.nodes) return apiError(c, 400, "bad_request", "需要 graph");

  const sourceHash = manifestHash(graph);
  const id = `cmp_${nanoid(10)}`;
  const result = compileGraph(graph);
  const encoded = result.netlist ? Buffer.from(encodeNetlist(result.netlist)).toString("hex") : null;

  await db.insert(compilations).values({
    id,
    ownerId: c.get("userId") as string,
    sourceHash,
    status: "succeeded",
    result: {
      ...result,
      netlistHex: encoded,
      compilerVersion: "tiny-compiler/0.1.0",
    },
  });

  return c.json(
    {
      jobId: id,
      status: "succeeded",
      sourceHash,
      diagnostics: result.ir.diagnostics,
      report: result.report,
      netlist: result.netlist
        ? {
            nIn: result.netlist.nIn,
            nOut: result.netlist.nOut,
            nState: result.netlist.nState,
            gateCount: result.netlist.gates.length,
            hex: encoded,
          }
        : null,
      ir: result.ir,
    },
    202
  );
});

compileRoutes.get("/compilations/:id", async (c) => {
  const id = c.req.param("id");
  const rows = await db.select().from(compilations).where(eq(compilations.id, id)).limit(1);
  const row = rows[0];
  if (!row) return apiError(c, 404, "not_found", "编译任务不存在");
  if (row.ownerId !== c.get("userId")) return apiError(c, 403, "forbidden", "无权查看");
  return c.json({
    jobId: row.id,
    status: row.status,
    sourceHash: row.sourceHash,
    result: row.result,
  });
});

compileRoutes.post("/anchors/prepare", async (c) => {
  const body = await c.req.json();
  const releaseId = String(body.releaseId ?? "");
  const chainId = Number(body.chainId ?? 196);
  const rel = await db.select().from(releases).where(eq(releases.id, releaseId)).limit(1);
  if (!rel[0]) return apiError(c, 404, "not_found", "作品不存在");
  if (chainId !== 196) {
    return apiError(c, 400, "bad_chain", "当前仅支持 X Layer 主网 chainId=196");
  }

  const id = `an_${nanoid(10)}`;
  await db.insert(anchors).values({
    id,
    releaseId,
    chainId,
    registry: null,
    status: "prepared",
    manifestHash: rel[0].manifestHash,
  });

  return c.json({
    anchorId: id,
    chainId,
    manifestHash: rel[0].manifestHash,
    summary: {
      network: "X Layer",
      chainId: 196,
      irreversible: true,
      note: "仅准备调用摘要；实际由用户钱包发送。Registry 需另行部署授权。",
    },
    evidenceProbe: await probeChain(),
  });
});

compileRoutes.post("/tapeout/cost", async (c) => {
  const body = await c.req.json().catch(() => ({}));
  let gateCount = Number(body.gateCount ?? 0);
  let byteLength = Number(body.byteLength ?? 0);
  let nIn = Number(body.nIn ?? 0);
  let nOut = Number(body.nOut ?? 1);
  let nState = Number(body.nState ?? 0);

  if (body.graph) {
    const compiled = compileGraph(body.graph);
    if (compiled.netlist) {
      gateCount = compiled.netlist.gates.length;
      byteLength = encodeNetlist(compiled.netlist).byteLength;
      nIn = compiled.netlist.nIn;
      nOut = compiled.netlist.nOut;
      nState = compiled.netlist.nState;
    } else {
      return c.json({
        ok: false,
        message: "当前图尚未生成可流片网表；请先使用可编译零件（如按钮→计数器）",
        diagnostics: compiled.ir.diagnostics,
        report: compiled.report,
      });
    }
  }

  if (!gateCount && !byteLength) {
    return apiError(c, 400, "bad_request", "需要 graph 或 gateCount/byteLength");
  }

  const estimate = await estimateTapeoutCost({
    gateCount,
    byteLength: byteLength || gateCount * 7,
    nIn,
    nOut: Math.max(1, nOut),
    nState,
    processor: body.processor,
  });

  return c.json({ ok: true, estimate, netlist: { gateCount, byteLength, nIn, nOut, nState } });
});

compileRoutes.get("/tapeout/probe", async (c) => {
  const evidence = await probeChain();
  const processor = (c.req.query("processor") ||
    process.env.TAPEOUT_PROCESSOR ||
    "") as `0x${string}` | "";
  const circuitId = c.req.query("circuitId");
  let circuit = null;
  if (processor && circuitId) {
    circuit = await tryCircuitInfo({
      processor,
      circuitId: BigInt(circuitId),
    });
  }
  return c.json({
    candidates: TAPEOUT_CANDIDATES,
    evidence,
    circuit,
    badgePolicy:
      "只有真实求值匹配时才显示绿色验证标识；候选地址未验证前保持待验证",
  });
});
