import { blockVersions, draftFromTemplate, validateGraph } from "@tinythings/block-registry";
import {
  DraftPayloadSchema,
  ManifestSchema,
  SCHEMA_VERSION,
  createDraft,
  type DesignGraph,
} from "@tinythings/schema";
import { and, desc, eq, isNull, sql } from "drizzle-orm";
import { Hono } from "hono";
import { nanoid } from "nanoid";
import { db } from "../db/client.js";
import {
  drafts,
  projects,
  releases,
  runtimeStates,
  stats,
  users,
} from "../db/schema.js";
import { apiError } from "../lib/errors.js";
import { manifestHash } from "../lib/hash.js";

export const projectRoutes = new Hono();

projectRoutes.get("/me", async (c) => {
  return c.json({
    userId: c.get("userId"),
    displayName: c.get("displayName"),
  });
});

projectRoutes.post("/projects", async (c) => {
  const body = await c.req.json().catch(() => ({}));
  const name = String(body.name ?? "未命名小东西").slice(0, 40);
  const templateId = body.templateId as string | undefined;
  const draftPayload = templateId ? draftFromTemplate(templateId) : createDraft(name);
  if (body.name) draftPayload.name = name;

  const projectId = `p_${nanoid(10)}`;
  const draftId = `d_${nanoid(10)}`;
  const ownerId = c.get("userId") as string;

  await db.insert(projects).values({
    id: projectId,
    ownerId,
    name: draftPayload.name,
    visibility: "private",
    rootProjectId: projectId,
    category: "life",
    description: "",
  });
  await db.insert(drafts).values({
    id: draftId,
    projectId,
    schemaVersion: SCHEMA_VERSION,
    revision: 0,
    graph: draftPayload.graph,
    layout: draftPayload.layout,
    theme: draftPayload.theme,
  });

  return c.json({ projectId, draftId, draft: { ...draftPayload, id: draftId, projectId } }, 201);
});

projectRoutes.get("/drafts/:id", async (c) => {
  const id = c.req.param("id");
  const rows = await db.select().from(drafts).where(eq(drafts.id, id)).limit(1);
  const draft = rows[0];
  if (!draft) return apiError(c, 404, "not_found", "草稿不存在");
  const proj = await db.select().from(projects).where(eq(projects.id, draft.projectId)).limit(1);
  if (!proj[0] || proj[0].ownerId !== c.get("userId")) {
    return apiError(c, 403, "forbidden", "无权访问该草稿");
  }
  return c.json({
    id: draft.id,
    projectId: draft.projectId,
    name: proj[0].name,
    schemaVersion: draft.schemaVersion,
    revision: draft.revision,
    graph: draft.graph,
    layout: draft.layout,
    theme: draft.theme,
    updatedAt: draft.updatedAt,
  });
});

projectRoutes.put("/drafts/:id", async (c) => {
  const id = c.req.param("id");
  const body = await c.req.json();
  const rows = await db.select().from(drafts).where(eq(drafts.id, id)).limit(1);
  const draft = rows[0];
  if (!draft) return apiError(c, 404, "not_found", "草稿不存在");
  const proj = await db.select().from(projects).where(eq(projects.id, draft.projectId)).limit(1);
  if (!proj[0] || proj[0].ownerId !== c.get("userId")) {
    return apiError(c, 403, "forbidden", "无权编辑该草稿");
  }

  const baseRevision = Number(body.baseRevision ?? -1);
  if (baseRevision !== draft.revision) {
    return c.json(
      {
        code: "conflict",
        message: "草稿版本冲突，请选择本地或服务器版本",
        requestId: c.get("requestId"),
        retryable: false,
        server: {
          revision: draft.revision,
          graph: draft.graph,
          layout: draft.layout,
          theme: draft.theme,
        },
      },
      409
    );
  }

  const parsed = DraftPayloadSchema.partial().safeParse(body);
  if (!parsed.success) {
    return apiError(c, 422, "invalid_draft", parsed.error.message);
  }
  const graph = (parsed.data.graph ?? draft.graph) as DesignGraph;
  const issues = validateGraph(graph);
  const blocking = issues.filter((i) => i.code !== "unknown_block");
  // allow save with warnings but block hard type errors on publish later
  if (body.strict && blocking.length) {
    return apiError(c, 422, "graph_invalid", blocking[0]!.message, {
      nodeId: blocking[0]!.nodeId,
    });
  }

  const nextRev = draft.revision + 1;
  await db
    .update(drafts)
    .set({
      revision: nextRev,
      graph,
      layout: parsed.data.layout ?? draft.layout,
      theme: parsed.data.theme ?? draft.theme,
      updatedAt: new Date(),
    })
    .where(eq(drafts.id, id));

  if (parsed.data.name) {
    await db
      .update(projects)
      .set({ name: parsed.data.name.slice(0, 40) })
      .where(eq(projects.id, draft.projectId));
  }

  return c.json({ revision: nextRev, issues });
});

projectRoutes.post("/releases", async (c) => {
  const body = await c.req.json();
  const draftId = String(body.draftId ?? "");
  const expectedRevision = Number(body.revision ?? -1);
  const visibility = (body.visibility as string) ?? "public";
  const description = String(body.description ?? "").slice(0, 500);
  const category = (body.category as string) ?? "life";

  const rows = await db.select().from(drafts).where(eq(drafts.id, draftId)).limit(1);
  const draft = rows[0];
  if (!draft) return apiError(c, 404, "not_found", "草稿不存在");
  const proj = await db.select().from(projects).where(eq(projects.id, draft.projectId)).limit(1);
  if (!proj[0] || proj[0].ownerId !== c.get("userId")) {
    return apiError(c, 403, "forbidden", "无权发布");
  }
  if (expectedRevision !== draft.revision) {
    return apiError(c, 409, "conflict", "发布前 revision 已变化，请重新保存");
  }

  const issues = validateGraph(draft.graph as DesignGraph);
  if (issues.some((i) => ["type_mismatch", "cycle", "cardinality", "direction"].includes(i.code))) {
    return apiError(c, 422, "graph_invalid", issues[0]!.message);
  }

  const existing = await db
    .select()
    .from(releases)
    .where(eq(releases.projectId, draft.projectId))
    .orderBy(desc(releases.version))
    .limit(1);
  const version = (existing[0]?.version ?? 0) + 1;
  const releaseId = `r_${nanoid(10)}`;
  const slug = `${proj[0].name.toLowerCase().replace(/[^a-z0-9\u4e00-\u9fff]+/gi, "-").slice(0, 24)}-${releaseId.slice(-6)}`;

  const manifest = ManifestSchema.parse({
    schemaVersion: SCHEMA_VERSION,
    graph: draft.graph,
    layout: draft.layout,
    theme: draft.theme,
    blockVersions: blockVersions(),
    assets: [],
    license: "remixable",
    parentReleaseId: null,
    category,
    description,
    coverUrl: null,
  });
  const hash = manifestHash(manifest);

  await db.insert(releases).values({
    id: releaseId,
    projectId: draft.projectId,
    version,
    parentReleaseId: null,
    slug,
    manifestHash: hash,
    manifest,
    license: "remixable",
    visibility,
    status: "webPublished",
  });
  await db
    .update(projects)
    .set({ visibility, category, description })
    .where(eq(projects.id, draft.projectId));
  await db.insert(stats).values({ releaseId, views: 0, likes: 0, uses: 0 }).onConflictDoNothing();

  return c.json({
    releaseId,
    slug,
    url: `/run/${releaseId}`,
    hash,
    version,
  });
});

projectRoutes.get("/releases/:id", async (c) => {
  const id = c.req.param("id");
  const byId = await db.select().from(releases).where(eq(releases.id, id)).limit(1);
  const bySlug = byId[0]
    ? byId
    : await db.select().from(releases).where(eq(releases.slug, id)).limit(1);
  const rel = bySlug[0];
  if (!rel) return apiError(c, 404, "not_found", "作品不存在");
  if (rel.withdrawnAt) return apiError(c, 410, "withdrawn", rel.withdrawReason ?? "版本已撤下");
  if (rel.visibility === "private" && true) {
    const proj = await db.select().from(projects).where(eq(projects.id, rel.projectId)).limit(1);
    if (proj[0]?.ownerId !== c.get("userId")) {
      return apiError(c, 403, "forbidden", "私有作品需要作者权限");
    }
  }
  const proj = await db.select().from(projects).where(eq(projects.id, rel.projectId)).limit(1);
  const author = proj[0]
    ? await db.select().from(users).where(eq(users.id, proj[0].ownerId)).limit(1)
    : [];
  const st = await db.select().from(stats).where(eq(stats.releaseId, rel.id)).limit(1);
  return c.json({
    id: rel.id,
    slug: rel.slug,
    version: rel.version,
    parentReleaseId: rel.parentReleaseId,
    manifestHash: rel.manifestHash,
    manifest: rel.manifest,
    license: rel.license,
    visibility: rel.visibility,
    status: rel.status,
    publishedAt: rel.publishedAt,
    name: proj[0]?.name,
    description: proj[0]?.description,
    category: proj[0]?.category,
    author: { id: author[0]?.id, displayName: author[0]?.displayName ?? "匿名" },
    stats: st[0] ?? { views: 0, likes: 0, uses: 0 },
  });
});

projectRoutes.post("/releases/:id/remix", async (c) => {
  const id = c.req.param("id");
  const body = await c.req.json().catch(() => ({}));
  const idem = c.req.header("idempotency-key");
  const relRows = await db.select().from(releases).where(eq(releases.id, id)).limit(1);
  const rel = relRows[0];
  if (!rel) return apiError(c, 404, "not_found", "作品不存在");
  if (rel.license !== "remixable") {
    return apiError(c, 403, "license", "该作品不允许复制改造");
  }

  // Idempotency: reuse remix project tagged with parent release + key in description marker
  if (idem) {
    const marker = `remix:${id}:${idem}`;
    const found = await db
      .select()
      .from(projects)
      .where(and(eq(projects.ownerId, c.get("userId") as string), eq(projects.description, marker)))
      .limit(1);
    if (found[0]) {
      const d = await db.select().from(drafts).where(eq(drafts.projectId, found[0].id)).limit(1);
      return c.json({ projectId: found[0].id, draftId: d[0]?.id, reused: true });
    }
  }

  const manifest = rel.manifest as {
    graph: DesignGraph;
    layout: unknown;
    theme: unknown;
  };
  const projectId = `p_${nanoid(10)}`;
  const draftId = `d_${nanoid(10)}`;
  const name = String(body.name ?? `改造·${rel.slug}`).slice(0, 40);
  const marker = idem ? `remix:${id}:${idem}` : "";

  await db.insert(projects).values({
    id: projectId,
    ownerId: c.get("userId") as string,
    name,
    visibility: "private",
    rootProjectId: rel.projectId,
    category: "life",
    description: marker,
  });
  await db.insert(drafts).values({
    id: draftId,
    projectId,
    schemaVersion: SCHEMA_VERSION,
    revision: 0,
    graph: manifest.graph,
    layout: manifest.layout,
    theme: manifest.theme,
  });

  return c.json({
    projectId,
    draftId,
    parentReleaseId: rel.id,
    note: "已复制图结构与公开默认值；未复制运行记录与私人数据",
  });
});

projectRoutes.get("/discover", async (c) => {
  const query = (c.req.query("query") ?? "").trim().toLowerCase();
  const category = c.req.query("category") ?? "all";
  const sort = c.req.query("sort") ?? "newest";
  const cursor = Number(c.req.query("cursor") ?? 0);
  const limit = 24;

  const rows = await db
    .select({
      release: releases,
      project: projects,
      author: users,
      stats,
    })
    .from(releases)
    .innerJoin(projects, eq(projects.id, releases.projectId))
    .innerJoin(users, eq(users.id, projects.ownerId))
    .leftJoin(stats, eq(stats.releaseId, releases.id))
    .where(
      and(
        eq(releases.visibility, "public"),
        eq(releases.status, "webPublished"),
        isNull(releases.withdrawnAt)
      )
    )
    .orderBy(desc(releases.publishedAt))
    .limit(200);

  let items = rows.map((r) => ({
    id: r.release.id,
    slug: r.release.slug,
    name: r.project.name,
    description: r.project.description,
    category: r.project.category,
    author: r.author.displayName,
    publishedAt: r.release.publishedAt,
    stats: {
      views: r.stats?.views ?? 0,
      likes: r.stats?.likes ?? 0,
      uses: r.stats?.uses ?? 0,
    },
    coverHint: r.project.category,
  }));

  if (category !== "all") items = items.filter((i) => i.category === category);
  if (query) {
    items = items.filter(
      (i) =>
        i.name.toLowerCase().includes(query) ||
        i.description.toLowerCase().includes(query)
    );
  }
  if (sort === "hot") {
    items.sort(
      (a, b) => b.stats.uses + b.stats.likes * 2 - (a.stats.uses + a.stats.likes * 2)
    );
  }

  const page = items.slice(cursor, cursor + limit);
  return c.json({
    items: page,
    nextCursor: cursor + limit < items.length ? cursor + limit : null,
  });
});

projectRoutes.get("/studio", async (c) => {
  const ownerId = c.get("userId") as string;
  const mine = await db
    .select({ project: projects, draft: drafts })
    .from(projects)
    .leftJoin(drafts, eq(drafts.projectId, projects.id))
    .where(and(eq(projects.ownerId, ownerId), isNull(projects.deletedAt)))
    .orderBy(desc(projects.createdAt));

  const published = await db
    .select({ release: releases, project: projects })
    .from(releases)
    .innerJoin(projects, eq(projects.id, releases.projectId))
    .where(eq(projects.ownerId, ownerId))
    .orderBy(desc(releases.publishedAt));

  return c.json({
    drafts: mine.map((m) => ({
      projectId: m.project.id,
      draftId: m.draft?.id,
      name: m.project.name,
      revision: m.draft?.revision ?? 0,
      updatedAt: m.draft?.updatedAt,
      rootProjectId: m.project.rootProjectId,
    })),
    published: published.map((p) => ({
      releaseId: p.release.id,
      slug: p.release.slug,
      name: p.project.name,
      version: p.release.version,
      publishedAt: p.release.publishedAt,
      status: p.release.status,
    })),
  });
});

projectRoutes.put("/runtime/:instance/state", async (c) => {
  const instanceId = c.req.param("instance");
  const body = await c.req.json();
  const releaseId = String(body.releaseId ?? "");
  const expectedRevision = Number(body.expectedRevision ?? 0);
  const eventId = String(body.eventId ?? "");
  const subjectId = (c.get("userId") as string) || "guest";

  if (!releaseId || !eventId) {
    return apiError(c, 400, "bad_request", "需要 releaseId 与 eventId");
  }

  const rel = await db.select().from(releases).where(eq(releases.id, releaseId)).limit(1);
  if (!rel[0]) return apiError(c, 404, "not_found", "作品不存在");

  // dedupe
  try {
    await db.insert(runtimeStates).values({
      id: `tmp_${nanoid(6)}`,
      releaseId,
      subjectId,
      instanceId,
      revision: 0,
      state: {},
    }).onConflictDoNothing();
  } catch {
    /* ignore */
  }

  const existing = await db
    .select()
    .from(runtimeStates)
    .where(
      and(
        eq(runtimeStates.releaseId, releaseId),
        eq(runtimeStates.subjectId, subjectId),
        eq(runtimeStates.instanceId, instanceId)
      )
    )
    .limit(1);

  let row = existing[0];
  if (!row) {
    const id = `rs_${nanoid(10)}`;
    await db.insert(runtimeStates).values({
      id,
      releaseId,
      subjectId,
      instanceId,
      revision: 0,
      state: body.state ?? {},
    });
    row = (
      await db.select().from(runtimeStates).where(eq(runtimeStates.id, id)).limit(1)
    )[0]!;
  }

  if (row.revision !== expectedRevision) {
    return c.json(
      {
        code: "conflict",
        message: "状态版本冲突，请重读后重放事件",
        requestId: c.get("requestId"),
        retryable: true,
        state: row.state,
        revision: row.revision,
      },
      409
    );
  }

  // event dedupe via unique index
  try {
    await db.execute(sql`
      INSERT INTO event_log (id, release_id, subject_id, event_id)
      VALUES (${`ev_${nanoid(10)}`}, ${releaseId}, ${subjectId}, ${eventId})
    `);
  } catch {
    return c.json({ nextState: row.state, revision: row.revision, deduped: true });
  }

  const nextState = body.nextState ?? body.state ?? row.state;
  const nextRev = row.revision + 1;
  await db
    .update(runtimeStates)
    .set({ state: nextState, revision: nextRev, updatedAt: new Date() })
    .where(eq(runtimeStates.id, row.id));

  await db.execute(sql`
    INSERT INTO release_stats (release_id, views, likes, uses)
    VALUES (${releaseId}, 0, 0, 1)
    ON CONFLICT (release_id) DO UPDATE SET uses = release_stats.uses + 1
  `);

  return c.json({ nextState, revision: nextRev });
});

projectRoutes.get("/runtime/:instance/state", async (c) => {
  const instanceId = c.req.param("instance");
  const releaseId = c.req.query("releaseId") ?? "";
  const subjectId = c.get("userId") as string;
  const rows = await db
    .select()
    .from(runtimeStates)
    .where(
      and(
        eq(runtimeStates.releaseId, releaseId),
        eq(runtimeStates.subjectId, subjectId),
        eq(runtimeStates.instanceId, instanceId)
      )
    )
    .limit(1);
  if (!rows[0]) return c.json({ state: null, revision: 0 });
  return c.json({ state: rows[0].state, revision: rows[0].revision });
});
