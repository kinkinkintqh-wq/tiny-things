import { drizzle } from "drizzle-orm/postgres-js";
import postgres from "postgres";
import * as schema from "./schema.js";

const url =
  process.env.DATABASE_URL ??
  "postgresql://tinythings:tinythings@127.0.0.1:5432/tinythings";

export const sql = postgres(url, { max: 10 });
export const db = drizzle(sql, { schema });
