import { sql } from "./client.js";

async function main() {
  await sql`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      display_name VARCHAR(80) NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
  `;
  await sql`
    CREATE TABLE IF NOT EXISTS projects (
      id TEXT PRIMARY KEY,
      owner_id TEXT NOT NULL,
      name VARCHAR(40) NOT NULL,
      visibility VARCHAR(16) NOT NULL DEFAULT 'private',
      root_project_id TEXT,
      category VARCHAR(16) NOT NULL DEFAULT 'life',
      description TEXT NOT NULL DEFAULT '',
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      deleted_at TIMESTAMPTZ
    );
  `;
  await sql`
    CREATE TABLE IF NOT EXISTS drafts (
      id TEXT PRIMARY KEY,
      project_id TEXT NOT NULL,
      schema_version VARCHAR(32) NOT NULL,
      revision INTEGER NOT NULL DEFAULT 0,
      graph JSONB NOT NULL,
      layout JSONB NOT NULL,
      theme JSONB NOT NULL,
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
  `;
  await sql`
    CREATE TABLE IF NOT EXISTS releases (
      id TEXT PRIMARY KEY,
      project_id TEXT NOT NULL,
      version INTEGER NOT NULL,
      parent_release_id TEXT,
      slug VARCHAR(64) NOT NULL,
      manifest_hash VARCHAR(80) NOT NULL,
      manifest JSONB NOT NULL,
      license VARCHAR(32) NOT NULL DEFAULT 'remixable',
      visibility VARCHAR(16) NOT NULL DEFAULT 'public',
      status VARCHAR(24) NOT NULL DEFAULT 'webPublished',
      published_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      withdrawn_at TIMESTAMPTZ,
      withdraw_reason TEXT
    );
  `;
  await sql`
    CREATE TABLE IF NOT EXISTS runtime_states (
      id TEXT PRIMARY KEY,
      release_id TEXT NOT NULL,
      subject_id TEXT NOT NULL,
      instance_id TEXT NOT NULL,
      revision INTEGER NOT NULL DEFAULT 0,
      state JSONB NOT NULL,
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
  `;
  await sql`
    CREATE UNIQUE INDEX IF NOT EXISTS runtime_unique
    ON runtime_states (release_id, subject_id, instance_id);
  `;
  await sql`
    CREATE TABLE IF NOT EXISTS event_log (
      id TEXT PRIMARY KEY,
      release_id TEXT NOT NULL,
      subject_id TEXT NOT NULL,
      event_id TEXT NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
  `;
  await sql`
    CREATE UNIQUE INDEX IF NOT EXISTS event_dedupe
    ON event_log (release_id, subject_id, event_id);
  `;
  await sql`
    CREATE TABLE IF NOT EXISTS favorites (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      release_id TEXT NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
  `;
  await sql`
    CREATE TABLE IF NOT EXISTS anchors (
      id TEXT PRIMARY KEY,
      release_id TEXT NOT NULL,
      chain_id INTEGER NOT NULL,
      registry TEXT,
      tx_hash TEXT,
      block_hash TEXT,
      status VARCHAR(24) NOT NULL DEFAULT 'prepared',
      manifest_hash VARCHAR(80) NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
  `;
  await sql`
    CREATE TABLE IF NOT EXISTS compilations (
      id TEXT PRIMARY KEY,
      owner_id TEXT NOT NULL,
      source_hash VARCHAR(80) NOT NULL,
      status VARCHAR(24) NOT NULL DEFAULT 'queued',
      result JSONB,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
  `;
  await sql`
    CREATE TABLE IF NOT EXISTS release_stats (
      release_id TEXT PRIMARY KEY,
      views INTEGER NOT NULL DEFAULT 0,
      likes INTEGER NOT NULL DEFAULT 0,
      uses INTEGER NOT NULL DEFAULT 0
    );
  `;
  console.log("Migrations applied.");
  await sql.end();
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
