import { serve } from "@hono/node-server";
import "./types.js";
import { Hono } from "hono";
import { cors } from "hono/cors";
import { compileRoutes } from "./routes/compile.js";
import { projectRoutes } from "./routes/projects.js";
import { withRequestId, withSession } from "./middleware/session.js";

const app = new Hono();
const webOrigin = process.env.WEB_ORIGIN ?? "http://127.0.0.1:3846";

app.use(
  "*",
  cors({
    origin: [webOrigin, "http://localhost:3846", "http://127.0.0.1:3846"],
    credentials: true,
  })
);
app.use("*", withRequestId);
app.use("/api/v1/*", withSession);

app.get("/health", (c) => c.json({ ok: true, service: "tinythings-api" }));

app.route("/api/v1", projectRoutes);
app.route("/api/v1", compileRoutes);

const port = Number(process.env.API_PORT ?? 3847);
console.log(`Tiny Things API listening on http://127.0.0.1:${port}`);
serve({ fetch: app.fetch, port, hostname: "0.0.0.0" });
