import { serve } from "@hono/node-server";
import { compileGraph, encodeNetlist } from "@tinythings/compiler";
import type { DesignGraph } from "@tinythings/schema";
import { Hono } from "hono";

const app = new Hono();

app.get("/health", (c) => c.json({ ok: true, service: "tinythings-compiler" }));

app.post("/compile", async (c) => {
  const body = await c.req.json();
  const graph = body.graph as DesignGraph;
  const result = compileGraph(graph);
  return c.json({
    ...result,
    netlistHex: result.netlist
      ? Buffer.from(encodeNetlist(result.netlist)).toString("hex")
      : null,
  });
});

const port = Number(process.env.COMPILER_PORT ?? 3848);
console.log(`Compiler service on http://127.0.0.1:${port}`);
serve({ fetch: app.fetch, port, hostname: "0.0.0.0" });
