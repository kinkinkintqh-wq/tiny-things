/** Isolated fork rehearsal ONLY. No wallets, keys, or public write transport. */
import { createPublicClient, http, parseAbi, encodeFunctionData, keccak256, toHex, hexToBytes, bytesToHex } from 'viem';
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { assertLocalForkEndpoint, assertLocalForkIdentity } from './src/fork-safety';
import { decodeSequential, stepSequential } from '../../apps/web/packages/compiler/src/sequential';
import { packBits, unpackBits } from '../../apps/web/packages/compiler/src/nand';
const endpoint='http://127.0.0.1:18546';assertLocalForkEndpoint(endpoint);
const c=createPublicClient({transport:http(endpoint,{timeout:20000,retryCount:0})});
const rpc=async(method:string,params:unknown[]=[])=>c.request({method:method as never,params:params as never}) as Promise<any>;
assertLocalForkIdentity(await c.getChainId(),await rpc('web3_clientVersion'));
const target=JSON.parse(readFileSync(new URL('../../verification/tapeout-preflight/target.json',import.meta.url),'utf8'));
const pinned=await c.getBlock({blockNumber:BigInt(target.blockNumber)});if(pinned.hash!==target.blockHash)throw Error('Pinned block mismatch');
if(await c.getBlockNumber()!==BigInt(target.blockNumber))throw Error('Fork must be freshly started');
const processor=target.processor as `0x${string}`,transistors=target.transistors as `0x${string}`;
for(const contract of target.code) { const code=await c.getCode({address:contract.address});if(!code||keccak256(code)!==contract.codeHash)throw Error('Proxy code changed');const impl=await c.getCode({address:contract.implementation});if(!impl||keccak256(impl)!==contract.implementationCodeHash)throw Error('Implementation code changed'); }
const read=async(address:`0x${string}`,signature:string,args:unknown[]=[])=>c.readContract({address,abi:parseAbi([signature]),functionName:signature.split('(')[0]!.split(' ').at(-1)!,args} as never) as Promise<any>;
const record: any={status:'running-local-fork',startedAt:new Date().toISOString(),publicTransactions:0,simulationChainId:31337,sourceChainId:196,sourceBlock:target.blockNumber,sourceBlockHash:target.blockHash,processor,transistors,syntheticAccount:'0x0000000000000000000000000000000000031337',transactions:[],circuits:[]};
const account=record.syntheticAccount as `0x${string}`;
const snapshot=await rpc('evm_snapshot');
try {
 await rpc('anvil_setBalance',[account,toHex(10n**20n)]);
 await rpc('anvil_impersonateAccount',[account]);
 const fee=await read(processor,'function TAPEOUT_FEE() view returns(uint256)');
 const mintPrice=await read(transistors,'function mintPrice() view returns(uint256)');
 const protocolFee=await read(transistors,'function protocolFee() view returns(uint256)');
 const cap=await read(transistors,'function supplyCap() view returns(uint256)');
 const minted=await read(transistors,'function minted() view returns(uint256)');
 const artifacts=['sum','matches'].map(name=>JSON.parse(readFileSync(new URL(`../../verification/letter-circuits/${name}.json`,import.meta.url),'utf8')));
 const nand=artifacts.reduce((s,a)=>s+BigInt(a.nandCount),0n), latch=16n;
 if(cap-minted<nand+latch)throw Error('Insufficient mint capacity');
 record.quote={feeWei:fee,mintPriceWei:mintPrice,mintProtocolFeeWei:protocolFee,nand,latch,remainingCapacity:cap-minted,requiredValueWei:(nand+latch)*mintPrice+2n*protocolFee+2n*fee,gasPriceWei:await c.getGasPrice()};
 async function send(address:`0x${string}`,signature:string,args:unknown[],value:bigint,label:string){
  assertLocalForkIdentity(await c.getChainId(),await rpc('web3_clientVersion'));
  const data=encodeFunctionData({abi:parseAbi([signature]),functionName:signature.split('(')[0]!.split(' ').at(-1)!,args} as never);
  const estimate=await c.estimateGas({account,to:address,data,value});
  const hash=await rpc('eth_sendTransaction',[{from:account,to:address,data,value:toHex(value),gas:toHex(estimate+estimate/4n)}]);
  const receipt=await c.getTransactionReceipt({hash});if(receipt.status!=='success')throw Error(`${label} reverted`);
  record.transactions.push({simulationOnly:true,label,to:address,data,valueWei:value,estimatedGas:estimate,simulationHash:hash,gasUsed:receipt.gasUsed});
 }
 const balance=(id:bigint)=>read(transistors,'function balanceOf(address,uint256) view returns(uint256)',[account,id]);
 if(await balance(0n)!==0n||await balance(1n)!==0n)throw Error('Synthetic address already holds resources');
 await send(transistors,'function mint(uint256,uint256) payable',[0n,nand],nand*mintPrice+protocolFee,'mint NAND');
 await send(transistors,'function mint(uint256,uint256) payable',[1n,latch],latch*mintPrice+protocolFee,'mint LATCH');
 if(await balance(0n)!==nand||await balance(1n)!==latch)throw Error('Mint balance mismatch');
 for(const artifact of artifacts){
  const bytes=hexToBytes(artifact.encodedHex);
  if(createHash('sha256').update(bytes).digest('hex')!==artifact.sha256)throw Error('Artifact hash mismatch');
  const circuit=decodeSequential(bytes,artifact.nIn,artifact.nOut);
  const previous=await read(processor,'function nextId() view returns(uint256)');
  await send(processor,'function tapeout(bytes,uint32,uint32) payable',[artifact.encodedHex,artifact.nIn,artifact.nOut],fee,`tapeout ${artifact.rule.rule}`);
  const id=await read(processor,'function nextId() view returns(uint256)');if(id!==previous+1n)throw Error('Unexpected simulated circuit ID');
  const owner=await read(processor,'function ownerOf(uint256) view returns(address)',[id]);if(owner.toLowerCase()!==account)throw Error('Wrong author');
  const netlist=await read(processor,'function netlist(uint256) view returns(bytes)',[id]);if(netlist!==artifact.encodedHex)throw Error('On-fork bytecode differs');
  const info=await read(processor,'function circuitInfo(uint256) view returns(uint32,uint32,uint32,uint32)',[id]);
  if(info[0]!==5||info[1]!==8||info[2]!==8)throw Error('Circuit pin/state counts differ');
  const evidence:any={rule:artifact.rule,artifactSHA256:artifact.sha256,simulatedCircuitId:id,info,vectors:[],sequence:[]};
  // All valid progress states, both lock states and all five-bit inputs.
  for(let progress=0;progress<=artifact.rule.target;progress++)for(const unlocked of [false,true])for(let input=0;input<32;input++){
   const state=unpackBits(Uint8Array.of(progress|(unlocked?128:0)),8);
   const inputs=unpackBits(Uint8Array.of(input),5);
   const local=stepSequential(circuit,state,inputs);
   const [newState,outputs]=await read(processor,'function step(uint256,bytes,bytes) view returns(bytes,bytes)',[id,bytesToHex(packBits(state)),bytesToHex(packBits(inputs))]);
   if(bytesToHex(packBits(local.state))!==newState||bytesToHex(packBits(local.outputs))!==outputs)throw Error(`step mismatch ${artifact.rule.rule}/${progress}/${unlocked}/${input}`);
   evidence.vectors.push({state:bytesToHex(packBits(state)),input:bytesToHex(packBits(inputs)),newState,outputs});
  }
  let state='0x';
  for(const input of [3,13,5,13,13,7,16,0]){
   const [newState,outputs]=await read(processor,'function step(uint256,bytes,bytes) view returns(bytes,bytes)',[id,state,toHex(input,{size:1})]);
   const local=stepSequential(circuit,state==='0x'?[]:unpackBits(hexToBytes(state as `0x${string}`),8),unpackBits(Uint8Array.of(input),5));
   if(bytesToHex(packBits(local.state))!==newState||bytesToHex(packBits(local.outputs))!==outputs)throw Error('Chained step mismatch');
   evidence.sequence.push({state,input:toHex(input,{size:1}),newState,outputs});state=newState;
  }
  record.circuits.push(evidence);
  console.log(`${artifact.rule.rule}: ${evidence.vectors.length} state/input vectors + ${evidence.sequence.length} chained steps matched`);
 }
 if(await balance(0n)!==0n||await balance(1n)!==0n)throw Error('Unexpected resource burn');
 record.status='fork-tapeout-and-step-verified';
} catch(error){record.status='failed';record.error=String(error);throw error;}
finally {
 record.forkReverted=await rpc('evm_revert',[snapshot]);
 record.finishedAt=new Date().toISOString();
 writeFileSync(new URL('../../verification/tapeout-preflight/fork-result.json',import.meta.url),JSON.stringify(record,(_,v)=>typeof v==='bigint'?v.toString():v,2)+'\n');
 console.log(JSON.stringify({status:record.status,forkReverted:record.forkReverted,publicTransactions:0}));
}
