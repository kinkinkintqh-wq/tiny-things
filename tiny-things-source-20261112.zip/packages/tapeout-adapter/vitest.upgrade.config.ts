import { defineConfig } from "vitest/config";
import { fileURLToPath } from "node:url";
const web = fileURLToPath(new URL("../../apps/web/", import.meta.url));
export default defineConfig({ resolve: { alias: Object.fromEntries(["schema", "block-registry", "runtime", "compiler"].map((name) => [`@tinythings/${name}`, `${web}packages/${name}/src/index.ts`])) }, test: { include: [`${web}packages/**/*.test.ts`], environment: "node" } });
