import { createPublicClient, http, parseAbi, keccak256 } from 'viem';
import { mkdirSync, writeFileSync } from 'node:fs';
const rpcUrl='https://rpc.xlayer.tech';
const run=process.env.TINY_EVIDENCE_RUN;
if(run&&!/^\d{8}$/.test(run))throw Error('Invalid evidence run');
const evidence=new URL(`../../verification/${run?'tapeout-live-'+run:'tapeout-preflight'}/`,import.meta.url);
mkdirSync(evidence,{recursive:true});
const c=createPublicClient({transport:http(rpcUrl,{timeout:12000,retryCount:0})});
const factory='0x1f09daefa827f02cbb40967cc91b259763760761';
const block=await c.getBlock();
if(await c.getChainId()!==196)throw Error('Wrong chain');
const reads=[];
async function read(address,signature,args=[]){const functionName=signature.split('(')[0].split(' ').at(-1);const value=await c.readContract({address,abi:parseAbi([signature]),functionName,args,blockNumber:block.number});reads.push({address,signature,args,value});return value;}
const processor=await read(factory,'function cpus(uint256) view returns(address)',[BigInt(process.env.TINY_CPU_INDEX ?? '414')]);
if(!await read(factory,'function isCPU(address) view returns(bool)',[processor]))throw Error('Not registered');
if((await read(processor,'function factory() view returns(address)')).toLowerCase()!==factory)throw Error('Factory mismatch');
const transistors=await read(processor,'function transistors() view returns(address)');
for(const [a,s] of [[processor,'function TAPEOUT_FEE() view returns(uint256)'],[processor,'function nextId() view returns(uint256)'],[transistors,'function mintPrice() view returns(uint256)'],[transistors,'function protocolFee() view returns(uint256)'],[transistors,'function supplyCap() view returns(uint256)'],[transistors,'function minted() view returns(uint256)']])await read(a,s);
const beaconSlot='0xa3f0ad74e5423aebfd80d3ef4346578335a9a72aeaee59ff6cb3582b35133d50';
const proxySlot='0x360894a13ba1a3210667c828492db98dca3e2076cc3735a920a3ca505d382bbc';
const code=[];
for(const a of [factory,processor,transistors]){
 const bytecode=await c.getCode({address:a,blockNumber:block.number});
 const beaconWord=await c.getStorageAt({address:a,slot:beaconSlot,blockNumber:block.number});
 const implementationWord=await c.getStorageAt({address:a,slot:proxySlot,blockNumber:block.number});
 let implementation='0x'+implementationWord.slice(-40);
 const beacon='0x'+beaconWord.slice(-40);
 if(BigInt(beacon)!==0n)implementation=await read(beacon,'function implementation() view returns(address)');
 const implementationCode=BigInt(implementation)===0n?'0x':await c.getCode({address:implementation,blockNumber:block.number});
 code.push({address:a,codeHash:keccak256(bytecode),beacon,implementation,implementationCodeHash:keccak256(implementationCode)});
 writeFileSync(new URL(`${a}.hex`,evidence),bytecode+'\n');
 if(implementationCode!=='0x')writeFileSync(new URL(`${implementation}.hex`,evidence),implementationCode+'\n');
}
const final=await c.getBlock({blockNumber:block.number});if(final.hash!==block.hash)throw Error('Reorg');
const result={checkedAt:new Date().toISOString(),chainId:196,rpcUrl,blockNumber:block.number,blockHash:block.hash,factory,processor,transistors,reads,code,status:'read-only-target-inspection',broadcastTransactions:0};
const json=JSON.stringify(result,(_,v)=>typeof v==='bigint'?v.toString():v,2);
writeFileSync(new URL('target.json',evidence),json+'\n');console.log(json);
