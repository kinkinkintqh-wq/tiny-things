import { createPublicClient,http,parseAbi } from 'viem';
import {writeFileSync} from 'node:fs';
const c=createPublicClient({transport:http('https://rpc.xlayer.tech',{timeout:12000,retryCount:0})});
const block=await c.getBlock();const factory='0x1f09daefa827f02cbb40967cc91b259763760761';
const read=(address,signature,args=[])=>c.readContract({address,abi:parseAbi([signature]),functionName:signature.split('(')[0].split(' ').at(-1),args,blockNumber:block.number});
const count=await read(factory,'function cpuCount() view returns(uint256)');const out=[];
for(const index of [...new Set([0n,275n,...Array.from({length:16},(_,i)=>count-1n-BigInt(i))])]){
 const processor=await read(factory,'function cpus(uint256) view returns(address)',[index]);
 const transistors=await read(processor,'function transistors() view returns(address)');
 const values={index,processor,transistors};
 await Promise.all(['supplyCap','minted','mintPrice','protocolFee'].map(async name=>values[name]=await read(transistors,`function ${name}() view returns(uint256)`))); 
 values.fee=await read(processor,'function TAPEOUT_FEE() view returns(uint256)');
 out.push(values);
}
const result={checkedAt:new Date().toISOString(),blockNumber:block.number,blockHash:block.hash,count,candidates:out};
const json=JSON.stringify(result,(_,v)=>typeof v==='bigint'?v.toString():v,2);
writeFileSync(new URL('../../verification/tapeout-preflight/candidates.json',import.meta.url),json+'\n');console.log(json);
