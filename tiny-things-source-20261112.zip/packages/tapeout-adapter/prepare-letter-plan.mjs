/** Prepares reviewable unsigned requests; no RPC, wallet or broadcaster. */
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { decodeFunctionData, parseAbi } from 'viem';
const read=p=>JSON.parse(readFileSync(new URL(`../../verification/${p}`,import.meta.url),'utf8'));
const fork=read('tapeout-preflight/fork-result.json'),target=read('tapeout-preflight/target.json'),gas=read('tapeout-preflight/gas-price.json');
if(fork.status!=='fork-tapeout-and-step-verified'||fork.forkReverted!==true||fork.publicTransactions!==0||gas.chainId!==196||fork.sourceBlockHash!==target.blockHash)throw Error('Unverified evidence');
const abi=parseAbi(['function mint(uint256,uint256) payable','function tapeout(bytes,uint32,uint32) payable']);
const gasPriceCeiling=40000000n;
const transactions=fork.transactions.map((tx,i)=>{
 const decoded=decodeFunctionData({abi,data:tx.data});
 if(i<2){if(decoded.functionName!=='mint'||tx.to!==target.transistors||BigInt(decoded.args[0])!==BigInt(i)||BigInt(decoded.args[1])!==BigInt(i===0?787:16))throw Error('Resource request changed');}
 else {
  const artifact=read(`letter-circuits/${i===2?'sum':'matches'}.json`);
  if(decoded.functionName!=='tapeout'||tx.to!==target.processor||decoded.args[0]!==artifact.encodedHex||decoded.args[1]!==5||decoded.args[2]!==8||createHash('sha256').update(Buffer.from(artifact.encodedHex.slice(2),'hex')).digest('hex')!==artifact.sha256)throw Error('Circuit request changed');
 }
 const gasLimit=(BigInt(tx.estimatedGas)*125n+99n)/100n;
 return {order:i+1,label:tx.label,chainId:196,to:tx.to,data:tx.data,valueWei:tx.valueWei,gasLimit:gasLimit.toString(),decoded:{function:decoded.functionName,args:decoded.args},note:'Unsigned review candidate; sender, nonce and live gas parameters are intentionally absent. Re-estimate with the actual selected wallet.'};
});
const value=transactions.reduce((s,t)=>s+BigInt(t.valueWei),0n),gasLimit=transactions.reduce((s,t)=>s+BigInt(t.gasLimit),0n);
const plan={format:'tiny-letter-tapeout-plan/1',status:'review-only-not-authorized-to-broadcast',generatedAt:new Date().toISOString(),chainId:196,target,sourceForkEvidence:{block:fork.sourceBlock,hash:fork.sourceBlockHash,vectorCount:fork.circuits.reduce((s,c)=>s+c.vectors.length,0),sequenceCount:fork.circuits.reduce((s,c)=>s+c.sequence.length,0)},artifactSHA256:fork.circuits.map(c=>({rule:c.rule,sha256:c.artifactSHA256})),quote:{contractValueWei:value.toString(),gasPriceSnapshot:gas,estimatedGasTotal:fork.transactions.reduce((s,t)=>s+BigInt(t.estimatedGas),0n).toString(),gasLimitTotal:gasLimit.toString(),gasPriceCeilingWei:gasPriceCeiling.toString(),maxTotalAtCeilingWei:(value+gasLimit*gasPriceCeiling).toString(),suggestedApprovalCapWei:'4200000000000000'},transactions,requiredBeforeBroadcast:['Choose the user wallet and verify it is on chain 196; do not reuse the synthetic fork address.','Re-read registration, beacons, implementations, fees, mint capacity and resource balances. Stop if implementation/hash or fee changes.','Re-estimate and simulate each ordered request for the selected wallet; confirm total fits the approved cap.','Obtain explicit transaction approval; no current approval exists.','Record actual receipt events, processor + IDs and exact netlist hash, then verify step against local vectors. Simulated IDs are never used as real IDs.'],recovery:'Minted ERC1155 resources remain in the selected wallet if flow stops. Each confirmed tapeout consumes its resources and fee and cannot be undone; inspect receipts before retrying. Existing completed circuits can be bound independently. Never resend an ambiguous transaction.'};
const json=JSON.stringify(plan,(_,v)=>typeof v==='bigint'?v.toString():v,2)+'\n';
writeFileSync(new URL('../../verification/tapeout-preflight/unsigned-plan.json',import.meta.url),json);
writeFileSync(new URL('../../verification/tapeout-preflight/unsigned-plan.sha256',import.meta.url),createHash('sha256').update(json).digest('hex')+'\n');
console.log(JSON.stringify({status:plan.status,contractValueWei:value.toString(),maxTotalAtCeilingWei:plan.quote.maxTotalAtCeilingWei,sha256:createHash('sha256').update(json).digest('hex')}));
