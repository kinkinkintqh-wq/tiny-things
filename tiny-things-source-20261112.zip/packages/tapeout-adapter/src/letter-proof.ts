/** Bounded, fixed-block verification of a REAL deployed letter circuit. No transaction methods. */
import { createPublicClient,http,parseAbi,hexToBytes,bytesToHex,type PublicClient,type Address } from 'viem';
import { createHash } from 'node:crypto';
import sum from '../../../verification/letter-circuits/sum.json';
import matches from '../../../verification/letter-circuits/matches.json';
import { decodeSequential,stepSequential } from '../../../apps/web/packages/compiler/src/sequential';
import { packBits,unpackBits } from '../../../apps/web/packages/compiler/src/nand';
const processor='0x9e2849c04A513FE64db07521cBE52d078d905c0E' as Address;
const factory='0x1f09daefa827f02cbb40967cc91b259763760761' as Address;
export async function verifyLetterCircuit(client:PublicClient,idInput:string,rule:string){
 if(!/^\d{1,20}$/.test(idInput)||BigInt(idInput)<BigInt(1))throw Error('请填写正式流片收据里的正整数电路 ID');
 if(rule!=='sum'&&rule!=='matches')throw Error('请选择已验证的情书规则');
 if(await client.getChainId()!==196)throw Error('节点不在 X Layer 主网');
 const artifact=rule==='sum'?sum:matches;
 const block=await client.getBlock();const id=BigInt(idInput);
 const read=async(address:Address,signature:string,args:unknown[]=[])=>client.readContract({address,abi:parseAbi([signature]),functionName:signature.split('(')[0]!.split(' ').at(-1)!,args,blockNumber:block.number} as never) as Promise<unknown>;
 if(await read(factory,'function isCPU(address) view returns(bool)',[processor])!==true)throw Error('处理器未登记');
 if(String(await read(processor,'function factory() view returns(address)')).toLowerCase()!==factory)throw Error('处理器 Factory 不匹配');
 const info=await read(processor,'function circuitInfo(uint256) view returns(uint32,uint32,uint32,uint32)',[id]) as number[];
 if(info[0]!==5||info[1]!==8||info[2]!==8||info[3]!==artifact.nandCount+8)throw Error('正式电路布局与所选情书规则不匹配');
 const nl=await read(processor,'function netlist(uint256) view returns(bytes)',[id]) as string;
 if(nl!==artifact.encodedHex||createHash('sha256').update(Buffer.from(nl.slice(2),'hex')).digest('hex')!==artifact.sha256)throw Error('正式网表与已验证电路包不一致');
 const local=decodeSequential(hexToBytes(nl as `0x${string}`),5,8);
 const vectors:Array<{state:string;input:string;newState:string;outputs:string}>=[];
 const compare=async(state:Uint8Array,input:number)=>{
  const inputs=Uint8Array.of(input);const expected=stepSequential(local,state.length?unpackBits(state,8):[],unpackBits(inputs,5));
  const chain=await read(processor,'function step(uint256,bytes,bytes) view returns(bytes,bytes)',[id,bytesToHex(state),bytesToHex(inputs)]) as [string,string];
  if(chain[0]!==bytesToHex(packBits(expected.state))||chain[1]!==bytesToHex(packBits(expected.outputs)))throw Error('链上 step 返回与本地电路不一致，未验证通过');
  vectors.push({state:bytesToHex(state),input:bytesToHex(inputs),newState:chain[0],outputs:chain[1]});return hexToBytes(chain[0] as `0x${string}`);
 };
 // Boundary vectors cover idle, invalid faces, valid faces, force unlock and saturation.
 for(const progress of [0,artifact.rule.target-1,artifact.rule.target])for(const unlocked of [false,true])for(const input of [0,1,3,13,15,16])await compare(Uint8Array.of(progress|(unlocked?128:0)),input);
 let state:Uint8Array=new Uint8Array();for(const input of [3,13,5,13,13,7,16,0])state=await compare(state,input);
 const final=await client.getBlock({blockNumber:block.number});if(final.hash!==block.hash)throw Error('读取期间区块变化，请重新验证');
 return {format:'tiny-letter-proof/1',verified:true,chainId:196,processor,circuitId:idInput,rule:artifact.rule,artifactSHA256:artifact.sha256,nIn:5,nOut:8,nState:8,blockNumber:block.number.toString(),blockHash:block.hash,checkedAt:new Date().toISOString(),vectors,note:'正式 X Layer 网表及 44 个边界/连续 step 向量已核对；不证明网页随机数公平，也不代表进度保存在链上。'};
}
export async function readLetterProof(id:string,rule:string){return verifyLetterCircuit(createPublicClient({transport:http('https://rpc.xlayer.tech',{timeout:12000,retryCount:0})}),id,rule);}
