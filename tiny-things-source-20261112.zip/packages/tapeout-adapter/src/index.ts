import {
  createPublicClient,
  http,
  type Hex,
  type PublicClient,
} from "viem";

export const XLAYER_MAINNET = {
  chainId: 196,
  name: "X Layer",
  rpcUrls: ["https://rpc.xlayer.tech", "https://xlayerrpc.okx.com"],
  explorer: "https://www.okx.com/web3/explorer/xlayer",
  nativeCurrency: "OKB",
} as const;

export const XLAYER_TESTNET = {
  chainId: 1952,
  name: "X Layer Testnet",
  rpcUrls: ["https://testrpc.xlayer.tech/terigon"],
} as const;

/** Discovery-only candidates from TAP-02 — NOT production allowlisted until verified. */
export const TAPEOUT_CANDIDATES = {
  factory: "0x1f09DAeFA827f02CBb40967cc91b259763760761" as Hex,
  implementation: "0x977f217887E085D298Cb3819cDAD5A0ee35F29B2" as Hex,
  status: "unverified" as const,
};

export const processorAbi = [
  {
    type: "function",
    name: "circuitInfo",
    stateMutability: "view",
    inputs: [{ name: "id", type: "uint256" }],
    outputs: [
      { name: "nIn", type: "uint32" },
      { name: "nOut", type: "uint32" },
      { name: "nState", type: "uint32" },
      { name: "gateCount", type: "uint32" },
    ],
  },
  {
    type: "function",
    name: "netlist",
    stateMutability: "view",
    inputs: [{ name: "id", type: "uint256" }],
    outputs: [{ name: "data", type: "bytes" }],
  },
  {
    type: "function",
    name: "eval",
    stateMutability: "view",
    inputs: [
      { name: "id", type: "uint256" },
      { name: "inputs", type: "bytes" },
    ],
    outputs: [{ name: "outputs", type: "bytes" }],
  },
  {
    type: "function",
    name: "step",
    stateMutability: "view",
    inputs: [
      { name: "id", type: "uint256" },
      { name: "state", type: "bytes" },
      { name: "inputs", type: "bytes" },
    ],
    outputs: [
      { name: "newState", type: "bytes" },
      { name: "outputs", type: "bytes" },
    ],
  },
] as const;

export const registryAbi = [
  {
    type: "function",
    name: "publish",
    stateMutability: "nonpayable",
    inputs: [
      { name: "projectKey", type: "bytes32" },
      { name: "manifestHash", type: "bytes32" },
      { name: "parentHash", type: "bytes32" },
      { name: "manifestURI", type: "string" },
    ],
    outputs: [{ name: "versionId", type: "uint256" }],
  },
  {
    type: "event",
    name: "VersionPublished",
    inputs: [
      { name: "publisher", type: "address", indexed: true },
      { name: "projectKey", type: "bytes32", indexed: true },
      { name: "manifestHash", type: "bytes32", indexed: true },
      { name: "parentHash", type: "bytes32", indexed: false },
      { name: "manifestURI", type: "string", indexed: false },
      { name: "versionId", type: "uint256", indexed: false },
    ],
  },
] as const;

export interface EvidenceRecord {
  mock: boolean;
  rpcUrl: string;
  chainId: number;
  blockNumber?: string;
  blockHash?: string;
  processor?: string;
  circuitId?: string;
  method?: string;
  rawInput?: string;
  rawOutput?: string;
  error?: string;
  note: string;
}

export function createXLayerClient(rpcUrl: string = XLAYER_MAINNET.rpcUrls[0]): PublicClient {
  return createPublicClient({
    transport: http(rpcUrl, { timeout: 12_000 }),
  });
}

export async function probeChain(rpcUrl?: string): Promise<EvidenceRecord> {
  const url = rpcUrl ?? XLAYER_MAINNET.rpcUrls[0];
  try {
    const client = createXLayerClient(url);
    const chainId = await client.getChainId();
    const block = await client.getBlock({ blockTag: "latest" });
    return {
      mock: false,
      rpcUrl: url,
      chainId,
      blockNumber: block.number.toString(),
      blockHash: block.hash,
      note:
        chainId === 196
          ? "X Layer mainnet RPC reachable"
          : `Connected chainId=${chainId} (expected 196 for mainnet)`,
    };
  } catch (err) {
    return {
      mock: true,
      rpcUrl: url,
      chainId: 196,
      error: err instanceof Error ? err.message : String(err),
      note: "RPC unreachable — marked mock/待验证; local product still runs",
    };
  }
}

export async function tryCircuitInfo(opts: {
  processor: Hex;
  circuitId: bigint;
  rpcUrl?: string;
}): Promise<EvidenceRecord> {
  const url = opts.rpcUrl ?? XLAYER_MAINNET.rpcUrls[0];
  try {
    const client = createXLayerClient(url);
    const block = await client.getBlock({ blockTag: "latest" });
    const info = await client.readContract({
      address: opts.processor,
      abi: processorAbi,
      functionName: "circuitInfo",
      args: [opts.circuitId],
      blockNumber: block.number,
    });
    return {
      mock: false,
      rpcUrl: url,
      chainId: await client.getChainId(),
      blockNumber: block.number.toString(),
      blockHash: block.hash,
      processor: opts.processor,
      circuitId: opts.circuitId.toString(),
      method: "circuitInfo",
      rawOutput: JSON.stringify(info),
      note: "Read circuitInfo at fixed block — verify ABI/fingerprint before allowlisting",
    };
  } catch (err) {
    return {
      mock: true,
      rpcUrl: url,
      chainId: 196,
      processor: opts.processor,
      circuitId: opts.circuitId.toString(),
      method: "circuitInfo",
      error: err instanceof Error ? err.message : String(err),
      note: "circuitInfo call failed — keep 待验证; do not show verified badge",
    };
  }
}

export { estimateTapeoutCost } from "./cost.js";
export type { TapeoutCostEstimate, TapeoutCostInput } from "./cost.js";

export function prepareAnchorCall(input: {
  registry: Hex;
  projectKey: Hex;
  manifestHash: Hex;
  parentHash: Hex;
  manifestURI: string;
}) {
  return {
    chainId: 196,
    to: input.registry,
    functionName: "publish" as const,
    args: [
      input.projectKey,
      input.manifestHash,
      input.parentHash,
      input.manifestURI,
    ] as const,
    warning:
      "网页发布成功 ≠ 链上成功。签名前请确认网络 196、费用与不可撤销性。候选地址未验证前不可写入生产 allowlist。",
  };
}
