/** Mutation clients are never allowed to point at a public network. */
export function assertLocalForkEndpoint(url: string) {
  if (url !== "http://127.0.0.1:18546") throw new Error("Simulation requires the fixed loopback endpoint");
}
export function assertLocalForkIdentity(chainId: number, clientVersion: string) {
  if (chainId !== 31337 || !/^anvil\//i.test(clientVersion)) throw new Error("Refusing mutation outside the local Anvil chain");
}
