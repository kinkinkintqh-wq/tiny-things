/** Public reads only. Transactions are returned unsigned to the user's wallet. */
import { createPublicClient, http, keccak256, parseAbi, toHex, type Address, type Hex, type PublicClient } from 'viem';
import plan from '../../../verification/tapeout-preflight/unsigned-plan.json';
import { createHash } from 'node:crypto';
export const PLAN_HASH = 'c3e83ac2a9ac14614468cc2c58a04140eeb220a82004af0ffa05cb1f6f9fc14e';
if(createHash('sha256').update(JSON.stringify(plan,null,2)+'\n').digest('hex')!==PLAN_HASH)throw Error('批准清单版本不匹配，已停止加载');
export const STEPS = plan.transactions.map(t => ({ label: t.label, to: t.to, data: t.data, value: toHex(BigInt(t.valueWei)), gas: toHex(BigInt(t.gasLimit)) }));
export const LAUNCH_SUMMARY = { planHash: PLAN_HASH, chainId: 196, cap: '0.0042', processor: plan.target.processor, steps: STEPS.map(({ label,to,value })=>({label,to,value})), note: '仅两枚预设规则；已有情书内容不上传链。' };
const ADDRESS = /^0x[0-9a-f]{40}$/i, HASH=/^0x[0-9a-f]{64}$/i;
const beaconSlot='0xa3f0ad74e5423aebfd80d3ef4346578335a9a72aeaee59ff6cb3582b35133d50' as Hex;
const implSlot='0x360894a13ba1a3210667c828492db98dca3e2076cc3735a920a3ca505d382bbc' as Hex;
const same=(a:string,b:string)=>a.toLowerCase()===b.toLowerCase();
export function validateLaunchInput(account:string,step:number,hashes:string[]) {
 if(!ADDRESS.test(account)||account.toLowerCase()==='0x0000000000000000000000000000000000031337'||BigInt(account)===BigInt(0))throw Error('请选择自己的有效钱包地址');
 if(!Number.isInteger(step)||step<0||step>4||hashes.length!==step||hashes.some(h=>!HASH.test(h))||new Set(hashes.map(h=>h.toLowerCase())).size!==hashes.length)throw Error('交易进度无效，请核对已有收据');
}
export function remainingBudget(step:number,spent:bigint,gasPrice:bigint) {
 const cap=BigInt(plan.quote.suggestedApprovalCapWei);
 if(gasPrice>BigInt(plan.quote.gasPriceCeilingWei))throw Error('网络费用超过已批准单价上限，请稍后重试');
 const remaining=plan.transactions.slice(step).reduce((s,t)=>s+BigInt(t.valueWei)+BigInt(t.gasLimit)*gasPrice,BigInt(0));
 if(spent+remaining>cap)throw Error('预计总支出超过 0.0042 OKB，已停止');
 return { cap, maximumTotal:spent+remaining };
}
export function matchApprovedTransaction(tx:{from:string;to:string|null;input:string;value:bigint;chainId?:number},account:string,index:number) {
 const approved=plan.transactions[index];
 if(!approved||!same(tx.from,account)||!tx.to||!same(tx.to,approved.to)||!same(tx.input,approved.data)||tx.value!==BigInt(approved.valueWei)||(tx.chainId!==undefined&&tx.chainId!==196))throw Error('收据对应的交易与批准清单不一致');
}
export async function inspectLaunch(client:PublicClient,account:string,step:number,hashes:string[]) {
 validateLaunchInput(account,step,hashes);
 if(await client.getChainId()!==196)throw Error('节点不是 X Layer 主网');
 const block=await client.getBlock();
 const bn=block.number;
 const read=async(address:string,signature:string,args:unknown[]=[])=>client.readContract({address:address as Address,abi:parseAbi([signature]),functionName:signature.split('(')[0]!.split(' ').at(-1)!,args,blockNumber:bn} as never) as Promise<unknown>;
 for(const entry of plan.target.code){
  const bytecode=await client.getCode({address:entry.address as Address,blockNumber:bn});
  if(!bytecode||keccak256(bytecode)!==entry.codeHash)throw Error('目标合约代码已变化，请重新验证');
  const beacon=await client.getStorageAt({address:entry.address as Address,slot:beaconSlot,blockNumber:bn});
  const expectedBeacon=entry.beacon;
  if(!beacon||!same('0x'+beacon.slice(-40),expectedBeacon))throw Error('合约 Beacon 已变化');
  const implementation=BigInt(expectedBeacon)!==BigInt(0)
   ? await read(expectedBeacon,'function implementation() view returns(address)') as string
   : '0x'+(await client.getStorageAt({address:entry.address as Address,slot:implSlot,blockNumber:bn}))!.slice(-40);
  if(!same(implementation,entry.implementation))throw Error('合约实现已变化，请重新验证');
  const code=await client.getCode({address:implementation as Address,blockNumber:bn});
  if(!code||keccak256(code)!==entry.implementationCodeHash)throw Error('实现代码不匹配');
 }
 if(await read(plan.target.factory,'function isCPU(address) view returns(bool)',[plan.target.processor])!==true||!same(await read(plan.target.processor,'function factory() view returns(address)') as string,plan.target.factory)||!same(await read(plan.target.processor,'function transistors() view returns(address)') as string,plan.target.transistors))throw Error('处理器登记或资源合约不匹配');
 const fee=await read(plan.target.processor,'function TAPEOUT_FEE() view returns(uint256)') as bigint;
 const protocol=await read(plan.target.transistors,'function protocolFee() view returns(uint256)') as bigint;
 const price=await read(plan.target.transistors,'function mintPrice() view returns(uint256)') as bigint;
 if(fee!==BigInt(1300000000000000)||protocol!==BigInt(660000000000000)||price!==BigInt(0))throw Error('协议费用已变化，不能沿用旧清单');
 let spent=BigInt(0);
 for(let i=0;i<hashes.length;i++){
  const hash=hashes[i] as Hex;
  const receipt=await client.getTransactionReceipt({hash});
  const tx=await client.getTransaction({hash});matchApprovedTransaction(tx,account,i);
  if(receipt.status!=='success')throw Error('已有交易未成功，请核对后恢复，不能重复发送');
  if(receipt.blockNumber>bn)throw Error('收据尚未进入本次核对区块，请稍后刷新');
  const canonical=await client.getBlock({blockNumber:receipt.blockNumber});
  if(canonical.hash!==receipt.blockHash)throw Error('收据所在区块已变化，请稍后刷新');
  spent+=tx.value+receipt.gasUsed*receipt.effectiveGasPrice;
 }
 const gasPrice=await client.getGasPrice();
 const budget=remainingBudget(step,spent,gasPrice);
 const minted=await read(plan.target.transistors,'function minted() view returns(uint256)') as bigint;
 const cap=await read(plan.target.transistors,'function supplyCap() view returns(uint256)') as bigint;
 const needed=(step===0?BigInt(787):BigInt(0))+(step<=1?BigInt(16):BigInt(0));
 if(cap-minted<needed)throw Error('处理器剩余资源不足，请重新选择并验证');
 if(step>=2&&step<4){
  const nand=await read(plan.target.transistors,'function balanceOf(address,uint256) view returns(uint256)',[account,BigInt(0)]) as bigint;
  const latch=await read(plan.target.transistors,'function balanceOf(address,uint256) view returns(uint256)',[account,BigInt(1)]) as bigint;
  if(nand<(step===2?BigInt(787):BigInt(397))||latch<(step===2?BigInt(16):BigInt(8)))throw Error('钱包中的 NAND/LATCH 不足，请核对资源收据');
 }
 const balance=await client.getBalance({address:account as Address,blockNumber:bn});
 if(balance<budget.maximumTotal-spent)throw Error('钱包 OKB 余额不足以覆盖剩余操作与网络费用');
 let transaction: {from:string;to:string;data:string;value:string;gas:string;gasPrice:string;chainId:string}|null=null;
 if(step<4){
  const tx=STEPS[step]!;
  const call={account:account as Address,to:tx.to as Address,data:tx.data as Hex,value:BigInt(tx.value)};
  // For later mint/tapeout steps, preceding receipts must be confirmed before simulation.
  await client.call({...call,blockNumber:bn});
  const estimate=await client.estimateGas(call);
  if(estimate>BigInt(tx.gas))throw Error('当前 gas 估算超过已验证限额，请重新演练');
  transaction={from:account,to:tx.to,data:tx.data,value:tx.value,gas:tx.gas,gasPrice:toHex(gasPrice),chainId:'0xc4'};
 }
 const final=await client.getBlock({blockNumber:bn});if(final.hash!==block.hash)throw Error('检查期间区块变化，请重新检查');
 return { planHash:PLAN_HASH,account,step,blockNumber:bn.toString(),blockHash:block.hash,checkedAt:new Date().toISOString(),balanceWei:balance.toString(),spentWei:spent.toString(),maximumTotalWei:budget.maximumTotal.toString(),transaction };
}
export async function liveLaunch(account:string,step:number,hashes:string[]) {
 return inspectLaunch(createPublicClient({transport:http('https://rpc.xlayer.tech',{timeout:12000,retryCount:0})}),account,step,hashes);
}
export async function verifyLetterReceipt(account:string,hash:string,index:number) {
 if(!Number.isInteger(index)||index<0||index>3)throw Error('请选择有效步骤');
 validateLaunchInput(account,0,[]);if(!HASH.test(hash))throw Error('交易哈希无效');
 const client=createPublicClient({transport:http('https://rpc.xlayer.tech',{timeout:12000,retryCount:0})});
 if(await client.getChainId()!==196)throw Error('节点网络错误');
 const [receipt,tx]=await Promise.all([client.getTransactionReceipt({hash:hash as Hex}),client.getTransaction({hash:hash as Hex})]);
 matchApprovedTransaction(tx,account,index);if(receipt.status!=='success')throw Error('交易未成功');
 const canonicalBlock=await client.getBlock({blockNumber:receipt.blockNumber});if(canonicalBlock.hash!==receipt.blockHash)throw Error('收据区块发生变化');
 if(index<2)return {chainId:196,txHash:hash,status:'resource-receipt-verified' as const};
 // Decode only the known TapedOut event; NFT Transfer alone is insufficient.
 const { decodeEventLog }=await import('viem');
 const events=receipt.logs.flatMap(log=>{if(!same(log.address,plan.target.processor))return [];try {const e=decodeEventLog({abi:parseAbi(['event TapedOut(uint256 indexed circuitId,address indexed author,uint32 gateCount,uint32 nState)']),data:log.data,topics:log.topics});return [e.args];}catch{return [];}});
 if(events.length!==1||!same(events[0]!.author,account)||events[0]!.nState!==8)throw Error('未找到匹配的流片事件');
 const id=events[0]!.circuitId;
 const netlist=await client.readContract({address:plan.target.processor as Address,abi:parseAbi(['function netlist(uint256) view returns(bytes)']),functionName:'netlist',args:[id],blockNumber:receipt.blockNumber});
 const expected=plan.artifactSHA256[index-2]!.sha256;
 if(createHash('sha256').update(Buffer.from(netlist.slice(2),'hex')).digest('hex')!==expected)throw Error('流片网表哈希不匹配');
 const canonical=await client.getBlock({blockNumber:receipt.blockNumber});if(canonical.hash!==receipt.blockHash)throw Error('收据区块发生变化');
 return {chainId:196,processor:plan.target.processor,circuitId:id.toString(),txHash:hash,artifactSHA256:expected,rule:index===2?'sum':'matches',status:'receipt-and-bytecode-verified' as const,note:'收据及字节已验证；正式 step 比对与作品绑定待完成'};
}
