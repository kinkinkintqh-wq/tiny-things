import {
  createPublicClient,
  formatEther,
  formatGwei,
  http,
  keccak256,
  toBytes,
  type Hex,
} from "viem";
import { TAPEOUT_CANDIDATES, XLAYER_MAINNET } from "./index.js";

export interface TapeoutCostInput {
  gateCount: number;
  latchCount?: number;
  byteLength: number;
  nIn: number;
  nOut: number;
  nState: number;
  processor?: Hex;
  rpcUrl?: string;
}

export interface TapeoutCostEstimate {
  chainId: number;
  nativeSymbol: string;
  mock: boolean;
  verifiedFee: boolean;
  protocolFeeWei: string;
  protocolFeeNative: string;
  gasPriceWei: string;
  gasPriceGwei: string;
  estimatedGas: string;
  estimatedGasNative: string;
  totalNative: string;
  transistorsToBurn: number;
  transistorNote: string;
  storageChunks: number;
  resource: {
    withinLocalBudget: boolean;
    maxNand: number;
    maxDepth: number;
    warnings: string[];
  };
  breakdown: Array<{ label: string; value: string; hint?: string }>;
  disclaimer: string;
  evidence: {
    feeSource: string;
    processorSample?: string;
    rpcUrl: string;
    readAt?: string;
  };
}

const LOCAL_MAX_NAND = 2000;
const LOCAL_MAX_DEPTH = 256;
/** Measured-ish base for SSTORE2-heavy tapeout; not a protocol guarantee. */
const GAS_BASE = 180_000n;
const GAS_PER_BYTE = 220n;
const GAS_PER_GATE_ANALYZE = 800n;

function sel(sig: string): Hex {
  return keccak256(toBytes(sig)).slice(0, 10) as Hex;
}

export async function estimateTapeoutCost(
  input: TapeoutCostInput
): Promise<TapeoutCostEstimate> {
  const rpcUrl = input.rpcUrl ?? XLAYER_MAINNET.rpcUrls[0];
  const latchCount = input.latchCount ?? 0;
  const transistors = Math.max(0, input.gateCount + latchCount);
  const chunks = Math.max(1, Math.ceil(input.byteLength / 24_000));
  const warnings: string[] = [];

  if (input.gateCount > LOCAL_MAX_NAND) {
    warnings.push(`门数 ${input.gateCount} 超过本地保护阈值 ${LOCAL_MAX_NAND}`);
  }
  if (input.nIn > 64 || input.nOut > 64) {
    warnings.push("输入/输出位宽超出 C0 默认预算（≤64）");
  }
  if (input.nState > 32) {
    warnings.push("状态位超出 C0 默认预算（≤32）");
  }

  let protocolFeeWei = 1_300_000_000_000_000n; // 0.0013 OKB fallback from prior read
  let verifiedFee = false;
  let feeSource = "cached X Layer implementation TAPEOUT_FEE (待复验)";
  let gasPriceWei = 20_000_001n;
  let readAt: string | undefined;
  let mock = false;
  let processorSample = input.processor;

  try {
    const client = createPublicClient({
      transport: http(rpcUrl, { timeout: 12_000 }),
    });
    const block = await client.getBlock({ blockTag: "latest" });
    readAt = block.number.toString();
    gasPriceWei = await client.getGasPrice();

    const impl = TAPEOUT_CANDIDATES.implementation;
    const feeData = await client.call({
      to: impl,
      data: sel("TAPEOUT_FEE()"),
      blockNumber: block.number,
    });
    if (feeData.data && feeData.data !== "0x") {
      protocolFeeWei = BigInt(feeData.data);
      verifiedFee = true;
      feeSource = `eth_call ${impl}.TAPEOUT_FEE() @ block ${block.number}`;
    }

    if (!processorSample) {
      // cpuAt(0)
      const data = (sel("cpuAt(uint256)") +
        "0".repeat(64)) as Hex;
      const cpu = await client.call({
        to: TAPEOUT_CANDIDATES.factory,
        data,
        blockNumber: block.number,
      });
      if (cpu.data && cpu.data.length >= 66) {
        processorSample = `0x${cpu.data.slice(-40)}` as Hex;
      }
    }
  } catch (err) {
    mock = true;
    warnings.push(
      `RPC 费用读取失败：${err instanceof Error ? err.message : String(err)}`
    );
    feeSource = "fallback 0.0013 OKB（上次成功读取值）；当前为估算";
  }

  const estimatedGas =
    GAS_BASE +
    GAS_PER_BYTE * BigInt(input.byteLength) +
    GAS_PER_GATE_ANALYZE * BigInt(Math.max(transistors, 1)) +
    BigInt(chunks) * 40_000n;

  const gasNativeWei = estimatedGas * gasPriceWei;
  const totalWei = protocolFeeWei + gasNativeWei;

  return {
    chainId: 196,
    nativeSymbol: "OKB",
    mock,
    verifiedFee,
    protocolFeeWei: protocolFeeWei.toString(),
    protocolFeeNative: formatEther(protocolFeeWei),
    gasPriceWei: gasPriceWei.toString(),
    gasPriceGwei: formatGwei(gasPriceWei),
    estimatedGas: estimatedGas.toString(),
    estimatedGasNative: formatEther(gasNativeWei),
    totalNative: formatEther(totalWei),
    transistorsToBurn: transistors,
    transistorNote:
      "TAP-02：流片会按顶层 NAND+LATCH 数量销毁晶体管代币（REF 子电路不再重复销毁）。X Layer 代币合约地址仍待从实现源码核实，此处只计数量。",
    storageChunks: chunks,
    resource: {
      withinLocalBudget:
        input.gateCount <= LOCAL_MAX_NAND && warnings.length === 0,
      maxNand: LOCAL_MAX_NAND,
      maxDepth: LOCAL_MAX_DEPTH,
      warnings,
    },
    breakdown: [
      {
        label: "协议流片费 TAPEOUT_FEE",
        value: `${formatEther(protocolFeeWei)} OKB`,
        hint: verifiedFee ? "链上实时读取" : "使用缓存/回退值",
      },
      {
        label: "估算 Gas",
        value: `${estimatedGas.toString()} ≈ ${formatEther(gasNativeWei)} OKB`,
        hint: `gasPrice ${formatGwei(gasPriceWei)} gwei · 按字节与门数模型估算，签名前以钱包为准`,
      },
      {
        label: "晶体管销毁",
        value: `${transistors} 个`,
        hint: "数量=顶层 NAND+LATCH；代币单价待核实",
      },
      {
        label: "网表存储",
        value: `${input.byteLength} bytes / ${chunks} × 24KB chunk`,
      },
    ],
    disclaimer:
      "流片会真实支出且不可自动撤销。本页为只读估算；未获你授权前不会发送交易。候选工厂/实现未写入生产 allowlist。网页发布成功 ≠ 流片成功。",
    evidence: {
      feeSource,
      processorSample,
      rpcUrl,
      readAt,
    },
  };
}
