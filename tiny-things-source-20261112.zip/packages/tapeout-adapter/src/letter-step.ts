import {createPublicClient,http,parseAbi} from 'viem';
import {verifyLetterCircuit} from './letter-proof';
import type {LetterTransition} from '../../../apps/web/packages/runtime/src/session';
const processor='0x9e2849c04A513FE64db07521cBE52d078d905c0E';
const client=createPublicClient({transport:http('https://rpc.xlayer.tech',{timeout:10000,retryCount:0})});
const proofs=new Map<string,{until:number;pending:Promise<unknown>}>();
async function proof(id:string,rule:string){
 const key=`${rule}:${id}`;let entry=proofs.get(key);
 if(!entry||entry.until<Date.now()){
  const pending=verifyLetterCircuit(client,id,rule);entry={until:Date.now()+60000,pending};proofs.set(key,entry);
  pending.catch(()=>{if(proofs.get(key)?.pending===pending)proofs.delete(key);});
 }
 await entry.pending;
}
export async function runLetterSteps(steps:LetterTransition[]){
  if(!Array.isArray(steps)||!steps.length||steps.length>16)throw Error('规则步骤无效');
  for(const s of steps)if(!s||!['sum','matches'].includes(s.rule)||![s.target,s.face,s.state,s.input,s.expected].every(Number.isInteger)||s.target<1||s.target>99||s.face<1||s.face>6||s.state<0||s.state>255||s.input<0||s.input>31||s.expected<0||s.expected>255)throw Error('规则输入无效');
  const selected=steps.map(s=>({step:s,id:s.rule==='sum'&&s.target===12?process.env.TINY_LETTER_SUM_ID:s.rule==='matches'&&s.target===3&&s.face===6?process.env.TINY_LETTER_MATCHES_ID:undefined}));
  // An absent binding is explicitly local. A configured but broken binding must fail closed.
  const active=selected.filter((s):s is {step:LetterTransition;id:string}=>s.id!==undefined);
  if(!active.length)return {mode:'local'};
  for(const {id,step} of active)await proof(id,step.rule);
  const block=await client.getBlock();
  for(const {id,step:s} of active){
   const hex=(v:number)=>`0x${v.toString(16).padStart(2,'0')}` as `0x${string}`;
   const [state,output]=await client.readContract({address:processor,abi:parseAbi(['function step(uint256,bytes,bytes) view returns(bytes,bytes)']),functionName:'step',args:[BigInt(id),hex(s.state),hex(s.input)],blockNumber:block.number});
   if(state!==hex(s.expected)||output!==hex(s.expected))throw Error('正式电路与本次运行结果不一致，未推进状态');
  }
  if((await client.getBlock({blockNumber:block.number})).hash!==block.hash)throw Error('区块发生变化，请重试本次操作');
  return {mode:active.length===steps.length?'chain':'mixed',chainId:196,processor,blockNumber:block.number.toString(),blockHash:block.hash,circuitIds:[...new Set(active.map(s=>s.id))]};

}
